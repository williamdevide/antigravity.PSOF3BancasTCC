<?php
declare(strict_types=1);
if (session_status() !== PHP_SESSION_ACTIVE) {
    $secure = !empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off';
    session_set_cookie_params(['httponly'=>true,'secure'=>$secure,'samesite'=>'Lax','path'=>'/']);
    session_start();
}
require_once __DIR__.'/data.php';
// Compatibilidade com PHP que não tenha extensão mbstring habilitada.
if (!function_exists('mb_strlen')) {
    function mb_strlen(string $s): int { return iconv_strlen($s, 'UTF-8') ?: strlen($s); }
}
if (!function_exists('mb_substr')) {
    function mb_substr(string $s,int $start,int $length): string { $val=iconv_substr($s,$start,$length,'UTF-8'); return $val===false?substr($s,$start,$length):$val; }
}
if (!function_exists('mb_strtolower')) {
    function mb_strtolower(string $s,string $encoding='UTF-8'): string { return strtolower($s); }
}

define('ROOT_PATH', dirname(__DIR__));
define('STORAGE_PATH', ROOT_PATH.'/storage');
require_once ROOT_PATH.'/config/supabase.php';
if (!is_dir(STORAGE_PATH)) mkdir(STORAGE_PATH, 0775, true);
function e($v): string { return htmlspecialchars((string)($v ?? ''), ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8'); }
function brand_logo_url(): string { return 'https://i.postimg.cc/jdQShqMz/Captura-de-tela-2026-10-27-081739-removebg-preview.png'; }
function base_url(string $path=''): string {
    static $base = null;
    if ($base === null) {
        $root=realpath(ROOT_PATH); $doc=realpath($_SERVER['DOCUMENT_ROOT'] ?? ''); $base='';
        if ($root && $doc && ($root===$doc || str_starts_with(str_replace('\\','/',$root),rtrim(str_replace('\\','/',$doc),'/').'/'))) {
            $base='/'.trim(str_replace('\\','/',substr($root,strlen($doc))),'/');
        }
    }
    return rtrim($base,'/').'/'.ltrim($path,'/');
}
function json_store(string $name): string {
    if (!preg_match('/^[a-z_]+$/', $name)) throw new InvalidArgumentException('Armazenamento inválido.');
    return STORAGE_PATH.'/'.$name.'.json';
}
function read_store(string $name): array {
    $file=json_store($name); if (!is_file($file)) return [];
    $fp=fopen($file,'rb'); if (!$fp) return [];
    try { flock($fp,LOCK_SH); $raw=stream_get_contents($fp); flock($fp,LOCK_UN); }
    finally { fclose($fp); }
    $data=json_decode($raw ?: '[]',true); return is_array($data)?$data:[];
}
function mutate_store(string $name, callable $action) {
    $fp=fopen(json_store($name),'c+');
    if (!$fp) throw new RuntimeException('Não foi possível gravar os dados.');
    try {
        if (!flock($fp,LOCK_EX)) throw new RuntimeException('Não foi possível bloquear o arquivo.');
        rewind($fp); $data=json_decode(stream_get_contents($fp) ?: '[]',true);
        if (!is_array($data)) $data=[];
        $result=$action($data);
        $out=json_encode($data,JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE|JSON_UNESCAPED_SLASHES|JSON_THROW_ON_ERROR);
        rewind($fp); ftruncate($fp,0); fwrite($fp,$out); fflush($fp);
        flock($fp,LOCK_UN);
        return $result;
    } finally { fclose($fp); }
}
function add_store(string $name,array $row): int {
    return mutate_store($name, static function(&$rows) use ($row) {
        $id=max(array_map(static fn($r)=>(int)($r['id']??0),$rows) ?: [0])+1;
        $row['id']=$id; $row['created_at']=date('Y-m-d H:i:s'); $rows[]=$row;
        return $id;
    });
}
function update_store_row(string $name,int $id,callable $update): bool {
    return mutate_store($name, static function (&$rows) use ($id,$update) {
        foreach ($rows as &$row) if ((int)($row['id']??0)===$id) { $update($row); return true; }
        return false;
    });
}
function csrf(): string { if (empty($_SESSION['csrf'])) $_SESSION['csrf']=bin2hex(random_bytes(32)); return $_SESSION['csrf']; }
function php_ini_size_bytes(string $size): int {
    $size=trim($size);
    if ($size === '') return 0;
    $value=(float)$size;
    $unit=strtolower(substr($size,-1));
    if ($unit==='g') $value*=1024*1024*1024;
    elseif ($unit==='m') $value*=1024*1024;
    elseif ($unit==='k') $value*=1024;
    return max(0,(int)$value);
}
function check_csrf(): void {
    if (!is_string($_POST['csrf']??null) || !hash_equals(csrf(),$_POST['csrf'])) {
        $postMax=php_ini_size_bytes((string)ini_get('post_max_size'));
        $contentLength=(int)($_SERVER['CONTENT_LENGTH']??0);
        if ($postMax>0 && $contentLength>$postMax) {
            http_response_code(413);
            exit('O arquivo enviado ultrapassou o limite de tamanho permitido neste servidor. Envie uma imagem menor (até 5 MB) ou ajuste os limites upload_max_filesize e post_max_size do PHP.');
        }
        http_response_code(419);
        exit('Sessão expirada. Atualize a página e tente novamente.');
    }
}
function flash(string $type,string $msg): void { $_SESSION['flash']=['type'=>$type,'msg'=>$msg]; }
function take_flash(): ?array { $f=$_SESSION['flash']??null; unset($_SESSION['flash']); return $f; }
function redirect(string $to): never { header('Location: '.base_url($to)); exit; }
function current_role(): string { return (string)($_SESSION['role']??''); }
function current_admin_account(): ?array {
    if (current_role() !== 'admin') return null;
    $id=(int)($_SESSION['admin_id']??0);
    foreach (read_store('admins') as $u) {
        if ((int)($u['id']??0)===$id && ($u['status']??'Ativo')==='Ativo') return $u;
    }
    return null;
}
function is_admin(): bool { return current_admin_account() !== null; }
function is_principal_admin(): bool {
    $u=current_admin_account();
    if (!$u) return false;
    // Compatibilidade: o primeiro administrador criado nas versões anteriores é o principal.
    $users=read_store('admins');
    $first=$users[0]??null;
    return ($u['tipo']??'')==='principal' || (
        $first && (int)$u['id']===(int)($first['id']??0)
        && !array_filter($users,static fn($r)=>($r['tipo']??'')==='principal')
    );
}
function require_principal_admin(): void { require_admin(); if (!is_principal_admin()) { http_response_code(403); exit('Somente o administrador principal pode autorizar acessos.'); } }
function require_admin(): void { if (!is_admin()) redirect('admin/login.php'); }
function is_ong(): bool { return current_role()==='ong' && (int)($_SESSION['ong_id']??0)>0; }
function require_ong(): void { if (!is_ong()) redirect('portal/login.php'); }
function current_ong(): ?array {
    if (!is_ong()) return null;
    foreach (read_store('ong_accounts') as $o) if ((int)($o['id']??0)===(int)$_SESSION['ong_id'] && ($o['status']??'')==='Aprovada') return $o;
    return null;
}
/** Mapeia o ID público de uma ONG para sua conta real aprovada, sem conceder acesso a entidades demonstrativas. */
function approved_ong_account_for_public_id(int $publicId): ?array {
    global $ongs;
    if (!isset($ongs[$publicId])) return null;
    foreach (read_store('ong_accounts') as $account) {
        if (($account['status'] ?? '') !== 'Aprovada') continue;
        if ((int)($account['public_ong_id'] ?? 0) === $publicId) return $account;
        if ($publicId === 1000 + (int)($account['id'] ?? 0) && empty($account['public_ong_id'])) return $account;
        // Um registro ilustrativo só pode ser conectado se o e-mail da conta aprovada for idêntico.
        $publicEmail = strtolower(trim((string)($ongs[$publicId]['email'] ?? '')));
        if ($publicEmail !== '' && $publicEmail === strtolower(trim((string)($account['email'] ?? '')))) return $account;
    }
    return null;
}
/** Direcionamento automático somente a uma ONG já aprovada que atue na mesma cidade. */
function approved_ong_for_report_city(string $city): ?array {
    $eligible=[];
    $key = static fn(string $v): string => strtolower(iconv('UTF-8','ASCII//TRANSLIT//IGNORE', $v) ?: $v);
    $search = trim(explode(',', $key($city))[0]);
    foreach (read_store('ong_accounts') as $account) {
        if (($account['status'] ?? '') !== 'Aprovada') continue;
        $cityAccount=$key((string)($account['cidade'] ?? ''));
        if ($search !== '' && str_contains($cityAccount,$search)) $eligible[]=$account;
    }
    if (!$eligible) return null;
    $open=[];
    foreach (read_store('denuncias') as $r) {
        $id=(int)($r['ong_id']??0);
        if ($id && !in_array(($r['status'] ?? ''),['Concluída','Arquivada'],true)) $open[$id]=($open[$id]??0)+1;
    }
    usort($eligible, static fn($a,$b)=> (($open[(int)$a['id']]??0)<=>($open[(int)$b['id']]??0)) ?: ((int)$a['id']<=>(int)$b['id']));
    return $eligible[0];
}
function find_ong(int $id): ?array { global $ongs; return $ongs[$id]??null; }
function find_animal(int $id): ?array { global $animals; return $animals[$id]??null; }
function admin_configured(): bool { return count(read_store('admins'))>0; }
function form_value(string $name,int $max=200): string { return mb_substr(trim((string)($_POST[$name]??'')),0,$max); }
function safe_photo_url(string $url): string {
    $url=trim($url);
    return filter_var($url,FILTER_VALIDATE_URL) && parse_url($url,PHP_URL_SCHEME)==='https' ? $url : '';
}
function save_uploaded_photo(string $field): ?string {
    if (empty($_FILES[$field]) || ($_FILES[$field]['error']??UPLOAD_ERR_NO_FILE)===UPLOAD_ERR_NO_FILE) return null;
    $f=$_FILES[$field];
    $error=(int)($f['error']??UPLOAD_ERR_NO_FILE);
    if (in_array($error,[UPLOAD_ERR_INI_SIZE,UPLOAD_ERR_FORM_SIZE],true)) {
        throw new RuntimeException('A imagem excedeu o limite de upload configurado no servidor (atual: '.ini_get('upload_max_filesize').'). Ajuste o PHP para aceitar arquivos de até 5 MB ou envie uma foto menor.');
    }
    if ($error===UPLOAD_ERR_PARTIAL) throw new RuntimeException('O envio da imagem foi interrompido. Tente novamente.');
    if (in_array($error,[UPLOAD_ERR_NO_TMP_DIR,UPLOAD_ERR_CANT_WRITE],true)) throw new RuntimeException('O servidor não conseguiu armazenar a imagem. Verifique as permissões e o espaço em disco.');
    if ($error!==UPLOAD_ERR_OK) throw new RuntimeException('Não foi possível receber o arquivo de imagem. Tente novamente.');
    if (($f['size']??0)>5*1024*1024) throw new RuntimeException('A imagem ultrapassa 5 MB. Compacte o arquivo antes de enviar.');
    if (($f['size']??0)<100) throw new RuntimeException('Imagem inválida. Envie um arquivo JPG, PNG ou WebP válido.');
    $mime=(new finfo(FILEINFO_MIME_TYPE))->file($f['tmp_name']);
    $types=['image/jpeg'=>'jpg','image/png'=>'png','image/webp'=>'webp'];
    if (!isset($types[$mime]) || !getimagesize($f['tmp_name'])) throw new RuntimeException('Envie uma foto JPG, PNG ou WebP.');
    $dir=ROOT_PATH.'/assets/uploads'; if (!is_dir($dir)) mkdir($dir,0775,true);
    $filename=bin2hex(random_bytes(16)).'.'.$types[$mime];
    if (!move_uploaded_file($f['tmp_name'],$dir.'/'.$filename)) throw new RuntimeException('Falha ao salvar imagem.');
    return base_url('assets/uploads/'.$filename);
}
/**
 * Provisiona automaticamente as cinco ONGs ilustrativas presentes no catálogo.
 * Idempotente: só acrescenta contas ausentes, não altera senhas, aprovações
 * nem demais organizações já cadastradas. Não depende de admin principal.
 */
function ensure_catalog_ong_accounts(): void {
    static $checked = false;
    if ($checked) return;
    $checked = true;
    $seedPath = ROOT_PATH . '/config/demo_ong_seed.json';
    if (!is_file($seedPath)) return;
    $seeds = json_decode((string) file_get_contents($seedPath), true);
    if (!is_array($seeds)) return;
    $existing = read_store('ong_accounts');
    $emailIndex = [];
    $catalogIndex = [];
    foreach ($existing as $account) {
        $emailIndex[strtolower(trim((string)($account['email'] ?? '')))] = true;
        $catalogId = (int)($account['public_ong_id'] ?? 0);
        if ($catalogId > 0) $catalogIndex[$catalogId] = true;
    }
    $hasMissing = false;
    foreach ($seeds as $seed) {
        $email = strtolower(trim((string)($seed['email'] ?? '')));
        $catalogId = (int)($seed['public_ong_id'] ?? 0);
        if ($catalogId > 0 && $email !== '' && !isset($emailIndex[$email]) && !isset($catalogIndex[$catalogId])) {
            $hasMissing = true;
            break;
        }
    }
    if (!$hasMissing) return;
    try {
        mutate_store('ong_accounts', static function (&$accounts) use ($seeds): void {
            $nextId = max(array_map(static fn($r) => (int)($r['id'] ?? 0), $accounts) ?: [0]);
            foreach ($seeds as $seed) {
                $email = strtolower(trim((string)($seed['email'] ?? '')));
                $catalogId = (int)($seed['public_ong_id'] ?? 0);
                if ($catalogId < 1 || $catalogId > 5 || $email === '' || empty($seed['password_hash'])) continue;
                $found = false;
                foreach ($accounts as $current) {
                    if (strtolower(trim((string)($current['email'] ?? ''))) === $email
                        || (int)($current['public_ong_id'] ?? 0) === $catalogId) {
                        $found = true;
                        break;
                    }
                }
                if ($found) continue;
                $seed['id'] = ++$nextId;
                $seed['status'] = 'Aprovada';
                $seed['demo'] = true;
                $seed['created_at'] = date('Y-m-d H:i:s');
                $accounts[] = $seed;
            }
        });
    } catch (Throwable $ex) {
        error_log('Guardiao Animal: falha ao inicializar contas de ONG. Confira escrita em storage.');
    }
}
// As contas devem estar disponíveis antes de abrir o login ou o painel.
ensure_catalog_ong_accounts();

// Provisiona uma unica conta principal, sem sobrescrever contas existentes.
require_once ROOT_PATH.'/config/auto_principal.php';
// ONGs aprovadas e novos animais publicados aparecem nas páginas públicas.
foreach (read_store('ong_accounts') as $account) {
    if (($account['status']??'')!=='Aprovada') continue;
    // Contas de exemplo vinculadas ao catálogo público: atualizações do perfil aparecem no site sem duplicar ONGs.
    $publicId = (int)($account['public_ong_id'] ?? 0);
    if ($publicId > 0 && isset($ongs[$publicId])) {
        foreach (['nome', 'cidade', 'bairro', 'foco', 'descricao', 'historia', 'foto'] as $field) {
            if (trim((string)($account[$field] ?? '')) !== '') $ongs[$publicId][$field] = $account[$field];
        }
        if (trim((string)($account['telefone'] ?? '')) !== '') $ongs[$publicId]['contato'] = $account['telefone'];
        // Mantém o e-mail público do perfil ilustrativo; e-mails reservados de login nunca são exibidos.
        continue;
    }
    $id=1000+(int)$account['id'];
    $ongs[$id]=[
        'nome'=>$account['nome'],'cidade'=>$account['cidade'],'bairro'=>$account['bairro'],'ano'=>(int)($account['ano']?:date('Y')),
        'foco'=>$account['foco']?:'Proteção animal','voluntarios'=>(int)($account['voluntarios']??0),
        'animais'=>0,'descricao'=>$account['descricao']?:'Organização parceira do Guardião Animal.',
        'historia'=>$account['historia']?:($account['descricao']??''),
        'foto'=>$account['foto']?:'https://images.unsplash.com/photo-1548199973-03cce0bbc87b?w=1200&auto=format&fit=crop',
        'contato'=>$account['telefone'],'email'=>$account['email']
    ];
}
$publicAccountIds=[];
foreach (read_store('ong_accounts') as $account) {
    if (($account['status'] ?? '') !== 'Aprovada') continue;
    $publicAccountIds[(int)$account['id']] = (int)($account['public_ong_id'] ?? 0) ?: 1000 + (int)$account['id'];
}
foreach (read_store('ong_animals') as $animal) {
    $aid=1000+(int)$animal['id'];$oid=$publicAccountIds[(int)$animal['ong_id']] ?? 0;
    if (!isset($ongs[$oid])) continue;
    $animals[$aid]=[
        'nome'=>$animal['nome'],'especie'=>$animal['especie'],'sexo'=>$animal['sexo'],'idade'=>$animal['idade'],
        'porte'=>$animal['porte'],'ong'=>$oid,'local'=>$animal['local'],'data'=>date('d/m/Y',strtotime($animal['created_at']??'now')),
        'status'=>$animal['status'],'temperamento'=>$animal['temperamento'],'historia'=>$animal['historia'],
        'foto'=>$animal['foto']?:'https://images.unsplash.com/photo-1552053831-71594a27632d?w=1000&auto=format&fit=crop'
    ];
    $ongs[$oid]['animais']++;
}
