<?php
declare(strict_types=1);
require_once __DIR__.'/bootstrap.php';

function ga_denuncia_payload(array $row): array {
    $urgencias = ['Baixa'=>'baixa', 'Média'=>'media', 'Alta'=>'alta', 'Emergência'=>'emergencia'];
    $identificado = ($row['identificacao'] ?? '') === 'Sim';
    $nome = $identificado ? trim((string)($row['nome'] ?? '')) : '';
    $email = $identificado ? trim((string)($row['email'] ?? '')) : '';
    $telefone = $identificado ? trim((string)($row['telefone'] ?? '')) : '';
    return [
        'protocolo'=>(string)($row['protocolo'] ?? ''),
        'especie'=>(string)($row['especie'] ?? ''),
        'descricao'=>(string)($row['descricao'] ?? ''),
        'local_ocorrencia'=>(string)($row['local'] ?? ''),
        'bairro'=>(string)($row['bairro'] ?? ''),
        'cidade'=>'Ourinhos', 'estado'=>'SP',
        'urgencia'=>$urgencias[(string)($row['urgencia'] ?? '')] ?? 'baixa',
        'deseja_identificar'=>$identificado,
        'nome_denunciante'=>$nome !== '' && $nome !== 'Não informado' ? $nome : null,
        'contato_denunciante'=>$email !== '' ? $email : ($telefone !== '' ? $telefone : null),
        'status'=>'recebida',
    ];
}

/** Retorna o resultado da tentativa, sem duplicar a denúncia local. */
function ga_sync_denuncia(int $id): array {
    $report = null;
    foreach (read_store('denuncias') as $row) {
        if ((int)($row['id'] ?? 0) === $id) { $report = $row; break; }
    }
    if (!$report) return ['ok'=>false, 'status'=>0, 'error'=>'Registro não encontrado.'];
    if (($report['bairro_origem'] ?? '') === 'Demonstração') {
        return ['ok'=>false, 'status'=>0, 'error'=>'Caso de demonstração não deve ser enviado ao banco real.'];
    }
    if (($report['supabase_sync'] ?? '') === 'sincronizado') return ['ok'=>true, 'status'=>200, 'error'=>''];
    if (empty($report['protocolo'])) return ['ok'=>false, 'status'=>0, 'error'=>'Registro sem protocolo único.'];
    $result = supabase_insert('denuncias', ga_denuncia_payload($report));
    // Em uma tentativa anterior, o Supabase pode ter salvo a linha, mas a hospedagem
    // perdido a resposta. Uma violação UNIQUE do protocolo indica o mesmo registro.
    $duplicate = (int)($result['status'] ?? 0) === 409
        && ($result['data']['code'] ?? '') === '23505'
        && stripos((string)($result['error'] ?? ''), 'protocolo') !== false;
    if ($duplicate) { $result['ok']=true; $result['error']=''; }
    update_store_row('denuncias', $id, static function (&$row) use ($result) {
        $row['supabase_sync'] = !empty($result['ok']) ? 'sincronizado' : 'pendente';
        $row['supabase_checked_at'] = date('Y-m-d H:i:s');
        $row['supabase_http_status'] = (int)($result['status'] ?? 0);
        if (!empty($result['ok'])) unset($row['supabase_error']);
        else $row['supabase_error'] = mb_substr((string)($result['error'] ?? 'Sem detalhes'), 0, 350);
    });
    return $result;
}
