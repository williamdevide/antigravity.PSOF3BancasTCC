<?php
require __DIR__.'/../includes/bootstrap.php';
require __DIR__.'/../includes/denuncia_sync.php';
require_admin();
$message = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    check_csrf();
    if (($_POST['action'] ?? '') === 'retry') {
        $tries = 0; $synced = 0; $failed = 0;
        foreach (read_store('denuncias') as $row) {
            if ($tries >= 20) break;
            if (($row['bairro_origem'] ?? '') === 'Demonstração') continue;
            if (($row['supabase_sync'] ?? '') === 'sincronizado') continue;
            if (empty($row['protocolo'])) continue;
            $tries++;
            $result = ga_sync_denuncia((int)$row['id']);
            if (!empty($result['ok'])) $synced++; else $failed++;
        }
        $message = "$tries tentativas: $synced sincronizadas e $failed pendentes.";
    }
}
$rows = array_values(array_filter(read_store('denuncias'), static fn($row) => ($row['bairro_origem'] ?? '') !== 'Demonstração'));
$pending = array_values(array_filter($rows, static fn($row) => ($row['supabase_sync'] ?? '') !== 'sincronizado'));
$synced = count($rows)-count($pending);
?><!doctype html><html lang="pt-BR"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Integrações | Guardião Animal</title><link rel="stylesheet" href="<?=e(base_url('assets/css/style.css'))?>?v=25"></head>
<body><main class="container" style="padding:40px 0;min-height:80vh;max-width:980px">
<p><a href="<?=e(base_url('admin/index.php'))?>">← Voltar ao painel</a></p><span class="eyebrow">Painel de diagnóstico restrito</span><h1>Sincronização das denúncias</h1>
<p>Projeto de destino: <code><?=e(SUPABASE_URL)?></code>. O banco precisa receber o SQL completo antes de sincronizar. Este painel não comprova conexão sem uma tentativa bem-sucedida.</p>
<p>Denúncias reais neste servidor: <strong><?=count($rows)?></strong>. Sincronizadas com o Supabase: <strong><?=$synced?></strong>. Pendentes: <strong><?=count($pending)?></strong>.</p>
<p>O mapa lê os registros locais deste servidor, independentemente do estado da sincronização. Para conferir a contagem sem dados pessoais, abra <a href="<?=e(base_url('api/map_data.php'))?>" target="_blank" rel="noopener">a API do mapa</a>.</p>
<?php if ($message):?><p role="status"><?=e($message)?></p><?php endif; ?>
<?php if ($pending):?><form method="post"><input type="hidden" name="csrf" value="<?=e(csrf())?>"><input type="hidden" name="action" value="retry"><button class="btn btn-dark" type="submit">Tentar sincronizar até 20 pendentes</button></form><?php endif; ?>
<h2>Últimas tentativas</h2><div style="overflow:auto"><table style="width:100%;border-collapse:collapse"><thead><tr><th>Protocolo</th><th>Bairro</th><th>Estado</th><th>HTTP</th><th>Retorno do Supabase</th></tr></thead><tbody>
<?php foreach (array_slice(array_reverse($rows),0,30) as $row): ?>
<tr style="border-bottom:1px solid #ccc"><td style="padding:12px"><?=e($row['protocolo'] ?? '#'.$row['id'])?></td><td><?=e($row['bairro'] ?? '')?></td><td><?=e($row['supabase_sync'] ?? 'não verificado')?></td><td><?=e($row['supabase_http_status'] ?? '-')?></td><td><?=e($row['supabase_error'] ?? '—')?></td></tr>
<?php endforeach; ?>
</tbody></table></div><p><small>Nunca exponha esta página ao público. Acesso restrito ao administrador; não exibe dados pessoais das denúncias.</small></p>
</main></body></html>
