<?php
require __DIR__.'/../includes/bootstrap.php';
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: private, no-store');
header('X-Content-Type-Options: nosniff');
if (!current_ong()) {
    http_response_code(403);
    echo json_encode(['error'=>'Acesso restrito a ONGs autorizadas.']);
    exit;
}
$reports = array_values(array_filter(read_store('denuncias'), static fn($r) => ($r['bairro_origem'] ?? '') !== 'Demonstração'));
echo json_encode([
    'count'=>count($reports),
    'latest'=>max(array_map(static fn($r) => (int)($r['id'] ?? 0), $reports) ?: [0]),
]);
