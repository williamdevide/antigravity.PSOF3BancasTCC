<?php
require __DIR__.'/../includes/bootstrap.php';
require __DIR__.'/../includes/ourinhos.php';
header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store, no-cache, must-revalidate, max-age=0');

$regions = ourinhos_neighborhoods();
$realCounts = array_fill_keys(array_keys($regions), 0);
$demoCounts = array_fill_keys(array_keys($regions), 0);

// O arquivo de exemplos e independente do armazenamento de denuncias reais.
// Nao gravamos exemplos no storage/denuncias.json nem os enviamos ao Supabase.
$demoFile = __DIR__.'/../config/demo_map_bairros.json';
$demoRows = is_readable($demoFile) ? json_decode((string)file_get_contents($demoFile), true) : [];
if (is_array($demoRows)) {
    foreach ($demoRows as $bairro => $qtd) {
        $normalized = normalize_ourinhos_bairro((string)$bairro);
        if ($normalized !== null && is_numeric($qtd)) {
            $demoCounts[$normalized] += max(0, min(1000, (int)$qtd));
        }
    }
}

// Somente registros da aplicacao sao tratados como denuncias recebidas.
foreach (read_store('denuncias') as $d) {
    $city = ourinhos_lower(trim((string)($d['cidade'] ?? '')));
    if ($city !== '' && strpos($city, 'ourinhos') === false) continue;
    $bairro = normalize_ourinhos_bairro((string)($d['bairro'] ?? ''));
    if ($bairro === null) continue;
    // Evita contar duas vezes exemplos antigos que eventualmente permanecam no storage.
    if (($d['bairro_origem'] ?? '') === 'Demonstração' || ($d['tipo_registro'] ?? '') === 'demonstracao') continue;
    $realCounts[$bairro]++;
}

$items = [];
foreach ($regions as $bairro => $coords) {
    $real = (int)$realCounts[$bairro];
    $demo = (int)$demoCounts[$bairro];
    if ($real + $demo === 0) continue;
    $items[] = [
        'bairro' => $bairro,
        'lat' => $coords['lat'],
        'lng' => $coords['lng'],
        'real_count' => $real,
        'demo_count' => $demo,
        'count' => $real + $demo
    ];
}

$realTotal = array_sum($realCounts);
$demoTotal = array_sum($demoCounts);
echo json_encode([
    'cidade' => 'Ourinhos - SP',
    'real' => $realTotal,
    'demonstracao' => $demoTotal,
    'total' => $realTotal + $demoTotal,
    'atualizado' => date('d/m/Y H:i:s'),
    'fonte' => 'registros deste servidor e exemplos claramente identificados',
    'regioes' => $items,
    'legenda' => ['baixo' => '1 a 5', 'medio' => '6 a 10', 'alto' => 'mais de 10']
], JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
