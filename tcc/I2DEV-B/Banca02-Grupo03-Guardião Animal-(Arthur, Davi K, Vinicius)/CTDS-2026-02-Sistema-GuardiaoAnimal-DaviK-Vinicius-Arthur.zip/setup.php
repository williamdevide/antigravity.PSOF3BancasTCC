<?php
require __DIR__.'/includes/bootstrap.php';
// O cadastro inicial e automatico e nao fica exposto na internet.
redirect('admin/login.php');
