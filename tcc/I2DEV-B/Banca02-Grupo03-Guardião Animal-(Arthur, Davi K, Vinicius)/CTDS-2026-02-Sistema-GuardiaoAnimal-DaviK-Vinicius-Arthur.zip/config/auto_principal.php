<?php
// V34: provisionamento unico do principal, somente se ainda nao houver administradores.
// Nunca exibir a senha em HTML ou versionar credenciais em texto puro.
if (!admin_configured()) {
    mutate_store('admins', static function (&$rows) {
        if ($rows) return false;
        $rows[] = ['id'=>1, 'created_at'=>date('Y-m-d H:i:s'), 'nome'=>'Administrador principal', 'username'=>'principal', 'email'=>'',
        'password_hash'=>'$2y$12$1Uz/9YgkMC4/P1ymmRPFXewv5rFqBqYgVU8a4vhLS/I5VEiFSMBxq', 'tipo'=>'principal', 'status'=>'Ativo'];
        return true;
    });
}
