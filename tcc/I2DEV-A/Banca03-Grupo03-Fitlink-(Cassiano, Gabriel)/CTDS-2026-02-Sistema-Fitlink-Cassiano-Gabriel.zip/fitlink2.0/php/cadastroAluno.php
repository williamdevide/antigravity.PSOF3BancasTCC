
<?php

include "conexao.php";

// ========================================
// FUNÇÃO PARA EXIBIR MENSAGENS
// ========================================

function mensagemRedirecionamento($mensagem, $destino) {

    $msg = json_encode(
        $mensagem,
        JSON_UNESCAPED_UNICODE
    );

    $url = json_encode($destino);

    echo "<script>
        alert($msg);
        window.location.href = $url;
    </script>";

    exit;
}


// ========================================
// VERIFICAR MÉTODO DA REQUISIÇÃO
// ========================================

if ($_SERVER["REQUEST_METHOD"] !== "POST") {

    header("Location: ../html/cadastro.html");
    exit;

}


// ========================================
// RECEBER DADOS DO FORMULÁRIO
// ========================================

$nome = trim($_POST["nome"] ?? "");
$email = trim($_POST["email"] ?? "");
$telefone = trim($_POST["telefone"] ?? "");
$data = trim($_POST["data_nascimento"] ?? "");
$genero = trim($_POST["genero"] ?? "");
$senha = $_POST["senha"] ?? "";


// ========================================
// VALIDAR CAMPOS
// ========================================

if (
    $nome === "" ||
    $email === "" ||
    $senha === ""
) {

    mensagemRedirecionamento(
        "Preencha todos os campos obrigatórios.",
        "../html/cadastro.html"
    );

}

if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {

    mensagemRedirecionamento(
        "Informe um e-mail válido.",
        "../html/cadastro.html"
    );

}


// ========================================
// CADASTRAR ALUNO
// ========================================

try {

    // Verificar se o e-mail já está cadastrado

    $verificar = $conn->prepare(
        "SELECT id_aluno
         FROM tb_cadastroaluno
         WHERE email = ?
         LIMIT 1"
    );

    $verificar->bind_param(
        "s",
        $email
    );

    $verificar->execute();
    $verificar->store_result();

    if ($verificar->num_rows > 0) {

        $verificar->close();

        mensagemRedirecionamento(
            "Este e-mail já está cadastrado! Faça login.",
            "../html/login.html"
        );

    }

    $verificar->close();


    // Criptografar a senha

    $senhaHash = password_hash(
        $senha,
        PASSWORD_DEFAULT
    );


    // Inserir aluno no banco

    $sql = "INSERT INTO tb_cadastroaluno
    (
        nome,
        email,
        telefone,
        data_nascimento,
        genero,
        senha
    )
    VALUES (?, ?, ?, ?, ?, ?)";


    $stmt = $conn->prepare($sql);

    $stmt->bind_param(
        "ssssss",
        $nome,
        $email,
        $telefone,
        $data,
        $genero,
        $senhaHash
    );


    $stmt->execute();

    $stmt->close();


    // Cadastro realizado com sucesso

    mensagemRedirecionamento(
        "Aluno cadastrado com sucesso!",
        "../html/login.html"
    );


} catch (mysqli_sql_exception $erro) {

    // Erro de registro duplicado

    if ($erro->getCode() == 1062) {

        mensagemRedirecionamento(
            "Já existe um cadastro com esses dados.",
            "../html/login.html"
        );

    }


    // Registrar erro técnico no servidor

    error_log(
        $erro->getMessage()
    );


    mensagemRedirecionamento(
        "Não foi possível realizar o cadastro. Tente novamente.",
        "../html/cadastro.html"
    );

}

?>
