<?php

session_start();

header(
    "Content-Type: application/json; charset=UTF-8"
);

require_once "conexao.php";


/* =========================================
   FUNÇÃO DE RESPOSTA
========================================= */

function responder($dados)
{
    echo json_encode(
        $dados,
        JSON_UNESCAPED_UNICODE
    );

    exit;
}


/* =========================================
   VERIFICAR LOGIN DO ALUNO
========================================= */

if (
    !isset($_SESSION["tipo_usuario"]) ||
    $_SESSION["tipo_usuario"] !== "aluno"
) {

    responder([
        "erro" => "Aluno não autenticado."
    ]);

}


$id_aluno =
    (int)(
        $_SESSION["id_aluno"] ??
        0
    );


if ($id_aluno <= 0) {

    responder([
        "erro" => "Aluno não identificado."
    ]);

}


/* =========================================
   AÇÃO
========================================= */

$acao =
    $_GET["acao"]
    ??
    $_POST["acao"]
    ??
    "";


/* =========================================
   LISTAR CONVERSAS
========================================= */

if ($acao === "listar_conversas") {


    $sql = "

        SELECT

            p.id_cref,

            p.nome,

            p.foto,

            ultima.mensagem AS ultima_mensagem,

            ultima.data_envio AS data_ultima,

            (

                SELECT COUNT(*)

                FROM tb_mensagens m2

                WHERE
                    m2.id_aluno = ?
                    AND m2.id_cref = p.id_cref
                    AND m2.remetente IN ('personal','sistema')
                    AND m2.lida = 0

            ) AS nao_lidas

        FROM tb_cadastropersonal p

        INNER JOIN (

            SELECT
                m.id_cref,
                m.mensagem,
                m.data_envio

            FROM tb_mensagens m

            INNER JOIN (

                SELECT

                    id_cref,
                    MAX(id_mensagem) AS id_mensagem

                FROM tb_mensagens

                WHERE id_aluno = ?

                GROUP BY id_cref

            ) ultima_id

                ON ultima_id.id_mensagem =
                   m.id_mensagem

        ) ultima

            ON ultima.id_cref =
               p.id_cref

        ORDER BY
            ultima.data_envio DESC

    ";


    $stmt =
        $conn->prepare($sql);


    if (!$stmt) {

        responder([
            "erro" => $conn->error
        ]);

    }


    $stmt->bind_param(
        "ii",
        $id_aluno,
        $id_aluno
    );


    $stmt->execute();


    $resultado =
        $stmt->get_result();


    $conversas = [];


    while (
        $linha =
        $resultado->fetch_assoc()
    ) {

        $conversas[] = $linha;

    }


    $stmt->close();


    responder($conversas);

}


/* =========================================
   LISTAR MENSAGENS
========================================= */

if ($acao === "listar_mensagens") {


    $id_cref =
        (int)(
            $_GET["id_cref"] ??
            0
        );


    if ($id_cref <= 0) {

        responder([
            "erro" => "Personal não informado."
        ]);

    }


    $stmt =
        $conn->prepare("

            SELECT

                id_mensagem,
                remetente,
                tipo,
                mensagem,
                id_aula,
                data_envio,
                lida

            FROM tb_mensagens

            WHERE
                id_aluno = ?
                AND id_cref = ?

            ORDER BY
                data_envio ASC,
                id_mensagem ASC

        ");


    if (!$stmt) {

        responder([
            "erro" => $conn->error
        ]);

    }


    $stmt->bind_param(
        "ii",
        $id_aluno,
        $id_cref
    );


    $stmt->execute();


    $resultado =
        $stmt->get_result();


    $mensagens = [];


    while (
        $linha =
        $resultado->fetch_assoc()
    ) {

        $mensagens[] =
            $linha;

    }


    $stmt->close();


    /* -----------------------------------------
       MARCAR COMO LIDAS
    ----------------------------------------- */

    $stmt =
        $conn->prepare("

            UPDATE tb_mensagens

            SET lida = 1

            WHERE
                id_aluno = ?
                AND id_cref = ?

                AND remetente IN (
                    'personal',
                    'sistema'
                )

                AND lida = 0

        ");


    if ($stmt) {

        $stmt->bind_param(
            "ii",
            $id_aluno,
            $id_cref
        );

        $stmt->execute();

        $stmt->close();

    }


    responder($mensagens);

}


/* =========================================
   ENVIAR MENSAGEM
========================================= */

if ($acao === "enviar") {


    $id_cref =
        (int)(
            $_POST["id_cref"] ??
            0
        );


    $mensagem =
        trim(
            $_POST["mensagem"] ??
            ""
        );


    $permitidas = [

        "Olá! Gostaria de confirmar minha aula.",

        "Olá! Preciso remarcar minha aula.",

        "Olá! Preciso cancelar minha aula."

    ];


    if (
        $mensagem ===
        "Olá! Gostaria de tirar uma dúvida sobre minha aula."
    ) {

        $permitidas[] =
            $mensagem;

    }


    if (
        $id_cref <= 0 ||
        !in_array(
            $mensagem,
            $permitidas,
            true
        )
    ) {

        responder([
            "erro" => "Mensagem não permitida."
        ]);

    }


    /* -----------------------------------------
       VERIFICAR PERSONAL
    ----------------------------------------- */

    $stmt =
        $conn->prepare("

            SELECT id_cref

            FROM tb_cadastropersonal

            WHERE id_cref = ?

        ");


    $stmt->bind_param(
        "i",
        $id_cref
    );


    $stmt->execute();


    $resultado =
        $stmt->get_result();


    if (
        $resultado->num_rows === 0
    ) {

        $stmt->close();

        responder([
            "erro" => "Personal não encontrado."
        ]);

    }


    $stmt->close();


    /* -----------------------------------------
       DEFINIR TIPO
    ----------------------------------------- */

    if (
        strpos(
            $mensagem,
            "confirmar"
        ) !== false
    ) {

        $tipo =
            "confirmacao";

    } elseif (
        strpos(
            $mensagem,
            "remarcar"
        ) !== false
    ) {

        $tipo =
            "remarcacao";

    } elseif (
        strpos(
            $mensagem,
            "cancelar"
        ) !== false
    ) {

        $tipo =
            "cancelamento";

    } else {

        $tipo =
            "texto";

    }


    /* -----------------------------------------
       PEGAR ÚLTIMA AULA
    ----------------------------------------- */

    $id_aula = null;


    $stmt =
        $conn->prepare("

            SELECT

                a.id_aula

            FROM tb_aulamarcada a

            INNER JOIN tb_agenda g

                ON g.id_agenda =
                   a.id_agenda

            WHERE

                a.id_aluno = ?

                AND g.id_cref = ?

            ORDER BY

                g.dia DESC,
                g.horario DESC,
                a.id_aula DESC

            LIMIT 1

        ");


    if ($stmt) {

        $stmt->bind_param(
            "ii",
            $id_aluno,
            $id_cref
        );


        $stmt->execute();


        $resultado =
            $stmt->get_result();


        if (
            $linha =
            $resultado->fetch_assoc()
        ) {

            $id_aula =
                (int)$linha["id_aula"];

        }


        $stmt->close();

    }


    /* -----------------------------------------
       INSERIR MENSAGEM
    ----------------------------------------- */

    if ($id_aula !== null) {

        $stmt =
            $conn->prepare("

                INSERT INTO tb_mensagens

                (
                    id_aluno,
                    id_cref,
                    remetente,
                    tipo,
                    mensagem,
                    id_aula
                )

                VALUES
                (
                    ?,
                    ?,
                    'aluno',
                    ?,
                    ?,
                    ?
                )

            ");


        $stmt->bind_param(
            "iissi",
            $id_aluno,
            $id_cref,
            $tipo,
            $mensagem,
            $id_aula
        );

    } else {

        $stmt =
            $conn->prepare("

                INSERT INTO tb_mensagens

                (
                    id_aluno,
                    id_cref,
                    remetente,
                    tipo,
                    mensagem
                )

                VALUES
                (
                    ?,
                    ?,
                    'aluno',
                    ?,
                    ?
                )

            ");


        $stmt->bind_param(
            "iiss",
            $id_aluno,
            $id_cref,
            $tipo,
            $mensagem
        );

    }


    if (!$stmt->execute()) {

        $stmt->close();

        responder([
            "erro" => "Não foi possível enviar a mensagem."
        ]);

    }


    $id_mensagem =
        $stmt->insert_id;


    $stmt->close();


    responder([
        "sucesso" => true,
        "id_mensagem" => $id_mensagem
    ]);

}


/* =========================================
   PEGAR TELEFONE DO PERSONAL
========================================= */

if ($acao === "telefone") {


    $id_cref =
        (int)(
            $_POST["id_cref"] ??
            $_GET["id_cref"] ??
            0
        );


    if ($id_cref <= 0) {

        responder([
            "erro" => "Personal não informado."
        ]);

    }


    $stmt =
        $conn->prepare("

            SELECT

                nome,
                telefone

            FROM tb_cadastropersonal

            WHERE id_cref = ?

            LIMIT 1

        ");


    $stmt->bind_param(
        "i",
        $id_cref
    );


    $stmt->execute();


    $resultado =
        $stmt->get_result();


    $personal =
        $resultado->fetch_assoc();


    $stmt->close();


    if (!$personal) {

        responder([
            "erro" => "Personal não encontrado."
        ]);

    }


    responder([

        "sucesso" => true,

        "nome" =>
            $personal["nome"],

        "telefone" =>
            $personal["telefone"]

    ]);

}


/* =========================================
   ACADEMIAS DO PERSONAL
========================================= */

if ($acao === "academias") {


    $id_cref =
        (int)(
            $_GET["id_cref"] ??
            $_POST["id_cref"] ??
            0
        );


    if ($id_cref <= 0) {

        responder([
            "erro" => "Personal não informado."
        ]);

    }


    $stmt =
        $conn->prepare("

            SELECT

                a.id_academia,
                a.nomeacademia,
                a.endereco,
                a.cidade,
                a.estado

            FROM tb_personalacademia pa

            INNER JOIN tb_academia a

                ON a.id_academia =
                   pa.id_academia

            WHERE
                pa.id_cref = ?

            ORDER BY
                a.nomeacademia ASC

        ");


    $stmt->bind_param(
        "i",
        $id_cref
    );


    $stmt->execute();


    $resultado =
        $stmt->get_result();


    $academias = [];


    while (
        $linha =
        $resultado->fetch_assoc()
    ) {

        $academias[] =
            $linha;

    }


    $stmt->close();


    responder($academias);

}


/* =========================================
   REMARCAR AULA
========================================= */

if ($acao === "remarcar") {


    $id_cref =
        (int)(
            $_POST["id_cref"] ??
            0
        );


    $id_agenda_nova =
        (int)(
            $_POST["id_agenda_nova"] ??
            0
        );


    $data_nova =
        trim(
            $_POST["data_nova"] ??
            ""
        );


    $horario_novo =
        trim(
            $_POST["horario_novo"] ??
            ""
        );


    $academia_nova =
        (int)(
            $_POST["academia_nova"] ??
            0
        );


    if (
        $id_cref <= 0 ||
        $id_agenda_nova <= 0 ||
        !$data_nova ||
        !$horario_novo ||
        $academia_nova <= 0
    ) {

        responder([
            "erro" =>
                "Dados da remarcação incompletos."
        ]);

    }


    /* -----------------------------------------
       DATA
    ----------------------------------------- */

    $dataObjeto =
        DateTime::createFromFormat(
            "Y-m-d",
            $data_nova
        );


    if (
        !$dataObjeto ||
        $dataObjeto->format("Y-m-d")
        !==
        $data_nova
    ) {

        responder([
            "erro" =>
                "Data inválida."
        ]);

    }


    /* -----------------------------------------
       INICIAR TRANSAÇÃO
    ----------------------------------------- */

    $conn->begin_transaction();


    try {


        /* -------------------------------------
           LOCALIZAR A AULA ATUAL DO ALUNO
        -------------------------------------- */

        $stmt =
            $conn->prepare("

                SELECT

                    a.id_aula,
                    a.id_agenda

                FROM tb_aulamarcada a

                INNER JOIN tb_agenda g

                    ON g.id_agenda =
                       a.id_agenda

                WHERE

                    a.id_aluno = ?

                    AND g.id_cref = ?

                    AND a.status <> 'cancelada'

                ORDER BY

                    g.dia DESC,
                    g.horario DESC,
                    a.id_aula DESC

                LIMIT 1

                FOR UPDATE

            ");


        $stmt->bind_param(
            "ii",
            $id_aluno,
            $id_cref
        );


        $stmt->execute();


        $resultado =
            $stmt->get_result();


        $aulaAtual =
            $resultado->fetch_assoc();


        $stmt->close();


        if (!$aulaAtual) {

            throw new Exception(
                "Você não possui uma aula para remarcar."
            );

        }


        $id_aula =
            (int)$aulaAtual["id_aula"];


        /* -------------------------------------
           VALIDAR NOVA AGENDA
        -------------------------------------- */

        $stmt =
            $conn->prepare("

                SELECT

                    g.id_agenda,
                    g.dia,
                    g.horario,
                    g.id_cref,
                    g.id_academia

                FROM tb_agenda g

                WHERE

                    g.id_agenda = ?

                    AND g.id_cref = ?

                    AND g.dia = ?

                    AND g.id_academia = ?

                    AND g.horario = ?

                LIMIT 1

            ");


        $stmt->bind_param(
            "iisis",
            $id_agenda_nova,
            $id_cref,
            $data_nova,
            $academia_nova,
            $horario_novo
        );


        $stmt->execute();


        $resultado =
            $stmt->get_result();


        $novaAgenda =
            $resultado->fetch_assoc();


        $stmt->close();


        if (!$novaAgenda) {

            throw new Exception(
                "O novo horário não é válido."
            );

        }


        /* -------------------------------------
           VERIFICAR SE NOVO HORÁRIO ESTÁ OCUPADO
        -------------------------------------- */

        $stmt =
            $conn->prepare("

                SELECT

                    id_aula

                FROM tb_aulamarcada

                WHERE

                    id_agenda = ?

                    AND id_aula <> ?

                    AND status <> 'cancelada'

                LIMIT 1

            ");


        $stmt->bind_param(
            "ii",
            $id_agenda_nova,
            $id_aula
        );


        $stmt->execute();


        $resultado =
            $stmt->get_result();


        if (
            $resultado->num_rows > 0
        ) {

            $stmt->close();

            throw new Exception(
                "Esse horário já está ocupado."
            );

        }


        $stmt->close();


        /* -------------------------------------
           PEGAR DADOS DA AULA NOVA
        -------------------------------------- */

        $nomeAcademia =
            "Academia";


        $stmt =
            $conn->prepare("

                SELECT
                    nomeacademia

                FROM tb_academia

                WHERE id_academia = ?

                LIMIT 1

            ");


        $stmt->bind_param(
            "i",
            $academia_nova
        );


        $stmt->execute();


        $resultado =
            $stmt->get_result();


        if (
            $academia =
            $resultado->fetch_assoc()
        ) {

            $nomeAcademia =
                $academia["nomeacademia"];

        }


        $stmt->close();


        /* -------------------------------------
           ALTERAR AULA
        -------------------------------------- */

        $stmt =
            $conn->prepare("

                UPDATE tb_aulamarcada

                SET

                    id_agenda = ?,
                    status = 'remarcada'

                WHERE

                    id_aula = ?
                    AND id_aluno = ?

            ");


        $stmt->bind_param(
            "iii",
            $id_agenda_nova,
            $id_aula,
            $id_aluno
        );


        if (!$stmt->execute()) {

            $stmt->close();

            throw new Exception(
                "Não foi possível remarcar a aula."
            );

        }


        $stmt->close();


        /* -------------------------------------
           DATA FORMATADA
        -------------------------------------- */

        $dataFormatada =
            $dataObjeto->format(
                "d/m/Y"
            );


        $mensagem =
            "🔄 Aula remarcada para " .
            $dataFormatada .
            " às " .
            substr(
                $horario_novo,
                0,
                5
            ) .
            " na " .
            $nomeAcademia .
            ".";


        /* -------------------------------------
           REGISTRAR NO CHAT
        -------------------------------------- */

        $stmt =
            $conn->prepare("

                INSERT INTO tb_mensagens

                (
                    id_aluno,
                    id_cref,
                    remetente,
                    tipo,
                    mensagem,
                    id_aula
                )

                VALUES

                (
                    ?,
                    ?,
                    'sistema',
                    'remarcacao',
                    ?,
                    ?
                )

            ");


        $stmt->bind_param(
            "iisi",
            $id_aluno,
            $id_cref,
            $mensagem,
            $id_aula
        );


        if (!$stmt->execute()) {

            $stmt->close();

            throw new Exception(
                "A aula foi alterada, mas não foi possível registrar a mensagem."
            );

        }


        $stmt->close();


        /* -------------------------------------
           CONFIRMAR
        -------------------------------------- */

        $conn->commit();


        responder([

            "sucesso" => true,

            "mensagem" =>
                $mensagem,

            "id_aula" =>
                $id_aula

        ]);

    } catch (Throwable $erro) {


        $conn->rollback();


        responder([

            "erro" =>
                $erro->getMessage()

        ]);

    }

}


/* =========================================
   AÇÃO INVÁLIDA
========================================= */

responder([
    "erro" => "Ação inválida."
]);

?>