
<?php

session_start();

header("Content-Type: application/json; charset=UTF-8");

require_once __DIR__ . "/conexao.php";

// Verificar autenticação
if (
    ($_SESSION["tipo_usuario"] ?? "") !== "personal"
) {
    http_response_code(401);

    echo json_encode([
        "erro" => "Personal não autenticado."
    ]);

    exit;
}

$id_cref = (int)($_SESSION["id_cref"] ?? 0);

if ($id_cref <= 0) {
    http_response_code(401);

    echo json_encode([
        "erro" => "CREF não identificado."
    ]);

    exit;
}

try {

    // Contar mensagens de alunos não lidas
    $sql = "
        SELECT COUNT(*) AS total
        FROM tb_mensagens
        WHERE id_cref = ?
          AND remetente = 'aluno'
          AND lida = 0
    ";

    $stmt = $conn->prepare($sql);

    $stmt->bind_param("i", $id_cref);

    $stmt->execute();

    $resultado = $stmt->get_result();

    $linha = $resultado->fetch_assoc();

    echo json_encode([
        "sucesso" => true,
        "total" => (int)($linha["total"] ?? 0)
    ]);

    $stmt->close();

} catch (Throwable $erro) {

    error_log($erro->getMessage());

    http_response_code(500);

    echo json_encode([
        "erro" => "Erro ao consultar notificações."
    ]);
}

$conn->close();

?>
