<?php

session_start();

header("Content-Type: application/json; charset=UTF-8");

require_once __DIR__ . "/conexao.php";


// ==================================================
// FUNÇÃO DE RESPOSTA
// ==================================================

function responder($dados)
{
    echo json_encode(
        $dados,
        JSON_UNESCAPED_UNICODE
    );

    exit;
}


// ==================================================
// CONVERTER HORÁRIO PARA MINUTOS
// ==================================================

function horaParaMinutos($hora)
{
    $partes = explode(":", $hora);

    return (
        ((int)$partes[0] * 60)
        +
        (int)$partes[1]
    );
}


// ==================================================
// VERIFICAR CONEXÃO
// ==================================================

if (!isset($conn)) {

    responder([
        "erro" => "Conexão com o banco de dados não encontrada."
    ]);
}


// ==================================================
// PEGAR CREF
// ==================================================

$id_cref =
    $_GET["id_cref"]
    ?? $_GET["cref"]
    ?? $_POST["id_cref"]
    ?? $_POST["cref"]
    ?? null;


if (!$id_cref) {

    responder([
        "erro" => "CREF do profissional não informado."
    ]);
}


// ==================================================
// AÇÃO
// ==================================================

$acao =
    $_GET["acao"]
    ?? $_POST["acao"]
    ?? "";


// ==================================================
// DADOS DO PERSONAL
// ==================================================

if ($acao === "dados_personal") {

    $sql = "
        SELECT
            id_cref,
            nome,
            foto
        FROM tb_cadastropersonal
        WHERE id_cref = ?
        LIMIT 1
    ";

    $stmt = $conn->prepare($sql);

    if (!$stmt) {

        responder([
            "erro" => "Erro ao consultar o profissional."
        ]);
    }

    $stmt->bind_param(
        "i",
        $id_cref
    );

    $stmt->execute();

    $resultado = $stmt->get_result();

    $personal = $resultado->fetch_assoc();

    $stmt->close();

    if (!$personal) {

        responder([
            "erro" => "Profissional não encontrado."
        ]);
    }

    responder([
        "nome" => $personal["nome"],
        "id_cref" => $personal["id_cref"],
        "foto" => $personal["foto"] ?? null
    ]);
}


// ==================================================
// ACADEMIAS DO PERSONAL
// ==================================================

if ($acao === "academias") {

    $sql = "
        SELECT
            a.id_academia,
            a.nomeacademia,
            a.endereco,
            a.cidade,
            a.estado

        FROM tb_academia a

        INNER JOIN tb_personalacademia pa
            ON pa.id_academia = a.id_academia

        WHERE pa.id_cref = ?

        ORDER BY a.nomeacademia
    ";

    $stmt = $conn->prepare($sql);

    if (!$stmt) {

        responder([
            "erro" => "Erro ao consultar academias."
        ]);
    }

    $stmt->bind_param(
        "i",
        $id_cref
    );

    $stmt->execute();

    $resultado = $stmt->get_result();

    $academias = [];

    while ($linha = $resultado->fetch_assoc()) {

        $academias[] = $linha;
    }

    $stmt->close();

    responder($academias);
}


// ==================================================
// HORÁRIOS
// ==================================================

if ($acao === "horarios") {

    $academia =
        isset($_GET["academia"])
        ? (int)$_GET["academia"]
        : 0;

    $data =
        $_GET["data"] ?? "";


    if (!$academia || !$data) {

        responder([
            "erro" => "Academia e data são obrigatórios."
        ]);
    }


    // ==================================================
    // VALIDAR DATA
    // ==================================================

    $dataObjeto =
        DateTime::createFromFormat(
            "Y-m-d",
            $data
        );

    if (
        !$dataObjeto ||
        $dataObjeto->format("Y-m-d") !== $data
    ) {

        responder([
            "erro" => "Data inválida."
        ]);
    }


    // ==================================================
    // NÃO PERMITIR DATA PASSADA
    // ==================================================

    $hoje =
        new DateTime(
            date("Y-m-d")
        );


    if ($dataObjeto < $hoje) {

        responder([
            "erro" =>
                "Não é possível agendar aulas em uma data passada."
        ]);
    }


    // ==================================================
    // VERIFICAR SE A ACADEMIA PERTENCE AO PERSONAL
    // ==================================================

    $sqlAcademia = "
        SELECT 1

        FROM tb_personalacademia

        WHERE
            id_cref = ?
            AND id_academia = ?

        LIMIT 1
    ";

    $stmtAcademia =
        $conn->prepare($sqlAcademia);

    if (!$stmtAcademia) {

        responder([
            "erro" =>
                "Erro ao verificar a academia."
        ]);
    }

    $stmtAcademia->bind_param(
        "ii",
        $id_cref,
        $academia
    );

    $stmtAcademia->execute();

    $resultadoAcademia =
        $stmtAcademia->get_result();

    if ($resultadoAcademia->num_rows === 0) {

        $stmtAcademia->close();

        responder([
            "erro" =>
                "Esta academia não está vinculada ao profissional."
        ]);
    }

    $stmtAcademia->close();


    // ==================================================
    // DIA DA SEMANA
    // ==================================================

    // 1 = Segunda
    // 2 = Terça
    // 3 = Quarta
    // 4 = Quinta
    // 5 = Sexta
    // 6 = Sábado
    // 7 = Domingo

    $diaSemana =
        (int)$dataObjeto->format("N");


    // ==================================================
    // BUSCAR DISPONIBILIDADE DO PERSONAL
    // ==================================================

    $sqlDisponibilidade = "
        SELECT
            horario,
            id_academia

        FROM tb_disponibilidade

        WHERE
            id_cref = ?
            AND dia_semana = ?
            AND id_academia = ?

        ORDER BY horario
    ";

    $stmtDisponibilidade =
        $conn->prepare(
            $sqlDisponibilidade
        );

    if (!$stmtDisponibilidade) {

        responder([
            "erro" =>
                "Erro ao consultar disponibilidade."
        ]);
    }

    $stmtDisponibilidade->bind_param(
        "iii",
        $id_cref,
        $diaSemana,
        $academia
    );

    $stmtDisponibilidade->execute();

    $resultadoDisponibilidade =
        $stmtDisponibilidade->get_result();

    $disponibilidades = [];

    while (
        $linha =
        $resultadoDisponibilidade->fetch_assoc()
    ) {

        $disponibilidades[] =
            $linha;
    }

    $stmtDisponibilidade->close();


    // ==================================================
    // NÃO EXISTE HORÁRIO CONFIGURADO
    // ==================================================

    if (count($disponibilidades) === 0) {

        responder([
            "total" => 0,
            "disponiveis" => 0,
            "horarios" => []
        ]);
    }


    // ==================================================
    // CRIAR OS HORÁRIOS NA TB_AGENDA
    // ==================================================

    foreach (
        $disponibilidades as $disp
    ) {

        $horario =
            $disp["horario"];


        // Verificar se já existe

        $sqlExiste = "
            SELECT
                id_agenda

            FROM tb_agenda

            WHERE
                id_cref = ?
                AND dia = ?
                AND horario = ?
                AND id_academia = ?

            LIMIT 1
        ";

        $stmtExiste =
            $conn->prepare(
                $sqlExiste
            );

        $stmtExiste->bind_param(
            "issi",
            $id_cref,
            $data,
            $horario,
            $academia
        );

        $stmtExiste->execute();

        $resultadoExiste =
            $stmtExiste->get_result();

        $existe =
            $resultadoExiste->fetch_assoc();

        $stmtExiste->close();


        // Se não existir, criar

        if (!$existe) {

            $sqlInsert = "
                INSERT INTO tb_agenda
                (
                    dia,
                    horario,
                    id_academia,
                    id_cref
                )

                VALUES
                (
                    ?,
                    ?,
                    ?,
                    ?
                )
            ";

            $stmtInsert =
                $conn->prepare(
                    $sqlInsert
                );

            $stmtInsert->bind_param(
                "ssii",
                $data,
                $horario,
                $academia,
                $id_cref
            );

            $stmtInsert->execute();

            $stmtInsert->close();
        }
    }


    // ==================================================
    // REMOVER HORÁRIOS QUE NÃO ESTÃO MAIS DISPONÍVEIS
    // ==================================================

    $sqlLimpeza = "
        DELETE a

        FROM tb_agenda a

        WHERE
            a.id_cref = ?
            AND a.dia = ?
            AND a.id_academia = ?

            AND NOT EXISTS (

                SELECT 1

                FROM tb_disponibilidade d

                WHERE
                    d.id_cref = a.id_cref
                    AND d.dia_semana = ?
                    AND d.id_academia = a.id_academia
                    AND d.horario = a.horario
            )

            AND NOT EXISTS (

                SELECT 1

                FROM tb_aulamarcada am

                WHERE
                    am.id_agenda = a.id_agenda
            )
    ";

    $stmtLimpeza =
        $conn->prepare(
            $sqlLimpeza
        );

    $stmtLimpeza->bind_param(
        "isii",
        $id_cref,
        $data,
        $academia,
        $diaSemana
    );

    $stmtLimpeza->execute();

    $stmtLimpeza->close();


    // ==================================================
    // BUSCAR AGENDA DO DIA
    // ==================================================

    $sqlAgenda = "
        SELECT
            a.id_agenda,
            a.dia,
            a.horario,
            a.id_academia,
            ac.nomeacademia

        FROM tb_agenda a

        INNER JOIN tb_academia ac
            ON ac.id_academia =
               a.id_academia

        WHERE
            a.id_cref = ?
            AND a.dia = ?
            AND a.id_academia = ?

        ORDER BY a.horario
    ";

    $stmtAgenda =
        $conn->prepare(
            $sqlAgenda
        );

    $stmtAgenda->bind_param(
        "isi",
        $id_cref,
        $data,
        $academia
    );

    $stmtAgenda->execute();

    $resultadoAgenda =
        $stmtAgenda->get_result();

    $agendas = [];

    while (
        $linha =
        $resultadoAgenda->fetch_assoc()
    ) {

        $agendas[] =
            $linha;
    }

    $stmtAgenda->close();


    // ==================================================
    // BUSCAR TODAS AS AULAS DO PERSONAL NA DATA
    // ==================================================

    $sqlAulas = "
        SELECT
            a.horario,
            a.id_academia

        FROM tb_aulamarcada am

        INNER JOIN tb_agenda a
            ON a.id_agenda =
               am.id_agenda

        WHERE
            a.id_cref = ?
            AND a.dia = ?
            AND am.status = 'marcada'
    ";

    $stmtAulas =
        $conn->prepare(
            $sqlAulas
        );

    $stmtAulas->bind_param(
        "is",
        $id_cref,
        $data
    );

    $stmtAulas->execute();

    $resultadoAulas =
        $stmtAulas->get_result();

    $aulasMarcadas = [];

    while (
        $linha =
        $resultadoAulas->fetch_assoc()
    ) {

        $aulasMarcadas[] =
            $linha;
    }

    $stmtAulas->close();


    // ==================================================
    // ANALISAR HORÁRIOS
    // ==================================================

    $horarios = [];


    foreach (
        $agendas as $agenda
    ) {

        $horaInicio =
            $agenda["horario"];


        $inicio =
            horaParaMinutos(
                $horaInicio
            );


        // Cada aula possui 1 hora

        $fim =
            $inicio + 60;


        $status =
            "disponivel";


        // ==================================================
        // SE FOR HOJE, HORÁRIO JÁ PASSADO
        // ==================================================

        if (
            $data === date("Y-m-d")
        ) {

            $horaAtual =
                (
                    ((int)date("H")) * 60
                    +
                    (int)date("i")
                );


            if ($inicio <= $horaAtual) {

                $status =
                    "ocupado";
            }
        }


        // ==================================================
        // VERIFICAR CONFLITOS
        // ==================================================

        foreach (
            $aulasMarcadas as $aula
        ) {

            $inicioAula =
                horaParaMinutos(
                    $aula["horario"]
                );


            $fimAula =
                $inicioAula + 60;


            $academiaAula =
                (int)$aula["id_academia"];


            // ==================================================
            // MESMA ACADEMIA
            // ==================================================

            if (
                $academiaAula ===
                (int)$academia
            ) {

                if (
                    $inicio < $fimAula &&
                    $fim > $inicioAula
                ) {

                    $status =
                        "ocupado";

                    break;
                }
            }


            // ==================================================
            // ACADEMIA DIFERENTE
            // ==================================================

            else {

                // 30 minutos de deslocamento

                $inicioComMargem =
                    $inicioAula - 30;

                $fimComMargem =
                    $fimAula + 30;


                if (
                    $inicio < $fimComMargem &&
                    $fim > $inicioComMargem
                ) {

                    if (
                        $status ===
                        "disponivel"
                    ) {

                        $status =
                            "deslocamento";
                    }
                }
            }
        }


        // ==================================================
        // HORA FINAL
        // ==================================================

        $horaFimMinutos =
            $inicio + 60;


        $horaFim =
            sprintf(
                "%02d:%02d",
                floor(
                    $horaFimMinutos / 60
                ),
                $horaFimMinutos % 60
            );


        $horarios[] = [

            "id_agenda" =>
                (int)$agenda["id_agenda"],

            "hora_inicio" =>
                substr(
                    $horaInicio,
                    0,
                    5
                ),

            "hora_fim" =>
                $horaFim,

            "nomeacademia" =>
                $agenda["nomeacademia"],

            "status" =>
                $status
        ];
    }


    // ==================================================
    // CONTADORES
    // ==================================================

    $total =
        count($horarios);


    $disponiveis = 0;


    foreach (
        $horarios as $horario
    ) {

        if (
            $horario["status"] ===
            "disponivel"
        ) {

            $disponiveis++;
        }
    }


    responder([

        "total" =>
            $total,

        "disponiveis" =>
            $disponiveis,

        "horarios" =>
            $horarios
    ]);
}


// ==================================================
// AGENDAR AULA
// ==================================================

if ($acao === "agendar") {


    // ==================================================
    // VERIFICAR LOGIN DO ALUNO
    // ==================================================

    if (
        !isset(
            $_SESSION["tipo_usuario"]
        )
        ||
        $_SESSION["tipo_usuario"] !==
        "aluno"
    ) {

        responder([
            "sucesso" => false,
            "erro" =>
                "Você precisa estar logado como aluno."
        ]);
    }


    $id_aluno =
        $_SESSION["id_aluno"]
        ?? null;


    if (!$id_aluno) {

        responder([
            "sucesso" => false,
            "erro" =>
                "Aluno não identificado."
        ]);
    }


    // ==================================================
    // ID DA AGENDA
    // ==================================================

    $id_agenda =
        isset($_POST["id_agenda"])
        ? (int)$_POST["id_agenda"]
        : 0;


    if (!$id_agenda) {

        responder([
            "sucesso" => false,
            "erro" =>
                "Horário não informado."
        ]);
    }


    // ==================================================
    // TRANSAÇÃO
    // ==================================================

    $conn->begin_transaction();


    try {


        // ==================================================
        // PEGAR A AGENDA
        // ==================================================

        $sqlAgenda = "
            SELECT
                a.id_agenda,
                a.dia,
                a.horario,
                a.id_cref,
                a.id_academia

            FROM tb_agenda a

            WHERE
                a.id_agenda = ?
                AND a.id_cref = ?

            LIMIT 1

            FOR UPDATE
        ";

        $stmtAgenda =
            $conn->prepare(
                $sqlAgenda
            );

        $stmtAgenda->bind_param(
            "ii",
            $id_agenda,
            $id_cref
        );

        $stmtAgenda->execute();

        $resultadoAgenda =
            $stmtAgenda->get_result();

        $agenda =
            $resultadoAgenda->fetch_assoc();

        $stmtAgenda->close();


        if (!$agenda) {

            throw new Exception(
                "Horário não encontrado."
            );
        }


        // ==================================================
        // DATA PASSADA
        // ==================================================

        if (
            $agenda["dia"] <
            date("Y-m-d")
        ) {

            throw new Exception(
                "Não é possível agendar uma data passada."
            );
        }


        // ==================================================
        // VERIFICAR SE JÁ ESTÁ OCUPADO
        // ==================================================

        $sqlOcupado = "
            SELECT
                id_aula

            FROM tb_aulamarcada

            WHERE
                id_agenda = ?
                AND status = 'marcada'

            LIMIT 1

            FOR UPDATE
        ";

        $stmtOcupado =
            $conn->prepare(
                $sqlOcupado
            );

        $stmtOcupado->bind_param(
            "i",
            $id_agenda
        );

        $stmtOcupado->execute();

        $resultadoOcupado =
            $stmtOcupado->get_result();


        if (
            $resultadoOcupado->num_rows > 0
        ) {

            $stmtOcupado->close();

            throw new Exception(
                "Este horário acabou de ser reservado por outro aluno."
            );
        }

        $stmtOcupado->close();


        // ==================================================
        // VERIFICAR DISPONIBILIDADE ATUAL
        // ==================================================

        $dataObjeto =
            new DateTime(
                $agenda["dia"]
            );


        $diaSemana =
            (int)$dataObjeto->format("N");


        $sqlDisponivel = "
            SELECT
                id_disponibilidade

            FROM tb_disponibilidade

            WHERE
                id_cref = ?
                AND dia_semana = ?
                AND horario = ?
                AND id_academia = ?

            LIMIT 1
        ";

        $stmtDisponivel =
            $conn->prepare(
                $sqlDisponivel
            );

        $stmtDisponivel->bind_param(
            "iisi",
            $id_cref,
            $diaSemana,
            $agenda["horario"],
            $agenda["id_academia"]
        );

        $stmtDisponivel->execute();

        $resultadoDisponivel =
            $stmtDisponivel->get_result();


        if (
            $resultadoDisponivel->num_rows === 0
        ) {

            $stmtDisponivel->close();

            throw new Exception(
                "Este horário não está mais disponível."
            );
        }

        $stmtDisponivel->close();


        // ==================================================
        // PEGAR OUTRAS AULAS DO PERSONAL
        // ==================================================

        $sqlConflitos = "
            SELECT
                a.horario,
                a.id_academia

            FROM tb_aulamarcada am

            INNER JOIN tb_agenda a
                ON a.id_agenda =
                   am.id_agenda

            WHERE
                a.id_cref = ?
                AND a.dia = ?
                AND am.status = 'marcada'
        ";

        $stmtConflitos =
            $conn->prepare(
                $sqlConflitos
            );

        $stmtConflitos->bind_param(
            "is",
            $id_cref,
            $agenda["dia"]
        );

        $stmtConflitos->execute();

        $resultadoConflitos =
            $stmtConflitos->get_result();


        $inicioCandidato =
            horaParaMinutos(
                $agenda["horario"]
            );


        $fimCandidato =
            $inicioCandidato + 60;


        while (
            $conflito =
            $resultadoConflitos->fetch_assoc()
        ) {

            $inicioExistente =
                horaParaMinutos(
                    $conflito["horario"]
                );


            $fimExistente =
                $inicioExistente + 60;


            $mesmaAcademia =
                (
                    (int)$conflito["id_academia"]
                    ===
                    (int)$agenda["id_academia"]
                );


            // ==================================================
            // MESMA ACADEMIA
            // ==================================================

            if ($mesmaAcademia) {

                if (
                    $inicioCandidato < $fimExistente &&
                    $fimCandidato > $inicioExistente
                ) {

                    $stmtConflitos->close();

                    throw new Exception(
                        "O profissional já possui uma aula nesse horário."
                    );
                }
            }


            // ==================================================
            // ACADEMIA DIFERENTE
            // ==================================================

            else {

                $inicioComMargem =
                    $inicioExistente - 30;


                $fimComMargem =
                    $fimExistente + 30;


                if (
                    $inicioCandidato < $fimComMargem &&
                    $fimCandidato > $inicioComMargem
                ) {

                    $stmtConflitos->close();

                    throw new Exception(
                        "Este horário não pode ser agendado porque o profissional precisa de 30 minutos para se deslocar entre academias."
                    );
                }
            }
        }


        $stmtConflitos->close();


        // ==================================================
        // LOCALIZAR CONTRATO / PLANO DO ALUNO
        // ==================================================

        /*
            A aula precisa ficar vinculada ao contrato para que,
            quando o Personal confirmar a aula, o sistema saiba
            exatamente qual plano deve entrar no financeiro.

            Procuramos um contrato deste aluno cujo plano pertença
            ao Personal selecionado.

            Damos preferência a um contrato ainda não confirmado.
        */

        $sqlContrato = "

            SELECT
                c.id_contrato

            FROM tb_contrato c

            INNER JOIN tb_planos p
                ON p.id_plano = c.id_plano

            WHERE
                c.id_aluno = ?
                AND p.id_cref = ?

            ORDER BY
                c.confirmado ASC,
                c.data_contratacao DESC,
                c.id_contrato DESC

            LIMIT 1

            FOR UPDATE
        ";


        $stmtContrato =
            $conn->prepare(
                $sqlContrato
            );


        if (!$stmtContrato) {

            throw new Exception(
                "Erro ao localizar o plano contratado."
            );
        }


        $stmtContrato->bind_param(
            "ii",
            $id_aluno,
            $id_cref
        );


        if (!$stmtContrato->execute()) {

            $stmtContrato->close();

            throw new Exception(
                "Não foi possível verificar o plano contratado."
            );
        }


        $resultadoContrato =
            $stmtContrato->get_result();


        $contrato =
            $resultadoContrato->fetch_assoc();


        $stmtContrato->close();


        if (!$contrato) {

            throw new Exception(
                "Você não possui um plano contratado com este Personal."
            );
        }


        $id_contrato =
            (int)$contrato["id_contrato"];


        // ==================================================
        // REGISTRAR AGENDAMENTO
        // ==================================================

        $sqlInserir = "
            INSERT INTO tb_aulamarcada
            (
                id_agenda,
                id_aluno,
                id_contrato,
                status
            )

            VALUES
            (
                ?,
                ?,
                ?,
                'pendente'
            )
        ";

        $stmtInserir =
            $conn->prepare(
                $sqlInserir
            );


        if (!$stmtInserir) {

            throw new Exception(
                "Erro ao preparar o agendamento."
            );
        }


        $stmtInserir->bind_param(
            "iii",
            $id_agenda,
            $id_aluno,
            $id_contrato
        );


        if (
            !$stmtInserir->execute()
        ) {

            $stmtInserir->close();

            throw new Exception(
                "Não foi possível registrar a aula."
            );
        }


        // ==================================================
        // PEGAR ID DA AULA CRIADA
        // ==================================================

        $id_aula =
            $stmtInserir->insert_id;


        $stmtInserir->close();


        // ==================================================
        // BUSCAR NOME DA ACADEMIA
        // ==================================================

        $sqlAcademiaMensagem = "
            SELECT
                nomeacademia

            FROM tb_academia

            WHERE id_academia = ?

            LIMIT 1
        ";


        $stmtAcademiaMensagem =
            $conn->prepare(
                $sqlAcademiaMensagem
            );


        $nomeAcademia =
            "Academia";


        if ($stmtAcademiaMensagem) {

            $stmtAcademiaMensagem->bind_param(
                "i",
                $agenda["id_academia"]
            );

            $stmtAcademiaMensagem->execute();

            $resultadoAcademiaMensagem =
                $stmtAcademiaMensagem->get_result();

            $academiaMensagem =
                $resultadoAcademiaMensagem->fetch_assoc();


            if ($academiaMensagem) {

                $nomeAcademia =
                    $academiaMensagem["nomeacademia"];
            }


            $stmtAcademiaMensagem->close();
        }


        // ==================================================
        // FORMATAR DATA E HORÁRIO
        // ==================================================

        $dataMensagem =
            DateTime::createFromFormat(
                "Y-m-d",
                $agenda["dia"]
            );


        $dataFormatada =
            $dataMensagem
            ? $dataMensagem->format("d/m/Y")
            : $agenda["dia"];


        $horarioFormatado =
            substr(
                $agenda["horario"],
                0,
                5
            );


        // ==================================================
        // CRIAR MENSAGEM AUTOMÁTICA
        // ==================================================

        $mensagemSistema =
            "Aula agendada com sucesso para "
            . $dataFormatada
            . " às "
            . $horarioFormatado
            . " na "
            . $nomeAcademia
            . ".";


        // ==================================================
        // SALVAR MENSAGEM NA CONVERSA
        // ==================================================

        $sqlMensagem = "
            INSERT INTO tb_mensagens
            (
                id_aluno,
                id_cref,
                remetente,
                tipo,
                mensagem,
                id_aula
            )

            VALUES
            (
                ?,
                ?,
                'sistema',
                'agendamento',
                ?,
                ?
            )
        ";


        $stmtMensagem =
            $conn->prepare(
                $sqlMensagem
            );


        if (!$stmtMensagem) {

            throw new Exception(
                "Erro ao preparar a mensagem automática."
            );
        }


        $stmtMensagem->bind_param(
            "iisi",
            $id_aluno,
            $id_cref,
            $mensagemSistema,
            $id_aula
        );


        if (
            !$stmtMensagem->execute()
        ) {

            $stmtMensagem->close();

            throw new Exception(
                "A aula foi criada, mas não foi possível registrar a mensagem."
            );
        }


        $stmtMensagem->close();


        // ==================================================
        // CONFIRMAR TRANSAÇÃO
        // ==================================================

        $conn->commit();


        responder([
            "sucesso" => true,
            "mensagem" =>
                "Aula agendada com sucesso!"
        ]);
    }


    catch (
        Exception $e
    ) {

        $conn->rollback();


        responder([
            "sucesso" => false,
            "erro" =>
                $e->getMessage()
        ]);
    }
}


// ==================================================
// AÇÃO INVÁLIDA
// ==================================================

responder([
    "erro" => "Ação inválida."
]);

?>