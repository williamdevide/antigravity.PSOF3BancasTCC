<?php

session_start();

header('Content-Type: application/json; charset=UTF-8');

require_once __DIR__ . '/conexao.php';

function responder($dados)
{
    echo json_encode($dados, JSON_UNESCAPED_UNICODE);
    exit;
}

$acao = $_GET['acao'] ?? $_POST['acao'] ?? '';
$tipo = $_SESSION['tipo_usuario'] ?? '';

if ($tipo === 'aluno') {

    $id_aluno = (int)($_SESSION['id_aluno'] ?? 0);

    if (!$id_aluno) {
        responder(['erro' => 'Aluno não identificado.']);
    }

    /* Lista os Personais com quem o aluno já teve aula realizada. */
    if ($acao === 'listar_personais') {

        $sql = "
            SELECT
                p.id_cref,
                p.nome,
                p.foto,
                MAX(TIMESTAMP(ag.dia, ag.horario)) AS ultima_aula,
                f.id_feedback,
                f.avaliacao,
                f.relato
            FROM tb_aulamarcada am
            INNER JOIN tb_agenda ag
                ON ag.id_agenda = am.id_agenda
            INNER JOIN tb_cadastropersonal p
                ON p.id_cref = ag.id_cref
            LEFT JOIN tb_feedbacks f
                ON f.id_aluno = am.id_aluno
               AND f.id_cref = ag.id_cref
            WHERE am.id_aluno = ?
              AND am.status = 'confirmada'
              AND TIMESTAMP(ag.dia, ag.horario) < NOW()
            GROUP BY
                p.id_cref, p.nome, p.foto,
                f.id_feedback, f.avaliacao, f.relato
            ORDER BY ultima_aula DESC
        ";

        $stmt = $conn->prepare($sql);
        $stmt->bind_param('i', $id_aluno);
        $stmt->execute();
        $resultado = $stmt->get_result();

        $personais = [];

        while ($linha = $resultado->fetch_assoc()) {
            $personais[] = [
                'id_cref' => (int)$linha['id_cref'],
                'nome' => $linha['nome'],
                'foto' => $linha['foto'],
                'ultima_aula' => $linha['ultima_aula'],
                'feedback' => $linha['id_feedback'] ? [
                    'id_feedback' => (int)$linha['id_feedback'],
                    'avaliacao' => (int)$linha['avaliacao'],
                    'relato' => $linha['relato']
                ] : null
            ];
        }

        $stmt->close();

        responder([
            'sucesso' => true,
            'personais' => $personais
        ]);
    }

    $id_cref = (int)($_GET['id_cref'] ?? $_POST['id_cref'] ?? 0);

    if (!$id_cref) {
        responder(['erro' => 'Personal não informado.']);
    }

    if ($acao === 'situacao') {

        $sql = "
            SELECT COUNT(*) AS total
            FROM tb_aulamarcada am
            INNER JOIN tb_agenda ag ON ag.id_agenda = am.id_agenda
            WHERE am.id_aluno = ?
              AND ag.id_cref = ?
              AND am.status = 'confirmada'
              AND TIMESTAMP(ag.dia, ag.horario) < NOW()
        ";

        $stmt = $conn->prepare($sql);
        $stmt->bind_param('ii', $id_aluno, $id_cref);
        $stmt->execute();
        $resultado = $stmt->get_result()->fetch_assoc();
        $teveAula = (int)$resultado['total'] > 0;
        $stmt->close();

        $sql = "
            SELECT id_feedback, avaliacao, relato
            FROM tb_feedbacks
            WHERE id_aluno = ? AND id_cref = ?
            ORDER BY id_feedback DESC
            LIMIT 1
        ";

        $stmt = $conn->prepare($sql);
        $stmt->bind_param('ii', $id_aluno, $id_cref);
        $stmt->execute();
        $feedback = $stmt->get_result()->fetch_assoc();
        $stmt->close();

        responder([
            'pode_avaliar' => $teveAula,
            'feedback' => $feedback ?: null
        ]);
    }

    if ($acao === 'salvar') {

        $avaliacao = (int)($_POST['avaliacao'] ?? 0);
        $relato = trim($_POST['relato'] ?? '');

        if ($avaliacao < 1 || $avaliacao > 5) {
            responder(['erro' => 'Escolha uma avaliação de 1 a 5 estrelas.']);
        }

        if (mb_strlen($relato) < 3 || mb_strlen($relato) > 500) {
            responder(['erro' => 'O comentário deve ter entre 3 e 500 caracteres.']);
        }

        $sql = "
            SELECT
                am.id_contrato,
                c.id_plano
            FROM tb_aulamarcada am
            INNER JOIN tb_agenda ag
                ON ag.id_agenda = am.id_agenda
            LEFT JOIN tb_contrato c
                ON c.id_contrato = am.id_contrato
            WHERE am.id_aluno = ?
              AND ag.id_cref = ?
              AND am.status = 'confirmada'
              AND TIMESTAMP(ag.dia, ag.horario) < NOW()
            ORDER BY ag.dia DESC, ag.horario DESC
            LIMIT 1
        ";

        $stmt = $conn->prepare($sql);
        $stmt->bind_param('ii', $id_aluno, $id_cref);
        $stmt->execute();
        $aula = $stmt->get_result()->fetch_assoc();
        $stmt->close();

        if (!$aula) {
            responder([
                'erro' => 'O feedback é liberado depois de uma aula confirmada e realizada com este Personal.'
            ]);
        }

        $id_plano = (int)($aula['id_plano'] ?? 0);

        /* Compatibilidade com aulas antigas sem id_contrato: busca um plano do Personal. */
        if (!$id_plano) {
            $sql = "
                SELECT id_plano
                FROM tb_planos
                WHERE id_cref = ?
                ORDER BY id_plano ASC
                LIMIT 1
            ";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param('i', $id_cref);
            $stmt->execute();
            $plano = $stmt->get_result()->fetch_assoc();
            $stmt->close();

            $id_plano = (int)($plano['id_plano'] ?? 0);
        }

        if (!$id_plano) {
            responder(['erro' => 'Não foi possível identificar o plano deste Personal.']);
        }

        $sql = "
            SELECT id_feedback
            FROM tb_feedbacks
            WHERE id_aluno = ? AND id_cref = ?
            ORDER BY id_feedback DESC
            LIMIT 1
        ";

        $stmt = $conn->prepare($sql);
        $stmt->bind_param('ii', $id_aluno, $id_cref);
        $stmt->execute();
        $feedbackAnterior = $stmt->get_result()->fetch_assoc();
        $stmt->close();

        if ($feedbackAnterior) {
            $sql = "
                UPDATE tb_feedbacks
                SET avaliacao = ?, relato = ?, id_plano = ?
                WHERE id_feedback = ?
            ";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param(
                'isii',
                $avaliacao,
                $relato,
                $id_plano,
                $feedbackAnterior['id_feedback']
            );
        } else {
            /*
             * A coluna foto pertence ao feedback antigo e é NOT NULL no banco.
             * Guardamos blob vazio; a tela do Personal usa a foto atual do cadastro do aluno.
             */
            $fotoVazia = '';
            $sql = "
                INSERT INTO tb_feedbacks
                    (relato, id_aluno, id_cref, avaliacao, foto, id_plano)
                VALUES
                    (?, ?, ?, ?, ?, ?)
            ";
            $stmt = $conn->prepare($sql);
            $stmt->bind_param(
                'siiisi',
                $relato,
                $id_aluno,
                $id_cref,
                $avaliacao,
                $fotoVazia,
                $id_plano
            );
        }

        if (!$stmt->execute()) {
            responder(['erro' => 'Não foi possível salvar o feedback.']);
        }

        $stmt->close();

        responder([
            'sucesso' => true,
            'mensagem' => 'Feedback salvo com sucesso!'
        ]);
    }

    responder(['erro' => 'Ação inválida.']);
}

if ($tipo === 'personal') {

    $id_cref = (int)($_SESSION['id_cref'] ?? 0);

    if (!$id_cref) {
        responder(['erro' => 'Personal não identificado.']);
    }

    if ($acao === 'listar') {

        $sql = "
            SELECT
                f.id_feedback,
                f.avaliacao,
                f.relato,
                a.id_aluno,
                a.nome,
                a.foto
            FROM tb_feedbacks f
            INNER JOIN tb_cadastroaluno a
                ON a.id_aluno = f.id_aluno
            WHERE f.id_cref = ?
            ORDER BY f.id_feedback DESC
        ";

        $stmt = $conn->prepare($sql);
        $stmt->bind_param('i', $id_cref);
        $stmt->execute();
        $resultado = $stmt->get_result();

        $feedbacks = [];
        while ($feedback = $resultado->fetch_assoc()) {
            $feedbacks[] = $feedback;
        }
        $stmt->close();

        $sql = "
            SELECT
                COUNT(*) AS total,
                COALESCE(AVG(avaliacao), 0) AS media,
                SUM(avaliacao = 5) AS e5,
                SUM(avaliacao = 4) AS e4,
                SUM(avaliacao = 3) AS e3,
                SUM(avaliacao = 2) AS e2,
                SUM(avaliacao = 1) AS e1
            FROM tb_feedbacks
            WHERE id_cref = ?
        ";

        $stmt = $conn->prepare($sql);
        $stmt->bind_param('i', $id_cref);
        $stmt->execute();
        $resumo = $stmt->get_result()->fetch_assoc();
        $stmt->close();

        responder([
            'resumo' => [
                'total' => (int)$resumo['total'],
                'media' => round((float)$resumo['media'], 1),
                'estrelas' => [
                    '5' => (int)$resumo['e5'],
                    '4' => (int)$resumo['e4'],
                    '3' => (int)$resumo['e3'],
                    '2' => (int)$resumo['e2'],
                    '1' => (int)$resumo['e1']
                ]
            ],
            'feedbacks' => $feedbacks
        ]);
    }

    responder(['erro' => 'Ação inválida.']);
}

responder(['erro' => 'Usuário não autenticado.']);
