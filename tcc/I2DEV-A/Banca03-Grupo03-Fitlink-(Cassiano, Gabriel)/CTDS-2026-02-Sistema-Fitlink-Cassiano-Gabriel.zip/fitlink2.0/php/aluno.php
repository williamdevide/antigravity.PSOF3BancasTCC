<?php

session_start();
header("Content-Type: application/json; charset=UTF-8");
include "conexao.php";

if (!$conn) {
    echo json_encode(["erro" => "Não foi possível conectar ao banco de dados."]);
    exit;
}

$acao = $_GET["acao"] ?? $_POST["acao"] ?? "";

if ($acao === "listar_personais") {

    $sqlPersonais = "
        SELECT id_cref, nome, email, telefone, foto
        FROM tb_cadastropersonal
        ORDER BY nome ASC
    ";

    $resultadoPersonais = $conn->query($sqlPersonais);

    if (!$resultadoPersonais) {
        echo json_encode(["erro" => "Erro ao buscar profissionais: " . $conn->error]);
        $conn->close();
        exit;
    }

    $personais = [];

    while ($personal = $resultadoPersonais->fetch_assoc()) {

        $idCref = (int)$personal["id_cref"];

        $stmtPlano = $conn->prepare("
            SELECT MIN(valor) AS valor_minimo, COUNT(*) AS quantidade_planos
            FROM tb_planos
            WHERE id_cref = ?
        ");
        $stmtPlano->bind_param("i", $idCref);
        $stmtPlano->execute();
        $plano = $stmtPlano->get_result()->fetch_assoc();
        $stmtPlano->close();

        $stmtAvaliacao = $conn->prepare("
            SELECT ROUND(AVG(avaliacao), 1) AS avaliacao
            FROM tb_feedbacks
            WHERE id_cref = ?
        ");
        $stmtAvaliacao->bind_param("i", $idCref);
        $stmtAvaliacao->execute();
        $avaliacao = $stmtAvaliacao->get_result()->fetch_assoc();
        $stmtAvaliacao->close();

        $stmtAcademias = $conn->prepare("
            SELECT
                GROUP_CONCAT(DISTINCT a.nomeacademia ORDER BY a.nomeacademia SEPARATOR '||') AS academias,
                GROUP_CONCAT(DISTINCT a.cidade ORDER BY a.cidade SEPARATOR '||') AS cidades,
                GROUP_CONCAT(DISTINCT a.estado ORDER BY a.estado SEPARATOR '||') AS estados
            FROM tb_personalacademia AS pa
            INNER JOIN tb_academia AS a ON a.id_academia = pa.id_academia
            WHERE pa.id_cref = ?
        ");
        $stmtAcademias->bind_param("i", $idCref);
        $stmtAcademias->execute();
        $academias = $stmtAcademias->get_result()->fetch_assoc();
        $stmtAcademias->close();

        $personais[] = [
            "id_cref" => $idCref,
            "nome" => $personal["nome"],
            "email" => $personal["email"],
            "telefone" => $personal["telefone"],
            "foto" => $personal["foto"] ?? null,
            "valor_minimo" => $plano["valor_minimo"] ?? null,
            "quantidade_planos" => $plano["quantidade_planos"] ?? 0,
            "avaliacao" => $avaliacao["avaliacao"] ?? null,
            "academias" => $academias["academias"] ?? "",
            "cidades" => $academias["cidades"] ?? "",
            "estados" => $academias["estados"] ?? ""
        ];
    }

    echo json_encode($personais, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    $conn->close();
    exit;
}

echo json_encode(["erro" => "Ação não encontrada."]);
$conn->close();
?>