<?php

session_start();

header("Content-Type: application/json; charset=UTF-8");

require_once __DIR__ . "/conexao.php";


// ==================================================
// VERIFICAR CONEXÃO
// ==================================================

if ($conn->connect_error) {

    echo json_encode([
        "erro" => "Erro de conexão com o banco."
    ], JSON_UNESCAPED_UNICODE);

    exit;
}


// ==================================================
// VERIFICAR LOGIN DO PERSONAL
// ==================================================

if (
    ($_SESSION["tipo_usuario"] ?? "") !== "personal"
) {

    echo json_encode([
        "erro" => "Personal não autenticado."
    ], JSON_UNESCAPED_UNICODE);

    exit;
}


// ==================================================
// PEGAR CREF DA SESSÃO
// ==================================================

$id_cref = (int)(
    $_SESSION["id_cref"] ?? 0
);


if ($id_cref <= 0) {

    echo json_encode([
        "erro" => "CREF do Personal não encontrado na sessão."
    ], JSON_UNESCAPED_UNICODE);

    exit;
}


// ==================================================
// AÇÃO
// ==================================================

$acao =
    $_GET["acao"]
    ?? $_POST["acao"]
    ?? "";


// ==================================================
// LISTAR AGENDA
// ==================================================

if ($acao === "listar") {


    // ==============================================
    // DATA
    // ==============================================

    $data =
        $_GET["data"]
        ?? "";


    // ==============================================
    // VALIDAR DATA
    // ==============================================

    $dataObjeto =
        DateTime::createFromFormat(
            "Y-m-d",
            $data
        );


    if (
        !$dataObjeto
        ||
        $dataObjeto->format("Y-m-d") !== $data
    ) {

        echo json_encode([
            "erro" => "Data inválida."
        ], JSON_UNESCAPED_UNICODE);

        exit;
    }


    // ==============================================
    // BUSCAR AGENDA
    // ==============================================

    /*
    ==================================================
    AQUI ESTÁ O PONTO IMPORTANTE:

    Pegamos todas as agendas daquele Personal
    naquela data.

    Depois fazemos LEFT JOIN com tb_aulamarcada.

    Assim:

    - horário sem aula = aparece como disponível
    - horário com aula = aparece com o aluno
    ==================================================
    */

    $sql = "

        SELECT

            agenda.id_agenda,

            agenda.dia,

            TIME_FORMAT(
                agenda.horario,
                '%H:%i'
            ) AS horario,

            agenda.id_academia,

            academia.nomeacademia,

            aula.id_aula,

            aula.status,

            aluno.id_aluno,

            aluno.nome AS nome_aluno,

            aluno.email AS email_aluno,

            aluno.telefone AS telefone_aluno

        FROM tb_agenda AS agenda


        INNER JOIN tb_aulamarcada AS aula
        
            ON aula.id_agenda = agenda.id_agenda


        LEFT JOIN tb_cadastroaluno AS aluno

            ON aluno.id_aluno =
               aula.id_aluno


        LEFT JOIN tb_academia AS academia

            ON academia.id_academia =
               agenda.id_academia


        WHERE

            agenda.id_cref = ?

            AND agenda.dia = ?


        ORDER BY

            agenda.horario ASC

    ";


    $stmt =
        $conn->prepare($sql);


    if (!$stmt) {

        echo json_encode([
            "erro" =>
                "Erro ao preparar consulta da agenda: "
                . $conn->error
        ], JSON_UNESCAPED_UNICODE);

        exit;
    }


    $stmt->bind_param(
        "is",
        $id_cref,
        $data
    );


    if (!$stmt->execute()) {

        echo json_encode([
            "erro" =>
                "Erro ao executar consulta da agenda: "
                . $stmt->error
        ], JSON_UNESCAPED_UNICODE);

        $stmt->close();

        exit;
    }


    $resultado =
        $stmt->get_result();


    $agenda = [];


    while (
        $linha =
        $resultado->fetch_assoc()
    ) {


        $agenda[] = [

            "id_agenda" =>
                (int)$linha["id_agenda"],


            "dia" =>
                $linha["dia"],


            "horario" =>
                $linha["horario"],


            "id_academia" =>
                $linha["id_academia"] !== null
                    ? (int)$linha["id_academia"]
                    : null,


            "nomeacademia" =>
                $linha["nomeacademia"],


            "id_aula" =>
                $linha["id_aula"] !== null
                    ? (int)$linha["id_aula"]
                    : null,


            "status" =>
                $linha["status"],


            "id_aluno" =>
                $linha["id_aluno"] !== null
                    ? (int)$linha["id_aluno"]
                    : null,


            "nome_aluno" =>
                $linha["nome_aluno"],


            "email_aluno" =>
                $linha["email_aluno"],


            "telefone_aluno" =>
                $linha["telefone_aluno"]

        ];

    }


    $stmt->close();


    // ==============================================
    // RETORNAR AGENDA
    // ==============================================

    echo json_encode(
        $agenda,
        JSON_UNESCAPED_UNICODE
    );

    exit;
}


// ==================================================
// AÇÃO INVÁLIDA
// ==================================================

echo json_encode([
    "erro" => "Ação inválida."
], JSON_UNESCAPED_UNICODE);

$conn->close();

?>