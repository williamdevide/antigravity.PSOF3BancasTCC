<?php

session_start();

header('Content-Type: application/json; charset=utf-8');

require_once 'conexao.php';


/* =========================================================
   RESPOSTA JSON
========================================================= */

function responder($dados)
{
    echo json_encode(
        $dados,
        JSON_UNESCAPED_UNICODE
    );

    exit;
}


/* =========================================================
   VERIFICAR LOGIN DO PERSONAL
========================================================= */

if (
    !isset($_SESSION['tipo_usuario']) ||
    $_SESSION['tipo_usuario'] !== 'personal' ||
    !isset($_SESSION['id_cref'])
) {

    responder([
        'erro' => 'Personal não autenticado.'
    ]);

}


$id_cref =
    intval(
        $_SESSION['id_cref']
    );


/* =========================================================
   RECEBER MÊS E ANO
========================================================= */

$ano =
    isset($_GET['ano'])
        ? intval($_GET['ano'])
        : intval(date('Y'));


$mes =
    isset($_GET['mes'])
        ? intval($_GET['mes'])
        : intval(date('m'));


/* =========================================================
   VALIDAR
========================================================= */

if (
    $ano < 2000 ||
    $ano > 2100
) {

    responder([
        'erro' => 'Ano inválido.'
    ]);

}


if (
    $mes < 1 ||
    $mes > 12
) {

    responder([
        'erro' => 'Mês inválido.'
    ]);

}


/* =========================================================
   BUSCAR CONTRATOS DO PERSONAL
========================================================= */

/*
    RELAÇÃO:

    tb_contrato
        ↓ id_plano

    tb_planos
        ↓ id_cref

    Personal logado


    Também buscamos o nome do aluno através de:

    tb_contrato
        ↓ id_aluno

    tb_cadastroaluno
*/

$sql = "

    SELECT

        c.id_contrato,

        c.data_confirmacao,

        a.nome AS aluno,

        p.titulo AS plano,

        p.valor AS valor_bruto

    FROM tb_contrato c

    INNER JOIN tb_planos p
        ON p.id_plano = c.id_plano

    INNER JOIN tb_cadastroaluno a
        ON a.id_aluno = c.id_aluno

    WHERE p.id_cref = ?

      AND c.confirmado = 1

      AND YEAR(c.data_confirmacao) = ?

      AND MONTH(c.data_confirmacao) = ?

    ORDER BY
        c.data_confirmacao DESC,
        c.id_contrato DESC

";


$stmt =
    $conn->prepare($sql);


if (!$stmt) {

    responder([
        'erro' =>
            'Erro ao preparar consulta: ' .
            $conn->error
    ]);

}


$stmt->bind_param(
    "iii",
    $id_cref,
    $ano,
    $mes
);


if (!$stmt->execute()) {

    responder([
        'erro' =>
            'Erro ao consultar financeiro.'
    ]);

}


$resultado =
    $stmt->get_result();


/* =========================================================
   CALCULAR VALORES
========================================================= */

$contratos = [];

$bruto = 0;

$taxaTotal = 0;

$liquidoTotal = 0;


while (
    $linha =
        $resultado->fetch_assoc()
) {

    $valorBruto =
        floatval(
            $linha['valor_bruto']
        );


    /*
        FITLINK = 20%
    */

    $taxa =
        round(
            $valorBruto * 0.20,
            2
        );


    /*
        PERSONAL = 80%
    */

    $liquido =
        round(
            $valorBruto - $taxa,
            2
        );


    $bruto +=
        $valorBruto;


    $taxaTotal +=
        $taxa;


    $liquidoTotal +=
        $liquido;


    /*
        FORMATAR DATA
    */

    $dataFormatada =
        date(
            'd/m/Y',
            strtotime(
                $linha['data_confirmacao']
            )
        );


    $contratos[] = [

        'id_contrato' =>
            intval(
                $linha['id_contrato']
            ),

        'aluno' =>
            $linha['aluno'],

        'plano' =>
            $linha['plano'],

        'data' =>
            $dataFormatada,

        'valor_bruto' =>
            round(
                $valorBruto,
                2
            ),

        'taxa' =>
            round(
                $taxa,
                2
            ),

        'liquido' =>
            round(
                $liquido,
                2
            )

    ];

}


$stmt->close();


/* =========================================================
   RESPOSTA
========================================================= */

responder([

    'sucesso' => true,

    'periodo' => [
        'mes' => $mes,
        'ano' => $ano
    ],

    'resumo' => [

        'quantidade' =>
            count(
                $contratos
            ),

        'bruto' =>
            round(
                $bruto,
                2
            ),

        'taxa' =>
            round(
                $taxaTotal,
                2
            ),

        'liquido' =>
            round(
                $liquidoTotal,
                2
            )

    ],

    'contratos' =>
        $contratos

]);

?>
