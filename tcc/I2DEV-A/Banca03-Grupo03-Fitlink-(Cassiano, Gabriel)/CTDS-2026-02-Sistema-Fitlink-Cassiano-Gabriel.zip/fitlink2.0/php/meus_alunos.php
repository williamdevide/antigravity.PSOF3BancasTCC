<?php 
 
session_start(); 
 
header( 
    "Content-Type: application/json; charset=UTF-8" 
); 
 
require_once __DIR__ . "/conexao.php"; 
 
 
// ================================================== 
// FUNÇÃO DE RESPOSTA 
// ================================================== 
 
function responder($dados) 
{ 
    echo json_encode( 
        $dados, 
        JSON_UNESCAPED_UNICODE 
    ); 
 
    exit; 
} 
 
 
// ================================================== 
// VERIFICAR LOGIN DO PERSONAL 
// ================================================== 
 
if ( 
    ($_SESSION["tipo_usuario"] ?? "") 
    !== 
    "personal" 
) { 
 
    responder([ 
        "erro" => 
            "Personal não autenticado." 
    ]); 
} 
 
 
$id_cref = 
    (int)( 
        $_SESSION["id_cref"] 
        ?? 0 
    ); 
 
 
if (!$id_cref) { 
 
    responder([ 
        "erro" => 
            "CREF do Personal não identificado." 
    ]); 
} 
 
 
// ================================================== 
// AÇÃO 
// ================================================== 
 
$acao = 
    $_GET["acao"] 
    ?? 
    $_POST["acao"] 
    ?? 
    ""; 
 
 
// ================================================== 
// LISTAR CONVERSAS 
// ================================================== 
 
if ( 
    $acao === 
    "listar" 
) { 
 
 
    $sql = " 
 
        SELECT 
 
            a.id_aluno, 
 
            a.nome, 
 
            a.email, 
 
            a.telefone, 

            a.foto,
 
 
            ultima.id_mensagem, 
 
            ultima.mensagem AS ultima_mensagem, 
 
            ultima.data_envio, 
 
 
            aula.id_aula, 
 
            aula.status, 
 
            agenda.dia, 
 
            TIME_FORMAT( 
                agenda.horario, 
                '%H:%i' 
            ) AS horario, 
 
            agenda.id_academia, 
 
            academia.nomeacademia 
 
 
        FROM tb_cadastroaluno a 
 
 
        INNER JOIN ( 
 
            SELECT 
 
                id_aluno, 
 
                MAX(id_mensagem) 
                AS ultimo_id 
 
            FROM tb_mensagens 
 
            WHERE 
                id_cref = ? 
 
            GROUP BY 
                id_aluno 
 
        ) ultima_id 
 
            ON ultima_id.id_aluno = 
               a.id_aluno 
 
 
        INNER JOIN tb_mensagens ultima 
 
            ON ultima.id_mensagem = 
               ultima_id.ultimo_id 
 
 
        LEFT JOIN ( 
 
            SELECT 
                x.id_aluno, 
                x.id_aula 
 
            FROM tb_aulamarcada x 
 
            INNER JOIN tb_agenda g 
 
                ON g.id_agenda = 
                   x.id_agenda 
 
            INNER JOIN ( 
 
                SELECT 
 
                    am.id_aluno, 
 
                    MAX(am.id_aula) 
                    AS ultima_aula 
 
                FROM tb_aulamarcada am 
 
                INNER JOIN tb_agenda ag 
 
                    ON ag.id_agenda = 
                       am.id_agenda 
 
                WHERE 
                    ag.id_cref = ? 
 
                GROUP BY 
                    am.id_aluno 
 
            ) ultima_aula 
 
                ON ultima_aula.ultima_aula = 
                   x.id_aula 
 
        ) aula_aluno 
 
            ON aula_aluno.id_aluno = 
               a.id_aluno 
 
 
        LEFT JOIN tb_aulamarcada aula 
 
            ON aula.id_aula = 
               aula_aluno.id_aula 
 
 
        LEFT JOIN tb_agenda agenda 
 
            ON agenda.id_agenda = 
               aula.id_agenda 
 
 
        LEFT JOIN tb_academia academia 
 
            ON academia.id_academia = 
               agenda.id_academia 
 
 
        ORDER BY 
            ultima.data_envio DESC 
 
    "; 
 
 
    $stmt = 
        $conn->prepare( 
            $sql 
        ); 
 
 
    if (!$stmt) { 
 
        responder([ 
            "erro" => 
                "Erro ao preparar a lista de conversas." 
        ]); 
 
    } 
 
 
    $stmt->bind_param( 
        "ii", 
        $id_cref, 
        $id_cref 
    ); 
 
 
    $stmt->execute(); 
 
 
    $resultado = 
        $stmt->get_result(); 
 
 
    $conversas = []; 
 
 
    while ( 
        $linha = 
        $resultado->fetch_assoc() 
    ) { 
 
        $conversas[] = [ 
 
            "id_aluno" => 
                (int)$linha[ 
                    "id_aluno" 
                ], 
 
            "nome" => 
                $linha[ 
                    "nome" 
                ], 
 
            "email" => 
                $linha[ 
                    "email" 
                ], 
 
            "telefone" => 
                $linha[ 
                    "telefone" 
                ],

            "foto" =>
                $linha[
                    "foto"
                ] ?? null,
 
            "ultima_mensagem" => 
                $linha[ 
                    "ultima_mensagem" 
                ], 
 
            "data_envio" => 
                $linha[ 
                    "data_envio" 
                ], 
 
            "id_aula" => 
                $linha[ 
                    "id_aula" 
                ] 
                !== null 
                ? 
                (int)$linha[ 
                    "id_aula" 
                ] 
                : 
                null, 
 
            "status" => 
                $linha[ 
                    "status" 
                ], 
 
            "dia" => 
                $linha[ 
                    "dia" 
                ], 
 
            "horario" => 
                $linha[ 
                    "horario" 
                ], 
 
            "id_academia" => 
                $linha[ 
                    "id_academia" 
                ], 
 
            "nomeacademia" => 
                $linha[ 
                    "nomeacademia" 
                ] 
 
        ]; 
 
    } 
 
 
    $stmt->close(); 
 
 
    responder( 
        $conversas 
    ); 
} 
 
 
// ================================================== 
// CARREGAR MENSAGENS 
// ================================================== 
 
if ( 
    $acao === 
    "mensagens" 
) { 
 
 
    $id_aluno = 
        (int)( 
            $_GET["id_aluno"] 
            ?? 0 
        ); 
 
 
    if (!$id_aluno) { 
 
        responder([ 
            "erro" => 
                "Aluno não informado." 
        ]); 
 
    } 
 
 
    $sql = " 
 
        SELECT 
 
            id_mensagem, 
 
            remetente, 
 
            tipo, 
 
            mensagem, 
 
            id_aula, 
 
            data_envio, 
 
            lida 
 
        FROM tb_mensagens 
 
        WHERE 
 
            id_aluno = ? 
 
            AND id_cref = ? 
 
        ORDER BY 
 
            data_envio ASC, 
 
            id_mensagem ASC 
 
    "; 
 
 
    $stmt = 
        $conn->prepare( 
            $sql 
        ); 
 
 
    if (!$stmt) { 
 
        responder([ 
            "erro" => 
                "Erro ao carregar mensagens." 
        ]); 
 
    } 
 
 
    $stmt->bind_param( 
        "ii", 
        $id_aluno, 
        $id_cref 
    ); 
 
 
    $stmt->execute(); 
 
 
    $resultado = 
        $stmt->get_result(); 
 
 
    $mensagens = []; 
 
 
    while ( 
        $linha = 
        $resultado->fetch_assoc() 
    ) { 
 
        $mensagens[] = 
            $linha; 
 
    } 
 
 
    $stmt->close(); 
 
 
    // ============================================== 
    // MARCAR MENSAGENS COMO LIDAS 
    // ============================================== 
 
    $sqlLidas = " 
 
        UPDATE tb_mensagens 
 
        SET lida = 1 
 
        WHERE 
 
            id_aluno = ? 
 
            AND id_cref = ? 
 
            AND remetente IN ( 
                'aluno', 
                'sistema' 
            ) 
 
            AND lida = 0 
 
    "; 
 
 
    $stmtLidas = 
        $conn->prepare( 
            $sqlLidas 
        ); 
 
 
    if ($stmtLidas) { 
 
        $stmtLidas->bind_param( 
            "ii", 
            $id_aluno, 
            $id_cref 
        ); 
 
        $stmtLidas->execute(); 
 
        $stmtLidas->close(); 
 
    } 
 
 
    responder( 
        $mensagens 
    ); 
} 
 
 
// ================================================== 
// ALTERAR STATUS 
// ================================================== 
 
if ( 
    $acao === 
    "alterar_status" 
) { 
 
 
    $id_aula = 
        (int)( 
            $_POST["id_aula"] 
            ?? 0 
        ); 
 
 
    $novoStatus = 
        $_POST["status"] 
        ?? ""; 
 
 
    $statusPermitidos = [ 
 
        "confirmada", 
 
        "cancelada" 
 
    ]; 
 
 
    if ( 
        !$id_aula 
        || 
        !in_array( 
            $novoStatus, 
            $statusPermitidos, 
            true 
        ) 
    ) { 
 
        responder([ 
            "erro" => 
                "Dados inválidos." 
        ]); 
 
    } 
 
 
    $conn->begin_transaction(); 
 
 
    try { 
 
 
        // ========================================== 
        // BUSCAR AULA 
        // ========================================== 
 
        $sqlAula = " 
 
            SELECT 
 
                am.id_aula, 
 
                am.id_aluno,

                am.id_contrato, 
 
                am.status, 
 
                ag.id_cref, 
 
                ag.dia, 
 
                ag.horario, 
 
                ag.id_academia, 
 
                ac.nomeacademia, 
 
                al.nome AS nome_aluno 
 
            FROM tb_aulamarcada am 
 
            INNER JOIN tb_agenda ag 
 
                ON ag.id_agenda = 
                   am.id_agenda 
 
            INNER JOIN tb_academia ac 
 
                ON ac.id_academia = 
                   ag.id_academia 
 
            INNER JOIN tb_cadastroaluno al 
 
                ON al.id_aluno = 
                   am.id_aluno 
 
            WHERE 
 
                am.id_aula = ? 
 
                AND ag.id_cref = ? 
 
            LIMIT 1 
 
            FOR UPDATE 
 
        "; 
 
 
        $stmtAula = 
            $conn->prepare( 
                $sqlAula 
            ); 
 
 
        $stmtAula->bind_param( 
            "ii", 
            $id_aula, 
            $id_cref 
        ); 
 
 
        $stmtAula->execute(); 
 
 
        $resultadoAula = 
            $stmtAula->get_result(); 
 
 
        $aula = 
            $resultadoAula->fetch_assoc(); 
 
 
        $stmtAula->close(); 
 
 
        if (!$aula) { 
 
            throw new Exception( 
                "Aula não encontrada." 
            ); 
 
        } 
 
 
        // ========================================== 
        // ATUALIZAR STATUS 
        // ========================================== 
 
        $sqlUpdate = " 
 
            UPDATE tb_aulamarcada 
 
            SET status = ? 
 
            WHERE id_aula = ? 
 
        "; 
 
 
        $stmtUpdate = 
            $conn->prepare( 
                $sqlUpdate 
            ); 
 
 
        $stmtUpdate->bind_param( 
            "si", 
            $novoStatus, 
            $id_aula 
        ); 
 
 
        if ( 
            !$stmtUpdate->execute() 
        ) { 
 
            $stmtUpdate->close(); 


        // ==========================================
        // LIBERAR CONTRATO NO FINANCEIRO
        // ==========================================

        if ($novoStatus === "confirmada") {

            $id_contrato =
                isset($aula["id_contrato"])
                ? (int)$aula["id_contrato"]
                : 0;

            if ($id_contrato > 0) {

                $sqlFinanceiro = "

                    UPDATE tb_contrato c

                    INNER JOIN tb_planos p
                        ON p.id_plano = c.id_plano

                    SET
                        c.confirmado = 1,
                        c.data_confirmacao = NOW()

                    WHERE
                        c.id_contrato = ?
                        AND c.id_aluno = ?
                        AND p.id_cref = ?
                        AND c.confirmado = 0

                ";

                $stmtFinanceiro =
                    $conn->prepare(
                        $sqlFinanceiro
                    );

                if (!$stmtFinanceiro) {
                    throw new Exception(
                        "Erro ao preparar lançamento financeiro."
                    );
                }

                $stmtFinanceiro->bind_param(
                    "iii",
                    $id_contrato,
                    $aula["id_aluno"],
                    $id_cref
                );

                if (!$stmtFinanceiro->execute()) {
                    $stmtFinanceiro->close();
                    throw new Exception(
                        "Não foi possível registrar o valor no financeiro."
                    );
                }

                $stmtFinanceiro->close();
            }
        }

 
            throw new Exception( 
                "Não foi possível atualizar a aula." 
            ); 
 
        } 
 
 
        $stmtUpdate->close(); 
 
 
        // ========================================== 
        // TEXTO DA MENSAGEM 
        // ========================================== 
 
        $data = 
            DateTime::createFromFormat( 
                "Y-m-d", 
                $aula["dia"] 
            ); 
 
 
        $dataFormatada = 
            $data 
            ? 
            $data->format( 
                "d/m/Y" 
            ) 
            : 
            $aula["dia"]; 
 
 
        $horario = 
            substr( 
                $aula["horario"], 
                0, 
                5 
            ); 
 
 
        if ( 
            $novoStatus === 
            "confirmada" 
        ) { 
 
            $tipo = 
                "confirmacao"; 
 
 
            $mensagem = 
                "Aula confirmada para " 
                . 
                $dataFormatada 
                . 
                " às " 
                . 
                $horario 
                . 
                " na " 
                . 
                $aula[ 
                    "nomeacademia" 
                ] 
                . 
                "."; 
 
        } 
 
        else { 
 
            $tipo = 
                "cancelamento"; 
 
 
            $mensagem = 
                "Aula cancelada para " 
                . 
                $dataFormatada 
                . 
                " às " 
                . 
                $horario 
                . 
                " na " 
                . 
                $aula[ 
                    "nomeacademia" 
                ] 
                . 
                "."; 
 
        } 
 
 
        // ========================================== 
        // REGISTRAR MENSAGEM 
        // ========================================== 
 
        $sqlMensagem = " 
 
            INSERT INTO tb_mensagens 
 
            ( 
                id_aluno, 
                id_cref, 
                remetente, 
                tipo, 
                mensagem, 
                id_aula 
            ) 
 
            VALUES 
 
            ( 
                ?, 
                ?, 
                'personal', 
                ?, 
                ?, 
                ? 
            ) 
 
        "; 
 
 
        $stmtMensagem = 
            $conn->prepare( 
                $sqlMensagem 
            ); 
 
 
        if (!$stmtMensagem) { 
 
            throw new Exception( 
                "Erro ao criar mensagem." 
            ); 
 
        } 
 
 
        $stmtMensagem->bind_param( 
            "iissi", 
            $aula["id_aluno"], 
            $id_cref, 
            $tipo, 
            $mensagem, 
            $id_aula 
        ); 
 
 
        if ( 
            !$stmtMensagem->execute() 
        ) { 
 
            $stmtMensagem->close(); 
 
            throw new Exception( 
                "Não foi possível registrar a mensagem." 
            ); 
 
        } 
 
 
        $stmtMensagem->close(); 
 
 
        // ========================================== 
        // COMMIT 
        // ========================================== 
 
        $conn->commit(); 
 
 
        $textoResposta = 
            $novoStatus === 
            "confirmada" 
            ? 
            "Aula confirmada com sucesso!" 
            : 
            "Aula cancelada com sucesso!"; 
 
 
        responder([ 
 
            "sucesso" => 
                true, 
 
            "mensagem" => 
                $textoResposta 
 
        ]); 
 
    } 
 
    catch ( 
        Exception $e 
    ) { 
 
        $conn->rollback(); 
 
 
        responder([ 
 
            "sucesso" => 
                false, 
 
            "erro" => 
                $e->getMessage() 
 
        ]); 
 
    } 
 
} 
 
 
// ================================================== 
// HORÁRIOS PARA REMARCAÇÃO 
// ================================================== 
 
if ( 
    $acao === 
    "horarios_remarcacao" 
) { 
 
 
    $id_aula = 
        (int)( 
            $_GET["id_aula"] 
            ?? 0 
        ); 
 
 
    $data = 
        $_GET["data"] 
        ?? ""; 
 
 
    if ( 
        !$id_aula || 
        !$data 
    ) { 
 
        responder([ 
            "erro" => 
                "Aula e data são obrigatórios." 
        ]); 
 
    } 
 
 
    // ========================================== 
    // PEGAR ACADEMIA ATUAL 
    // ========================================== 
 
    $sqlAula = " 
 
        SELECT 
 
            ag.id_cref, 
 
            ag.id_academia 
 
        FROM tb_aulamarcada am 
 
        INNER JOIN tb_agenda ag 
 
            ON ag.id_agenda = 
               am.id_agenda 
 
        WHERE 
 
            am.id_aula = ? 
 
            AND ag.id_cref = ? 
 
        LIMIT 1 
 
    "; 
 
 
    $stmt = 
        $conn->prepare( 
            $sqlAula 
        ); 
 
 
    $stmt->bind_param( 
        "ii", 
        $id_aula, 
        $id_cref 
    ); 
 
 
    $stmt->execute(); 
 
 
    $resultado = 
        $stmt->get_result(); 
 
 
    $aula = 
        $resultado->fetch_assoc(); 
 
 
    $stmt->close(); 
 
 
    if (!$aula) { 
 
        responder([ 
            "erro" => 
                "Aula não encontrada." 
        ]); 
 
    } 
 
 
    // ========================================== 
    // DIA DA SEMANA 
    // ========================================== 
 
    $dataObjeto = 
        DateTime::createFromFormat( 
            "Y-m-d", 
            $data 
        ); 
 
 
    if ( 
        !$dataObjeto 
        || 
        $dataObjeto->format("Y-m-d") 
        !== 
        $data 
    ) { 
 
        responder([ 
            "erro" => 
                "Data inválida." 
        ]); 
 
    } 
 
 
    $diaSemana = 
        (int)$dataObjeto->format( 
            "N" 
        ); 
 
 
    // ========================================== 
    // BUSCAR DISPONIBILIDADE 
    // ========================================== 
 
    $sql = " 
 
        SELECT 
 
            a.id_agenda, 
 
            TIME_FORMAT( 
                a.horario, 
                '%H:%i' 
            ) AS horario, 
 
            ac.nomeacademia 
 
        FROM tb_agenda a 
 
        INNER JOIN tb_academia ac 
 
            ON ac.id_academia = 
               a.id_academia 
 
        INNER JOIN tb_disponibilidade d 
 
            ON d.id_cref = 
               a.id_cref 
 
            AND d.dia_semana = 
                ? 
 
            AND d.horario = 
                a.horario 
 
            AND d.id_academia = 
                a.id_academia 
 
        WHERE 
 
            a.id_cref = ? 
 
            AND a.dia = ? 
 
            AND NOT EXISTS ( 
 
                SELECT 1 
 
                FROM tb_aulamarcada ocupada 
 
                WHERE 
 
                    ocupada.id_agenda = 
                    a.id_agenda 
 
                    AND ocupada.status IN ( 
                        'pendente', 
                        'confirmada', 
                        'remarcada' 
                    ) 
 
                    AND ocupada.id_aula <> ? 
 
            ) 
 
        ORDER BY 
 
            a.horario ASC 
 
    "; 
 
 
    $stmt = 
        $conn->prepare( 
            $sql 
        ); 
 
 
    $stmt->bind_param( 
        "iisi", 
        $diaSemana, 
        $id_cref, 
        $data, 
        $id_aula 
    ); 
 
 
    $stmt->execute(); 
 
 
    $resultado = 
        $stmt->get_result(); 
 
 
    $horarios = []; 
 
 
    while ( 
        $linha = 
        $resultado->fetch_assoc() 
    ) { 
 
        $horarios[] = 
            $linha; 
 
    } 
 
 
    $stmt->close(); 
 
 
    responder( 
        $horarios 
    ); 
} 
 
 
// ================================================== 
// REMARCAR 
// ================================================== 
 
if ( 
    $acao === 
    "remarcar" 
) { 
 
 
    $id_aula = 
        (int)( 
            $_POST["id_aula"] 
            ?? 0 
        ); 
 
 
    $id_agenda_nova = 
        (int)( 
            $_POST["id_agenda_nova"] 
            ?? 0 
        ); 
 
 
    if ( 
        !$id_aula || 
        !$id_agenda_nova 
    ) { 
 
        responder([ 
            "erro" => 
                "Aula e novo horário são obrigatórios." 
        ]); 
 
    } 
 
 
    $conn->begin_transaction(); 
 
 
    try { 
 
 
        // ========================================== 
        // BUSCAR AULA ATUAL 
        // ========================================== 
 
        $sqlAtual = " 
 
            SELECT 
 
                am.id_aula, 
 
                am.id_aluno, 
 
                am.id_agenda, 
 
                ag.id_cref, 
 
                ag.dia, 
 
                ag.horario, 
 
                ag.id_academia, 
 
                ac.nomeacademia 
 
            FROM tb_aulamarcada am 
 
            INNER JOIN tb_agenda ag 
 
                ON ag.id_agenda = 
                   am.id_agenda 
 
            INNER JOIN tb_academia ac 
 
                ON ac.id_academia = 
                   ag.id_academia 
 
            WHERE 
 
                am.id_aula = ? 
 
                AND ag.id_cref = ? 
 
            LIMIT 1 
 
            FOR UPDATE 
 
        "; 
 
 
        $stmtAtual = 
            $conn->prepare( 
                $sqlAtual 
            ); 
 
 
        $stmtAtual->bind_param( 
            "ii", 
            $id_aula, 
            $id_cref 
        ); 
 
 
        $stmtAtual->execute(); 
 
 
        $resultadoAtual = 
            $stmtAtual->get_result(); 
 
 
        $aulaAtual = 
            $resultadoAtual->fetch_assoc(); 
 
 
        $stmtAtual->close(); 
 
 
        if (!$aulaAtual) { 
 
            throw new Exception( 
                "Aula atual não encontrada." 
            ); 
 
        } 
 
 
        // ========================================== 
        // BUSCAR NOVO HORÁRIO 
        // ========================================== 
 
        $sqlNova = " 
 
            SELECT 
 
                ag.id_agenda, 
 
                ag.dia, 
 
                ag.horario, 
 
                ag.id_cref, 
 
                ag.id_academia, 
 
                ac.nomeacademia 
 
            FROM tb_agenda ag 
 
            INNER JOIN tb_academia ac 
 
                ON ac.id_academia = 
                   ag.id_academia 
 
            WHERE 
 
                ag.id_agenda = ? 
 
                AND ag.id_cref = ? 
 
            LIMIT 1 
 
            FOR UPDATE 
 
        "; 
 
 
        $stmtNova = 
            $conn->prepare( 
                $sqlNova 
            ); 
 
 
        $stmtNova->bind_param( 
            "ii", 
            $id_agenda_nova, 
            $id_cref 
        ); 
 
 
        $stmtNova->execute(); 
 
 
        $resultadoNova = 
            $stmtNova->get_result(); 
 
 
        $novaAgenda = 
            $resultadoNova->fetch_assoc(); 
 
 
        $stmtNova->close(); 
 
 
        if (!$novaAgenda) { 
 
            throw new Exception( 
                "Novo horário não encontrado." 
            ); 
 
        } 
 
 
        // ========================================== 
        // VERIFICAR SE NOVO HORÁRIO ESTÁ OCUPADO 
        // ========================================== 
 
        $sqlOcupado = " 
 
            SELECT 
                id_aula 
 
            FROM tb_aulamarcada 
 
            WHERE 
 
                id_agenda = ? 
 
                AND id_aula <> ? 
 
                AND status IN ( 
                    'pendente', 
                    'confirmada', 
                    'remarcada' 
                ) 
 
            LIMIT 1 
 
        "; 
 
 
        $stmtOcupado = 
            $conn->prepare( 
                $sqlOcupado 
            ); 
 
 
        $stmtOcupado->bind_param( 
            "ii", 
            $id_agenda_nova, 
            $id_aula 
        ); 
 
 
        $stmtOcupado->execute(); 
 
 
        $resultadoOcupado = 
            $stmtOcupado->get_result(); 
 
 
        if ( 
            $resultadoOcupado->num_rows > 0 
        ) { 
 
            $stmtOcupado->close(); 
 
            throw new Exception( 
                "O novo horário já está ocupado." 
            ); 
 
        } 
 
 
        $stmtOcupado->close(); 
 
 
        // ========================================== 
        // ATUALIZAR AULA 
        // ========================================== 
 
        $sqlUpdate = " 
 
            UPDATE tb_aulamarcada 
 
            SET 
 
                id_agenda = ?, 
 
                status = 'remarcada' 
 
            WHERE 
 
                id_aula = ? 
 
        "; 
 
 
        $stmtUpdate = 
            $conn->prepare( 
                $sqlUpdate 
            ); 
 
 
        $stmtUpdate->bind_param( 
            "ii", 
            $id_agenda_nova, 
            $id_aula 
        ); 
 
 
        if ( 
            !$stmtUpdate->execute() 
        ) { 
 
            $stmtUpdate->close(); 
 
            throw new Exception( 
                "Não foi possível remarcar a aula." 
            ); 
 
        } 
 
 
        $stmtUpdate->close(); 
 
 
        // ========================================== 
        // MONTAR MENSAGEM 
        // ========================================== 
 
        $data = 
            DateTime::createFromFormat( 
                "Y-m-d", 
                $novaAgenda["dia"] 
            ); 
 
 
        $dataFormatada = 
            $data 
            ? 
            $data->format( 
                "d/m/Y" 
            ) 
            : 
            $novaAgenda["dia"]; 
 
 
        $horario = 
            substr( 
                $novaAgenda["horario"], 
                0, 
                5 
            ); 
 
 
        $mensagem = 
            "Aula remarcada para " 
            . 
            $dataFormatada 
            . 
            " às " 
            . 
            $horario 
            . 
            " na " 
            . 
            $novaAgenda[ 
                "nomeacademia" 
            ] 
            . 
            "."; 
 
 
        // ========================================== 
        // REGISTRAR MENSAGEM 
        // ========================================== 
 
        $sqlMensagem = " 
 
            INSERT INTO tb_mensagens 
 
            ( 
                id_aluno, 
                id_cref, 
                remetente, 
                tipo, 
                mensagem, 
                id_aula 
            ) 
 
            VALUES 
 
            ( 
                ?, 
                ?, 
                'personal', 
                'remarcacao', 
                ?, 
                ? 
            ) 
 
        "; 
 
 
        $stmtMensagem = 
            $conn->prepare( 
                $sqlMensagem 
            ); 
 
 
        if (!$stmtMensagem) { 
 
            throw new Exception( 
                "Erro ao preparar mensagem." 
            ); 
 
        } 
 
 
        $stmtMensagem->bind_param( 
            "iisi", 
            $aulaAtual["id_aluno"], 
            $id_cref, 
            $mensagem, 
            $id_aula 
        ); 
 
 
        if ( 
            !$stmtMensagem->execute() 
        ) { 
 
            $stmtMensagem->close(); 
 
            throw new Exception( 
                "Não foi possível registrar a remarcação no chat." 
            ); 
 
        } 
 
 
        $stmtMensagem->close(); 
 
 
        // ========================================== 
        // COMMIT 
        // ========================================== 
 
        $conn->commit(); 
 
 
        responder([ 
 
            "sucesso" => 
                true, 
 
            "mensagem" => 
                "Aula remarcada com sucesso!" 
 
        ]); 
 
    } 
 
    catch ( 
        Exception $e 
    ) { 
 
        $conn->rollback(); 
 
 
        responder([ 
 
            "sucesso" => 
                false, 
 
            "erro" => 
                $e->getMessage() 
 
        ]); 
 
    } 
 
} 
 
 
// ================================================== 
// AÇÃO INVÁLIDA 
// ================================================== 
 
responder([ 
    "erro" => 
        "Ação inválida." 
]); 
 
?>