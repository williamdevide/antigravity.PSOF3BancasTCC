<?php

session_start();

header('Content-Type: application/json; charset=utf-8');

date_default_timezone_set('America/Sao_Paulo');


/* ==================================================
   CONEXÃO
================================================== */

require_once __DIR__ . '/conexao.php';


/*
 * O projeto utiliza a conexão existente em conexao.php.
 *
 * Normalmente ela estará na variável $conn.
 *
 * O código também aceita $conexao ou $mysqli,
 * caso esse seja o nome utilizado no seu arquivo.
 */

if (isset($conn) && $conn instanceof mysqli) {

    $db = $conn;

} elseif (
    isset($conexao) &&
    $conexao instanceof mysqli
) {

    $db = $conexao;

} elseif (
    isset($mysqli) &&
    $mysqli instanceof mysqli
) {

    $db = $mysqli;

} else {

    http_response_code(500);

    echo json_encode([
        'sucesso' => false,
        'mensagem' => 'Não foi possível encontrar a conexão com o banco.'
    ]);

    exit;

}


$db->set_charset('utf8mb4');


/* ==================================================
   FUNÇÃO DE RESPOSTA
================================================== */

function responder(
    bool $sucesso,
    string $mensagem = '',
    array $dados = []
): void {

    echo json_encode(
        array_merge(
            [
                'sucesso' => $sucesso,
                'mensagem' => $mensagem
            ],
            $dados
        ),
        JSON_UNESCAPED_UNICODE
    );

    exit;

}


/* ==================================================
   VERIFICAR LOGIN
================================================== */

if (
    !isset(
        $_SESSION['tipo_usuario']
    ) ||
    $_SESSION['tipo_usuario'] !== 'personal'
) {

    http_response_code(401);

    responder(
        false,
        'Você precisa estar logado como Personal.'
    );

}


if (
    !isset(
        $_SESSION['id_cref']
    )
) {

    http_response_code(401);

    responder(
        false,
        'CREF do Personal não encontrado na sessão.'
    );

}


$id_cref =
    (int) $_SESSION['id_cref'];


/* ==================================================
   AÇÃO
================================================== */

$acao =
    $_GET['acao'] ?? '';


/* ==================================================
   LISTAR ACADEMIAS DO PERSONAL
================================================== */

if (
    $acao === 'academias'
) {

    $sql = "

        SELECT
            a.id_academia,
            a.nomeacademia,
            a.endereco,
            a.cidade,
            a.estado

        FROM tb_personalacademia pa

        INNER JOIN tb_academia a
            ON a.id_academia = pa.id_academia

        WHERE pa.id_cref = ?

        ORDER BY a.nomeacademia ASC

    ";


    $stmt =
        $db->prepare($sql);


    if (!$stmt) {

        http_response_code(500);

        responder(
            false,
            'Erro ao preparar a consulta das academias.'
        );

    }


    $stmt->bind_param(
        'i',
        $id_cref
    );


    if (
        !$stmt->execute()
    ) {

        http_response_code(500);

        responder(
            false,
            'Erro ao consultar as academias.'
        );

    }


    $resultado =
        $stmt->get_result();


    $academias = [];


    while (
        $linha =
        $resultado->fetch_assoc()
    ) {

        $academias[] = [

            'id_academia' =>
                (int)
                $linha['id_academia'],

            'nomeacademia' =>
                $linha['nomeacademia'],

            'endereco' =>
                $linha['endereco'],

            'cidade' =>
                $linha['cidade'],

            'estado' =>
                $linha['estado']

        ];

    }


    $stmt->close();


    responder(
        true,
        '',
        [
            'academias' =>
                $academias
        ]
    );

}


/* ==================================================
   CARREGAR DISPONIBILIDADE
================================================== */

if (
    $acao === 'disponibilidade'
) {

    $sql = "

        SELECT

            d.id_disponibilidade,

            d.dia_semana,

            TIME_FORMAT(
                d.horario,
                '%H:%i'
            ) AS horario,

            d.id_academia,

            a.nomeacademia

        FROM tb_disponibilidade d

        INNER JOIN tb_academia a
            ON a.id_academia = d.id_academia

        WHERE d.id_cref = ?

        ORDER BY
            d.dia_semana ASC,
            d.horario ASC

    ";


    $stmt =
        $db->prepare($sql);


    if (!$stmt) {

        http_response_code(500);

        responder(
            false,
            'Erro ao preparar a consulta de disponibilidade.'
        );

    }


    $stmt->bind_param(
        'i',
        $id_cref
    );


    if (
        !$stmt->execute()
    ) {

        http_response_code(500);

        responder(
            false,
            'Erro ao consultar a disponibilidade.'
        );

    }


    $resultado =
        $stmt->get_result();


    $disponibilidade = [];


    while (
        $linha =
        $resultado->fetch_assoc()
    ) {

        $disponibilidade[] = [

            'id_disponibilidade' =>
                (int)
                $linha[
                    'id_disponibilidade'
                ],

            'dia_semana' =>
                (int)
                $linha[
                    'dia_semana'
                ],

            'horario' =>
                $linha[
                    'horario'
                ],

            'id_academia' =>
                (int)
                $linha[
                    'id_academia'
                ],

            'nomeacademia' =>
                $linha[
                    'nomeacademia'
                ]

        ];

    }


    $stmt->close();


    responder(
        true,
        '',
        [
            'disponibilidade' =>
                $disponibilidade
        ]
    );

}


/* ==================================================
   SALVAR DISPONIBILIDADE
================================================== */

if (
    $_SERVER['REQUEST_METHOD'] === 'POST'
) {


    /*
     * Recebe JSON enviado pelo JavaScript.
     */

    $entrada =
        file_get_contents(
            'php://input'
        );


    $dados =
        json_decode(
            $entrada,
            true
        );


    if (
        !is_array($dados)
    ) {

        http_response_code(400);

        responder(
            false,
            'Dados enviados em formato inválido.'
        );

    }


    $lista =
        $dados['disponibilidade']
        ?? [];


    if (
        !is_array($lista)
    ) {

        http_response_code(400);

        responder(
            false,
            'A lista de disponibilidade é inválida.'
        );

    }


    /* ==================================================
       HORÁRIOS PERMITIDOS
    ================================================== */

    $horariosPermitidos = [

        "00:00",
        "01:00",
        "02:00",
        "03:00",
        "04:00",
        "05:00",
        "06:00",
        "07:00",
        "08:00",
        "09:00",
        "10:00",
        "11:00",
        "12:00",
        "13:00",
        "14:00",
        "15:00",
        "16:00",
        "17:00",
        "18:00",
        "19:00",
        "20:00",
        "21:00",
        "22:00",
        "23:00"

    ];


    /* ==================================================
       VALIDAR ACADEMIAS DO PERSONAL
    ================================================== */

    $sqlAcademias = "

        SELECT
            a.id_academia,
            a.nomeacademia

        FROM tb_personalacademia pa

        INNER JOIN tb_academia a
            ON a.id_academia =
               pa.id_academia

        WHERE pa.id_cref = ?

    ";


    $stmtAcademias =
        $db->prepare(
            $sqlAcademias
        );


    if (!$stmtAcademias) {

        http_response_code(500);

        responder(
            false,
            'Erro ao validar academias.'
        );

    }


    $stmtAcademias->bind_param(
        'i',
        $id_cref
    );


    $stmtAcademias->execute();


    $resultadoAcademias =
        $stmtAcademias->get_result();


    $academiasPermitidas = [];


    while (
        $linha =
        $resultadoAcademias->fetch_assoc()
    ) {

        $academiasPermitidas[
            (int)
            $linha['id_academia']
        ] =
            $linha['nomeacademia'];

    }


    $stmtAcademias->close();


    /* ==================================================
       VALIDAR E NORMALIZAR DADOS
    ================================================== */

    $registros = [];


    foreach (
        $lista as $item
    ) {

        if (
            !is_array($item)
        ) {

            http_response_code(400);

            responder(
                false,
                'Um dos horários enviados é inválido.'
            );

        }


        $dia =
            isset(
                $item['dia_semana']
            )
            ? (int)
              $item['dia_semana']
            : 0;


        $horario =
            isset(
                $item['horario']
            )
            ? substr(
                trim(
                    (string)
                    $item['horario']
                ),
                0,
                5
            )
            : '';


        $id_academia =
            isset(
                $item['id_academia']
            )
            ? (int)
              $item['id_academia']
            : 0;


        /* ------------------------------
           DIA
        ------------------------------ */

        if (
            $dia < 1 ||
            $dia > 7
        ) {

            http_response_code(400);

            responder(
                false,
                'Dia da semana inválido.'
            );

        }


        /* ------------------------------
           HORÁRIO
        ------------------------------ */

        if (
            !in_array(
                $horario,
                $horariosPermitidos,
                true
            )
        ) {

            http_response_code(400);

            responder(
                false,
                "O horário {$horario} não é permitido."
            );

        }


        /* ------------------------------
           ACADEMIA
        ------------------------------ */

        if (
            !isset(
                $academiasPermitidas[
                    $id_academia
                ]
            )
        ) {

            http_response_code(403);

            responder(
                false,
                'Você tentou utilizar uma academia que não está vinculada ao seu perfil.'
            );

        }


        $chave =
            $dia .
            '_' .
            $horario;


        /*
         * A própria estrutura do banco possui
         * uma chave única para:
         *
         * id_cref + dia_semana + horario
         *
         * Mesmo assim, evitamos duplicidade
         * também no PHP.
         */

        if (
            isset(
                $registros[$chave]
            )
        ) {

            http_response_code(400);

            responder(
                false,
                "O horário {$horario} foi informado mais de uma vez."
            );

        }


        $registros[$chave] = [

            'dia' =>
                $dia,

            'horario' =>
                $horario,

            'id_academia' =>
                $id_academia,

            'nomeacademia' =>
                $academiasPermitidas[
                    $id_academia
                ]

        ];

    }


    /* ==================================================
       VALIDAR DESLOCAMENTO
    ================================================== */

    $porDia = [];


    foreach (
        $registros as $registro
    ) {

        $dia =
            $registro['dia'];


        if (
            !isset(
                $porDia[$dia]
            )
        ) {

            $porDia[$dia] = [];

        }


        $porDia[$dia][] =
            $registro;

    }


    foreach (
        $porDia as $dia =>
        &$registrosDia
    ) {

        usort(
            $registrosDia,
            function (
                $a,
                $b
            ) {

                return
                    minutos(
                        $a['horario']
                    ) -
                    minutos(
                        $b['horario']
                    );

            }
        );


        for (
            $i = 1;
            $i < count(
                $registrosDia
            );
            $i++
        ) {

            $anterior =
                $registrosDia[
                    $i - 1
                ];

            $atual =
                $registrosDia[
                    $i
                ];


            $diferenca =
                minutos(
                    $atual['horario']
                ) -
                minutos(
                    $anterior['horario']
                );


            $academiasDiferentes =
                $anterior[
                    'id_academia'
                ] !==
                $atual[
                    'id_academia'
                ];


            /*
             * Aula dura 60 minutos.
             *
             * Mesma academia:
             * próximo horário pode começar
             * 60 minutos depois.
             *
             * Academia diferente:
             * precisa de 60 min de aula
             * + 30 min de deslocamento.
             *
             * Portanto, mínimo de 90 minutos
             * entre os horários de início.
             */

            if (
                $academiasDiferentes &&
                $diferenca < 90
            ) {

                $nomeDia =
                    nomeDia(
                        (int) $dia
                    );


                http_response_code(400);

                responder(
                    false,
                    "Conflito na {$nomeDia}: " .
                    "{$anterior['horario']} - {$anterior['nomeacademia']} " .
                    "e {$atual['horario']} - {$atual['nomeacademia']}. " .
                    "É necessário ter 30 minutos de deslocamento entre academias diferentes."
                );

            }


            if (
                !$academiasDiferentes &&
                $diferenca < 60
            ) {

                http_response_code(400);

                responder(
                    false,
                    "Existem horários conflitantes na {$nomeDia}."
                );

            }

        }

    }

    unset(
        $registrosDia
    );


    /* ==================================================
       TRANSAÇÃO
    ================================================== */

    $db->begin_transaction();


    try {


        /*
         * IMPORTANTE:
         *
         * Aqui apagamos somente a configuração
         * semanal da disponibilidade.
         *
         * Não mexemos na tb_agenda.
         *
         * Portanto, aulas já marcadas continuam
         * existindo.
         */

        $sqlDelete = "

            DELETE FROM
                tb_disponibilidade

            WHERE
                id_cref = ?

        ";


        $stmtDelete =
            $db->prepare(
                $sqlDelete
            );


        if (!$stmtDelete) {

            throw new Exception(
                'Erro ao preparar a limpeza da disponibilidade.'
            );

        }


        $stmtDelete->bind_param(
            'i',
            $id_cref
        );


        if (
            !$stmtDelete->execute()
        ) {

            throw new Exception(
                'Erro ao limpar a disponibilidade anterior.'
            );

        }


        $stmtDelete->close();


        /* ==================================================
           INSERIR NOVA DISPONIBILIDADE
        ================================================== */

        if (
            count($registros) > 0
        ) {

            $sqlInsert = "

                INSERT INTO
                    tb_disponibilidade
                (
                    id_cref,
                    dia_semana,
                    horario,
                    id_academia
                )

                VALUES
                (
                    ?,
                    ?,
                    ?,
                    ?
                )

            ";


            $stmtInsert =
                $db->prepare(
                    $sqlInsert
                );


            if (!$stmtInsert) {

                throw new Exception(
                    'Erro ao preparar o cadastro dos horários.'
                );

            }


            foreach (
                $registros as $registro
            ) {

                $dia =
                    $registro['dia'];

                $horario =
                    $registro['horario'];

                $idAcademia =
                    $registro[
                        'id_academia'
                    ];


                $stmtInsert->bind_param(
                    'iisi',
                    $id_cref,
                    $dia,
                    $horario,
                    $idAcademia
                );


                if (
                    !$stmtInsert->execute()
                ) {

                    throw new Exception(
                        'Erro ao salvar um dos horários.'
                    );

                }

            }


            $stmtInsert->close();

        }


        $db->commit();


        responder(
            true,
            'Disponibilidade salva com sucesso.'
        );


    } catch (
        Throwable $erro
    ) {


        $db->rollback();


        http_response_code(500);


        responder(
            false,
            'Não foi possível salvar os horários. ' .
            $erro->getMessage()
        );

    }

}


/* ==================================================
   AÇÃO INVÁLIDA
================================================== */

http_response_code(400);

responder(
    false,
    'Ação inválida.'
);


/* ==================================================
   FUNÇÕES AUXILIARES
================================================== */

function minutos(
    string $horario
): int {

    $partes =
        explode(
            ':',
            $horario
        );


    return
        (
            (int)
            $partes[0]
            * 60
        )
        +
        (
            (int)
            $partes[1]
        );

}


function nomeDia(
    int $dia
): string {

    $dias = [

        1 => 'segunda-feira',

        2 => 'terça-feira',

        3 => 'quarta-feira',

        4 => 'quinta-feira',

        5 => 'sexta-feira',

        6 => 'sábado',

        7 => 'domingo'

    ];


    return
        $dias[$dia]
        ?? 'dia selecionado';

}