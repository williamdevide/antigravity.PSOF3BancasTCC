<?php

session_start();

header("Content-Type: application/json; charset=UTF-8");

require_once "conexao.php";


function responder($dados)
{
    echo json_encode(
        $dados,
        JSON_UNESCAPED_UNICODE
    );

    exit;
}


if (
    ($_SESSION["tipo_usuario"] ?? "") !== "aluno"
) {
    responder([
        "erro" => "Aluno não autenticado."
    ]);
}


$id_aluno = (int)(
    $_SESSION["id_aluno"] ?? 0
);


if ($id_aluno <= 0) {

    responder([
        "erro" => "ID do aluno não encontrado."
    ]);

}


$acao = $_GET["acao"]
    ?? $_POST["acao"]
    ?? "";


/*
|--------------------------------------------------------------------------
| CARREGAR PERFIL
|--------------------------------------------------------------------------
*/

if ($acao === "perfil") {

    $sql = "
        SELECT
            id_aluno,
            nome,
            email,
            telefone,
            data_nascimento,
            genero,
            foto
        FROM tb_cadastroaluno
        WHERE id_aluno = ?
        LIMIT 1
    ";

    $stmt = $conn->prepare($sql);

    $stmt->bind_param(
        "i",
        $id_aluno
    );

    $stmt->execute();

    $resultado = $stmt->get_result();

    $aluno = $resultado->fetch_assoc();

    if (!$aluno) {

        responder([
            "erro" => "Aluno não encontrado."
        ]);

    }

    responder($aluno);
}


/*
|--------------------------------------------------------------------------
| EDITAR DADOS
|--------------------------------------------------------------------------
*/

if ($acao === "editar") {

    $nome = trim(
        $_POST["nome"] ?? ""
    );

    $email = trim(
        $_POST["email"] ?? ""
    );

    $telefone = trim(
        $_POST["telefone"] ?? ""
    );

    $data_nascimento =
        $_POST["data_nascimento"] ?? null;

    $genero = trim(
        $_POST["genero"] ?? ""
    );


    if ($nome === "" || $email === "") {

        responder([
            "erro" => "Nome e e-mail são obrigatórios."
        ]);

    }


    $sql = "
        UPDATE tb_cadastroaluno
        SET
            nome = ?,
            email = ?,
            telefone = ?,
            data_nascimento = NULLIF(?, ''),
            genero = ?
        WHERE id_aluno = ?
    ";

    $stmt = $conn->prepare($sql);

    $stmt->bind_param(
        "sssssi",
        $nome,
        $email,
        $telefone,
        $data_nascimento,
        $genero,
        $id_aluno
    );

    if (!$stmt->execute()) {

        responder([
            "erro" => "Não foi possível salvar os dados."
        ]);

    }


    $_SESSION["nome_aluno"] = $nome;


    responder([
        "sucesso" => true,
        "mensagem" => "Perfil atualizado com sucesso."
    ]);
}


/*
|--------------------------------------------------------------------------
| UPLOAD DA FOTO
|--------------------------------------------------------------------------
*/

if ($acao === "upload_foto") {

    if (
        !isset($_FILES["foto"]) ||
        $_FILES["foto"]["error"] !== UPLOAD_ERR_OK
    ) {

        responder([
            "erro" => "Nenhuma foto foi enviada."
        ]);

    }


    $arquivo = $_FILES["foto"];


    if ($arquivo["size"] > 5 * 1024 * 1024) {

        responder([
            "erro" => "A foto pode ter no máximo 5 MB."
        ]);

    }


    $finfo = new finfo(FILEINFO_MIME_TYPE);

    $mime = $finfo->file(
        $arquivo["tmp_name"]
    );


    $tiposPermitidos = [
        "image/jpeg" => "jpg",
        "image/png" => "png",
        "image/webp" => "webp"
    ];


    if (
        !isset($tiposPermitidos[$mime])
    ) {

        responder([
            "erro" => "Formato inválido. Use JPG, PNG ou WEBP."
        ]);

    }


    $extensao =
        $tiposPermitidos[$mime];


    $pasta = __DIR__
        . "/../img/perfil_aluno";


    if (!is_dir($pasta)) {

        mkdir(
            $pasta,
            0755,
            true
        );

    }


    /*
     * Busca a foto antiga
     */

    $stmt = $conn->prepare("
        SELECT foto
        FROM tb_cadastroaluno
        WHERE id_aluno = ?
        LIMIT 1
    ");

    $stmt->bind_param(
        "i",
        $id_aluno
    );

    $stmt->execute();

    $resultado =
        $stmt->get_result();

    $dados =
        $resultado->fetch_assoc();

    $fotoAntiga =
        $dados["foto"] ?? null;


    /*
     * Novo nome
     */

    $nomeArquivo =
        "aluno_"
        . $id_aluno
        . "_"
        . bin2hex(random_bytes(8))
        . "."
        . $extensao;


    $caminhoCompleto =
        $pasta
        . "/"
        . $nomeArquivo;


    if (
        !move_uploaded_file(
            $arquivo["tmp_name"],
            $caminhoCompleto
        )
    ) {

        responder([
            "erro" => "Não foi possível salvar a foto."
        ]);

    }


    $caminhoBanco =
        "img/perfil_aluno/"
        . $nomeArquivo;


    /*
     * Atualiza banco
     */

    $stmt = $conn->prepare("
        UPDATE tb_cadastroaluno
        SET foto = ?
        WHERE id_aluno = ?
    ");

    $stmt->bind_param(
        "si",
        $caminhoBanco,
        $id_aluno
    );


    if (!$stmt->execute()) {

        if (file_exists($caminhoCompleto)) {
            unlink($caminhoCompleto);
        }

        responder([
            "erro" => "Não foi possível atualizar a foto."
        ]);

    }


    /*
     * Apaga foto antiga
     */

    if (
        $fotoAntiga &&
        strpos(
            $fotoAntiga,
            "img/perfil_aluno/"
        ) === 0
    ) {

        $arquivoAntigo =
            __DIR__
            . "/../"
            . $fotoAntiga;

        if (
            file_exists($arquivoAntigo)
        ) {

            unlink($arquivoAntigo);

        }

    }


    responder([
        "sucesso" => true,
        "foto" => $caminhoBanco
    ]);
}


/*
|--------------------------------------------------------------------------
| ALTERAR SENHA
|--------------------------------------------------------------------------
*/

if ($acao === "alterar_senha") {

    $senhaAtual =
        $_POST["senha_atual"] ?? "";

    $novaSenha =
        $_POST["nova_senha"] ?? "";

    if (
        $senhaAtual === "" ||
        $novaSenha === ""
    ) {

        responder([
            "erro" => "Preencha todos os campos."
        ]);

    }


    if (strlen($novaSenha) < 6) {

        responder([
            "erro" => "A nova senha deve ter pelo menos 6 caracteres."
        ]);

    }


    $stmt = $conn->prepare("
        SELECT senha
        FROM tb_cadastroaluno
        WHERE id_aluno = ?
        LIMIT 1
    ");

    $stmt->bind_param(
        "i",
        $id_aluno
    );

    $stmt->execute();

    $resultado =
        $stmt->get_result();

    $dados =
        $resultado->fetch_assoc();


    if (!$dados) {

        responder([
            "erro" => "Aluno não encontrado."
        ]);

    }


    if (
        !password_verify(
            $senhaAtual,
            $dados["senha"]
        )
    ) {

        responder([
            "erro" => "A senha atual está incorreta."
        ]);

    }


    $senhaHash =
        password_hash(
            $novaSenha,
            PASSWORD_DEFAULT
        );


    $stmt = $conn->prepare("
        UPDATE tb_cadastroaluno
        SET senha = ?
        WHERE id_aluno = ?
    ");

    $stmt->bind_param(
        "si",
        $senhaHash,
        $id_aluno
    );


    if (!$stmt->execute()) {

        responder([
            "erro" => "Não foi possível alterar a senha."
        ]);

    }


    responder([
        "sucesso" => true,
        "mensagem" => "Senha alterada com sucesso."
    ]);
}


responder([
    "erro" => "Ação inválida."
]);