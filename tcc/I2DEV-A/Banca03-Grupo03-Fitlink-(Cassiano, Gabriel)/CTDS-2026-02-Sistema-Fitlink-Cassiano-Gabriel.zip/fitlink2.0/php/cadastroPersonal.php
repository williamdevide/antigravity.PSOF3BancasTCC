
<?php

include "conexao.php";

function mensagemRedirecionamento($mensagem, $destino) {
    $msg = json_encode($mensagem, JSON_UNESCAPED_UNICODE);
    $url = json_encode($destino);

    echo "<script>
        alert($msg);
        window.location.href = $url;
    </script>";

    exit;
}

if ($_SERVER["REQUEST_METHOD"] !== "POST") {
    header("Location: ../html/cadastro.html");
    exit;
}

$nome = trim($_POST["nome"] ?? "");
$email = trim($_POST["email"] ?? "");
$telefone = trim($_POST["telefone"] ?? "");
$data = $_POST["data_nascimento"] ?? "";
$genero = trim($_POST["genero"] ?? "");
$senha = $_POST["senha"] ?? "";
$id_cref = trim($_POST["id_cref"] ?? "");

if (
    $nome === "" ||
    $email === "" ||
    $senha === "" ||
    !ctype_digit($id_cref)
) {
    mensagemRedirecionamento(
        "Preencha corretamente os campos obrigatórios.",
        "../html/cadastro.html"
    );
}

if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    mensagemRedirecionamento(
        "Informe um e-mail válido.",
        "../html/cadastro.html"
    );
}

try {

    // Verificar se o CREF já existe
    $verificar = $conn->prepare(
        "SELECT id_cref
         FROM tb_cadastropersonal
         WHERE id_cref = ?
         LIMIT 1"
    );

    $verificar->bind_param("i", $id_cref);
    $verificar->execute();
    $verificar->store_result();

    if ($verificar->num_rows > 0) {
        $verificar->close();

        mensagemRedirecionamento(
            "Este CREF já está cadastrado! Faça login ou utilize outro CREF válido.",
            "../html/login.html"
        );
    }

    $verificar->close();

    // Criptografar senha
    $senhaHash = password_hash(
        $senha,
        PASSWORD_DEFAULT
    );

    // Cadastrar Personal
    $sql = "INSERT INTO tb_cadastropersonal
        (
            id_cref,
            nome,
            email,
            telefone,
            data_nascimento,
            genero,
            senha
        )
        VALUES (?, ?, ?, ?, ?, ?, ?)";

    $stmt = $conn->prepare($sql);

    $stmt->bind_param(
        "issssss",
        $id_cref,
        $nome,
        $email,
        $telefone,
        $data,
        $genero,
        $senhaHash
    );

    $stmt->execute();
    $stmt->close();

    mensagemRedirecionamento(
        "Personal cadastrado com sucesso!",
        "../html/login.html"
    );

} catch (mysqli_sql_exception $erro) {

    if ($erro->getCode() == 1062) {

        mensagemRedirecionamento(
            "Este CREF já está cadastrado!",
            "../html/login.html"
        );

    }

    error_log($erro->getMessage());

    mensagemRedirecionamento(
        "Não foi possível realizar o cadastro. Tente novamente.",
        "../html/cadastro.html"
    );
}

?>
