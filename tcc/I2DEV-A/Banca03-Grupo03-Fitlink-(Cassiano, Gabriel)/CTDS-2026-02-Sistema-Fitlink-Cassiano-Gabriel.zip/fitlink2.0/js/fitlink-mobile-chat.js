/* FITLINK | Navegação do chat do Personal em telas pequenas.
   Apenas alterna as duas áreas já existentes; não altera mensagens. */
(() => {
    document.addEventListener('DOMContentLoaded', () => {
        const layout = document.querySelector('.fl-page-meusAlunos .dm-container');
        const lista = document.getElementById('listaAlunos');
        const voltar = document.getElementById('flVoltarConversas');

        if (!layout || !lista || !voltar) return;

        lista.addEventListener('click', (evento) => {
            if (evento.target.closest('.conversa')) {
                layout.classList.add('fl-chat-aberto');
            }
        });

        voltar.addEventListener('click', () => {
            layout.classList.remove('fl-chat-aberto');
        });

        // Ao voltar para a largura de desktop, mantém ambas as colunas disponíveis.
        window.addEventListener('resize', () => {
            if (window.innerWidth > 600) {
                layout.classList.remove('fl-chat-aberto');
            }
        });
    });
})();
