
/* =========================================
   FITLINK - NOTIFICAÇÕES DO PERSONAL
========================================= */

(() => {

    const URL_NOTIFICACOES =
        "../../php/notificacoes_personal.php";


    // Adicionar estilos apenas da notificação
    const estilo = document.createElement("style");

    estilo.textContent = `
        .notificacao-personal {
            display: inline-block;
            width: 10px;
            height: 10px;
            min-width: 10px;
            border-radius: 50%;
            background: #D4AF37;
            box-shadow: 0 0 8px rgba(212,175,55,0.55);
            margin-left: 7px;
            vertical-align: middle;
        }

        .notificacao-personal[hidden] {
            display: none !important;
        }
    `;

    document.head.appendChild(estilo);


    function encontrarBolinha() {

        // Encontrar o link Mensagens no menu
        const links = document.querySelectorAll(
            'a[href*="meusAlunos.html"]'
        );

        for (const link of links) {

            let bolinha = link.querySelector(
                ".notificacao-personal"
            );

            if (!bolinha) {

                bolinha = document.createElement("span");

                bolinha.className =
                    "notificacao-personal";

                bolinha.hidden = true;

                bolinha.setAttribute(
                    "aria-hidden",
                    "true"
                );

                link.appendChild(bolinha);
            }

            return bolinha;
        }

        return null;
    }


    async function verificarNotificacoesPersonal() {

        const bolinha = encontrarBolinha();

        if (!bolinha) {
            return;
        }

        try {

            const resposta = await fetch(
                URL_NOTIFICACOES,
                {
                    method: "GET",
                    credentials: "same-origin",
                    cache: "no-store"
                }
            );

            if (!resposta.ok) {
                throw new Error(
                    "Falha ao consultar notificações."
                );
            }

            const dados = await resposta.json();

            if (dados.erro) {
                throw new Error(dados.erro);
            }

            const total = Number(dados.total) || 0;

            bolinha.hidden = total === 0;

            bolinha.parentElement.title =
                total > 0
                    ? `${total} mensagem(ns) não lida(s)`
                    : "Mensagens";

        } catch (erro) {

            console.error(
                "Erro nas notificações do Personal:",
                erro
            );
        }
    }


    document.addEventListener(
        "DOMContentLoaded",
        () => {

            verificarNotificacoesPersonal();

            setInterval(() => {

                if (!document.hidden) {
                    verificarNotificacoesPersonal();
                }

            }, 10000);

        }
    );


    document.addEventListener(
        "visibilitychange",
        () => {

            if (!document.hidden) {
                verificarNotificacoesPersonal();
            }

        }
    );


    window.addEventListener(
        "pageshow",
        verificarNotificacoesPersonal
    );

})();
