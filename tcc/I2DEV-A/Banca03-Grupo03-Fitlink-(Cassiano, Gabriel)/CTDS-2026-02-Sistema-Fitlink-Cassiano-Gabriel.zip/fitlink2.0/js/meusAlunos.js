// ==================================================
// FITLINK - MENSAGENS DO PERSONAL
// ==================================================

let alunos = [];
let alunoSelecionado = null;


// ==================================================
// CARREGAR ALUNOS
// ==================================================

function carregarAlunos() {

    const lista = document.getElementById("listaAlunos");

    lista.innerHTML = `
        <p class="carregando">
            Carregando conversas...
        </p>
    `;

    fetch("../../php/meus_alunos.php?acao=listar", {
        cache: "no-store"
    })

    .then(response => {

        if (!response.ok) {
            throw new Error(
                "Erro HTTP: " + response.status
            );
        }

        return response.json();

    })

    .then(dados => {

        if (dados.erro) {
            throw new Error(dados.erro);
        }

        alunos = Array.isArray(dados)
            ? dados
            : [];

        mostrarAlunos(alunos);

    })

    .catch(error => {

        console.error(error);

        lista.innerHTML = `
            <p class="erro">
                ${escapeHtml(
                    error.message ||
                    "Erro ao carregar as conversas."
                )}
            </p>
        `;

    });
}




function iniciaisAluno(nome) {
    const partes = String(nome || "?").trim().split(/\s+/).filter(Boolean);
    if (!partes.length) return "?";
    if (partes.length === 1) return escapeHtml(partes[0].charAt(0).toUpperCase());
    return escapeHtml((partes[0].charAt(0) + partes[partes.length - 1].charAt(0)).toUpperCase());
}

function htmlAvatarAluno(foto, nome) {
    if (foto) {
        return `<img src="../../${escapeHtml(String(foto))}" alt="Foto de ${escapeHtml(nome || 'Aluno')}" class="avatar-foto" onerror="this.style.display='none';this.nextElementSibling.style.display='flex';"><span class="avatar-iniciais" style="display:none;">${iniciaisAluno(nome)}</span>`;
    }
    return `<span class="avatar-iniciais">${iniciaisAluno(nome)}</span>`;
}

// ==================================================
// MOSTRAR ALUNOS
// ==================================================

function mostrarAlunos(lista) {

    const container =
        document.getElementById("listaAlunos");

    container.innerHTML = "";

    if (
        !Array.isArray(lista) ||
        lista.length === 0
    ) {

        container.innerHTML = `
            <p class="sem-alunos">
                Nenhum aluno possui
                conversa ou aula com você.
            </p>
        `;

        return;
    }


    lista.forEach(aluno => {

        const conversa =
            document.createElement("div");

        conversa.classList.add("conversa");

        conversa.dataset.nome =
            String(aluno.nome || "")
                .toLowerCase();


        const primeiraLetra =
            String(aluno.nome || "?")
                .charAt(0)
                .toUpperCase();


        let statusTexto = "Sem aula";


        if (aluno.status === "pendente") {

            statusTexto =
                "🟡 Nova solicitação";

        }

        else if (aluno.status === "confirmada") {

            statusTexto =
                "🟢 Aula confirmada";

        }

        else if (aluno.status === "cancelada") {

            statusTexto =
                "🔴 Aula cancelada";

        }

        else if (aluno.status === "remarcada") {

            statusTexto =
                "🔄 Aula remarcada";

        }


        conversa.innerHTML = `

            <div class="avatar">
                ${htmlAvatarAluno(aluno.foto, aluno.nome)}
            </div>

            <div class="conversa-info">

                <div class="conversa-topo">

                    <h3>
                        ${escapeHtml(aluno.nome)}
                    </h3>

                </div>

                <p>
                    ${statusTexto}
                </p>

                ${
                    aluno.ultima_mensagem
                    ?
                    `
                    <small>
                        ${escapeHtml(
                            aluno.ultima_mensagem
                        )}
                    </small>
                    `
                    :
                    ""
                }

            </div>

        `;


        conversa.addEventListener(
            "click",
            function () {

                document
                    .querySelectorAll(".conversa")
                    .forEach(item => {

                        item.classList.remove(
                            "conversa-ativa"
                        );

                    });


                conversa.classList.add(
                    "conversa-ativa"
                );


                selecionarAluno(aluno);

            }
        );


        container.appendChild(conversa);

    });

}


// ==================================================
// SELECIONAR ALUNO
// ==================================================

function selecionarAluno(aluno) {

    alunoSelecionado = aluno;


    const nome =
        aluno.nome || "Aluno";


    document.getElementById(
        "nomeAluno"
    ).textContent = nome;


    document.getElementById(
        "avatarAluno"
    ).innerHTML =
        htmlAvatarAluno(
            aluno.foto,
            nome
        );


    document.getElementById(
        "statusAluno"
    ).textContent =
        aluno.status
        ?
        formatarStatus(aluno.status)
        :
        "Aluno";


    carregarMensagensAluno();

}


// ==================================================
// STATUS
// ==================================================

function formatarStatus(status) {

    switch (status) {

        case "pendente":
            return "Nova solicitação";

        case "confirmada":
            return "Aula confirmada";

        case "cancelada":
            return "Aula cancelada";

        case "remarcada":
            return "Aula remarcada";

        default:
            return "Aluno";

    }

}


// ==================================================
// CARREGAR MENSAGENS
// ==================================================

function carregarMensagensAluno() {

    if (!alunoSelecionado) {
        return;
    }


    const mensagens =
        document.getElementById("mensagens");


    mensagens.innerHTML = `

        <div class="chat-inicial">

            <div class="chat-inicial-icone">
                ⏳
            </div>

            <p>
                Carregando conversa...
            </p>

        </div>

    `;


    fetch(
        "../../php/meus_alunos.php?acao=mensagens&id_aluno="
        +
        encodeURIComponent(
            alunoSelecionado.id_aluno
        ),
        {
            cache: "no-store"
        }
    )

    .then(response => {

        if (!response.ok) {

            throw new Error(
                "Erro HTTP: " +
                response.status
            );

        }

        return response.json();

    })

    .then(dados => {

        if (dados.erro) {
            throw new Error(dados.erro);
        }


        mostrarMensagens(dados);

        mostrarBotoesAula();

    })

    .catch(error => {

        console.error(error);


        mensagens.innerHTML = `

            <div class="chat-inicial">

                <div class="chat-inicial-icone">
                    ⚠️
                </div>

                <h2>
                    Erro
                </h2>

                <p>
                    ${escapeHtml(error.message)}
                </p>

            </div>

        `;

    });

}


// ==================================================
// MOSTRAR MENSAGENS
// ==================================================

function mostrarMensagens(lista) {

    const container =
        document.getElementById("mensagens");


    container.innerHTML = "";


    if (
        !Array.isArray(lista) ||
        lista.length === 0
    ) {

        container.innerHTML = `

            <div class="chat-inicial">

                <div class="chat-inicial-icone">
                    💬
                </div>

                <h2>
                    Nenhuma mensagem
                </h2>

                <p>
                    Este aluno ainda não possui
                    mensagens nesta conversa.
                </p>

            </div>

        `;

        return;
    }


    lista.forEach(mensagem => {

        const bloco =
            document.createElement("div");


        bloco.classList.add("mensagem");


        bloco.classList.add(
            "mensagem-" +
            mensagem.remetente
        );


        let conteudo =
            escapeHtml(
                mensagem.mensagem
            );


        if (
            mensagem.tipo ===
            "agendamento"
        ) {

            conteudo =
                "📅 " + conteudo;

        }

        else if (
            mensagem.tipo ===
            "confirmacao"
        ) {

            conteudo =
                "✅ " + conteudo;

        }

        else if (
            mensagem.tipo ===
            "cancelamento"
        ) {

            conteudo =
                "❌ " + conteudo;

        }

        else if (
            mensagem.tipo ===
            "remarcacao"
        ) {

            conteudo =
                "🔄 " + conteudo;

        }


        bloco.innerHTML = `

            <div class="balao">

                ${conteudo}

                <span class="hora-mensagem">

                    ${formatarDataHora(
                        mensagem.data_envio
                    )}

                </span>

            </div>

        `;


        container.appendChild(bloco);

    });


    container.scrollTop =
        container.scrollHeight;

}


// ==================================================
// BOTÕES DA AULA
// ==================================================

function mostrarBotoesAula() {

    const acoes =
        document.getElementById(
            "acoesChat"
        );


    acoes.style.display =
        "none";


    if (
        !alunoSelecionado ||
        !alunoSelecionado.id_aula
    ) {

        return;

    }


    if (
        alunoSelecionado.status ===
        "pendente"
        ||
        alunoSelecionado.status ===
        "confirmada"
        ||
        alunoSelecionado.status ===
        "remarcada"
    ) {

        acoes.style.display =
            "flex";

    }

}


// ==================================================
// ALTERAR STATUS
// ==================================================

function alterarStatus(novoStatus) {

    if (
        !alunoSelecionado ||
        !alunoSelecionado.id_aula
    ) {

        alert(
            "Nenhuma aula selecionada."
        );

        return;
    }


    let mensagemConfirmacao =
        "Deseja confirmar esta ação?";


    if (
        novoStatus ===
        "confirmada"
    ) {

        mensagemConfirmacao =
            "Deseja confirmar esta aula?";

    }

    else if (
        novoStatus ===
        "cancelada"
    ) {

        mensagemConfirmacao =
            "Deseja cancelar esta aula?";

    }


    if (
        !confirm(
            mensagemConfirmacao
        )
    ) {

        return;

    }


    const dados =
        new FormData();


    dados.append(
        "acao",
        "alterar_status"
    );


    dados.append(
        "id_aula",
        alunoSelecionado.id_aula
    );


    dados.append(
        "status",
        novoStatus
    );


    fetch(
        "../../php/meus_alunos.php",
        {
            method: "POST",
            body: dados
        }
    )

    .then(response => {

        if (!response.ok) {

            throw new Error(
                "Erro HTTP: " +
                response.status
            );

        }

        return response.json();

    })

    .then(resultado => {

        if (!resultado.sucesso) {

            throw new Error(
                resultado.erro ||
                "Não foi possível alterar a aula."
            );

        }


        alunoSelecionado.status =
            novoStatus;


        alert(
            resultado.mensagem ||
            "Aula atualizada!"
        );


        carregarAlunos();

        carregarMensagensAluno();

    })

    .catch(error => {

        console.error(error);

        alert(
            error.message
        );

    });

}


// ==================================================
// ABRIR REMARCAÇÃO
// ==================================================

function abrirRemarcacao() {

    if (
        !alunoSelecionado ||
        !alunoSelecionado.id_aula
    ) {

        alert(
            "Nenhuma aula selecionada."
        );

        return;

    }


    const modal =
        document.getElementById(
            "modalRemarcacao"
        );


    const dataInput =
        document.getElementById(
            "novaData"
        );


    const hoje =
        new Date();


    const ano =
        hoje.getFullYear();


    const mes =
        String(
            hoje.getMonth() + 1
        ).padStart(2, "0");


    const dia =
        String(
            hoje.getDate()
        ).padStart(2, "0");


    dataInput.min =
        `${ano}-${mes}-${dia}`;


    dataInput.value =
        "";


    document.getElementById(
        "novoHorario"
    ).innerHTML = `

        <option value="">
            Selecione uma data primeiro
        </option>

    `;


    modal.style.display =
        "flex";

}


// ==================================================
// FECHAR REMARCAÇÃO
// ==================================================

function fecharRemarcacao() {

    document.getElementById(
        "modalRemarcacao"
    ).style.display =
        "none";

}


// ==================================================
// BUSCAR HORÁRIOS
// ==================================================

document
    .getElementById("novaData")
    .addEventListener(
        "change",
        function () {

            if (
                !alunoSelecionado ||
                !alunoSelecionado.id_aula
            ) {

                return;

            }


            const data =
                this.value;


            if (!data) {
                return;
            }


            const select =
                document.getElementById(
                    "novoHorario"
                );


            select.innerHTML = `

                <option value="">
                    Carregando horários...
                </option>

            `;


            fetch(
                "../../php/meus_alunos.php?acao=horarios_remarcacao"
                +
                "&id_aula="
                +
                encodeURIComponent(
                    alunoSelecionado.id_aula
                )
                +
                "&data="
                +
                encodeURIComponent(data),
                {
                    cache: "no-store"
                }
            )

            .then(response => {

                if (!response.ok) {

                    throw new Error(
                        "Erro HTTP: " +
                        response.status
                    );

                }

                return response.json();

            })

            .then(dados => {

                if (dados.erro) {

                    throw new Error(
                        dados.erro
                    );

                }


                select.innerHTML = `

                    <option value="">
                        Selecione um horário
                    </option>

                `;


                if (
                    !Array.isArray(dados) ||
                    dados.length === 0
                ) {

                    select.innerHTML = `

                        <option value="">
                            Nenhum horário disponível
                        </option>

                    `;

                    return;

                }


                dados.forEach(horario => {

                    const option =
                        document.createElement(
                            "option"
                        );


                    option.value =
                        horario.id_agenda;


                    option.textContent =
                        horario.horario
                        +
                        " - "
                        +
                        horario.nomeacademia;


                    select.appendChild(
                        option
                    );

                });

            })

            .catch(error => {

                console.error(error);


                select.innerHTML = `

                    <option value="">
                        ${escapeHtml(
                            error.message
                        )}
                    </option>

                `;

            });

        }
    );


// ==================================================
// CONFIRMAR REMARCAÇÃO
// ==================================================

function confirmarRemarcacao() {

    if (
        !alunoSelecionado ||
        !alunoSelecionado.id_aula
    ) {

        alert(
            "Nenhuma aula selecionada."
        );

        return;

    }


    const idAgenda =
        document.getElementById(
            "novoHorario"
        ).value;


    if (!idAgenda) {

        alert(
            "Escolha um novo horário."
        );

        return;

    }


    if (
        !confirm(
            "Deseja realmente remarcar esta aula?"
        )
    ) {

        return;

    }


    const dados =
        new FormData();


    dados.append(
        "acao",
        "remarcar"
    );


    dados.append(
        "id_aula",
        alunoSelecionado.id_aula
    );


    dados.append(
        "id_agenda_nova",
        idAgenda
    );


    fetch(
        "../../php/meus_alunos.php",
        {
            method: "POST",
            body: dados
        }
    )

    .then(response => {

        if (!response.ok) {

            throw new Error(
                "Erro HTTP: " +
                response.status
            );

        }

        return response.json();

    })

    .then(resultado => {

        if (!resultado.sucesso) {

            throw new Error(
                resultado.erro ||
                "Não foi possível remarcar."
            );

        }


        fecharRemarcacao();


        alert(
            resultado.mensagem ||
            "Aula remarcada!"
        );


        carregarAlunos();


        setTimeout(() => {

            const alunoAtualizado =
                alunos.find(
                    aluno =>
                        Number(aluno.id_aluno)
                        ===
                        Number(
                            alunoSelecionado.id_aluno
                        )
                );


            if (alunoAtualizado) {

                selecionarAluno(
                    alunoAtualizado
                );

            }

        }, 300);

    })

    .catch(error => {

        console.error(error);

        alert(
            error.message
        );

    });

}


// ==================================================
// PESQUISA
// ==================================================

document
    .getElementById("pesquisaAluno")
    .addEventListener(
        "input",
        function () {

            const pesquisa =
                this.value
                    .toLowerCase()
                    .trim();


            document
                .querySelectorAll(
                    ".conversa"
                )
                .forEach(conversa => {

                    const nome =
                        conversa.dataset.nome;


                    conversa.style.display =
                        nome.includes(pesquisa)
                        ? "flex"
                        : "none";

                });

        }
    );


// ==================================================
// FORMATAR DATA/HORA
// ==================================================

function formatarDataHora(valor) {

    if (!valor) {
        return "";
    }


    const data =
        new Date(
            String(valor)
                .replace(" ", "T")
        );


    if (
        isNaN(
            data.getTime()
        )
    ) {

        return "";

    }


    return data.toLocaleDateString(
        "pt-BR"
    )
    +
    " "
    +
    data.toLocaleTimeString(
        "pt-BR",
        {
            hour: "2-digit",
            minute: "2-digit"
        }
    );

}


// ==================================================
// ESCAPAR HTML
// ==================================================

function escapeHtml(valor) {

    return String(
        valor ?? ""
    )

    .replace(
        /&/g,
        "&amp;"
    )

    .replace(
        /</g,
        "&lt;"
    )

    .replace(
        />/g,
        "&gt;"
    )

    .replace(
        /"/g,
        "&quot;"
    )

    .replace(
        /'/g,
        "&#039;"
    );

}


// ==================================================
// SAIR
// ==================================================

function sair() {

    window.location.href =
        "../../php/logout.php";

}


// ==================================================
// INICIAR
// ==================================================

document.addEventListener(
    "DOMContentLoaded",
    function () {

        carregarAlunos();

    }
);