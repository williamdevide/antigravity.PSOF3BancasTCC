/* =========================================
   FITLINK - MENSAGENS DO ALUNO
========================================= */

const URL_PHP = "../../php/mensagens.php";

let crefSelecionado = null;

let horarioSelecionado = null;

let idAulaAtual = null;


/* =========================================
   INÍCIO
========================================= */

document.addEventListener(
    "DOMContentLoaded",
    function () {

        carregarConversas();

        configurarModal();

    }
);


/* =========================================
   CONVERSAS
========================================= */

function carregarConversas() {

    const lista =
        document.getElementById("listaConversas");

    lista.innerHTML =
        '<div class="carregando">Carregando conversas...</div>';


    fetch(
        URL_PHP +
        "?acao=listar_conversas",
        {
            cache: "no-store"
        }
    )

        .then(function (resposta) {

            return resposta.json();

        })

        .then(function (dados) {

            if (dados.erro) {

                throw new Error(dados.erro);

            }


            lista.innerHTML = "";


            if (
                !Array.isArray(dados) ||
                dados.length === 0
            ) {

                lista.innerHTML =
                    `
                    <div class="sem-conversas">
                        Você ainda não possui conversas.
                        <br><br>
                        Agende uma aula com um Personal
                        para iniciar.
                    </div>
                    `;

                return;

            }


            dados.forEach(function (conversa) {

                criarConversa(
                    conversa,
                    lista
                );

            });

        })

        .catch(function (erro) {

            console.error(erro);

            lista.innerHTML =
                `
                <div class="erro">
                    Não foi possível carregar suas conversas.
                </div>
                `;

        });

}


/* =========================================
   INICIAIS DO USUÁRIO
========================================= */

function iniciaisUsuario(nome) {

    const partes =
        String(nome || "?")
            .trim()
            .split(/\s+/)
            .filter(Boolean);


    if (!partes.length) {

        return "?";

    }


    if (partes.length === 1) {

        return esc(
            partes[0]
                .charAt(0)
                .toUpperCase()
        );

    }


    return esc(
        (
            partes[0].charAt(0) +
            partes[
                partes.length - 1
            ].charAt(0)
        ).toUpperCase()
    );

}


/* =========================================
   AVATAR
========================================= */

function htmlAvatar(
    foto,
    nome
) {

    if (foto) {

        return `
            <img
                src="../../${esc(String(foto))}"
                alt="Foto de ${esc(nome || "Personal")}"
                class="avatar-foto"
                onerror="
                    this.style.display='none';
                    this.nextElementSibling.style.display='flex';
                "
            >

            <span
                class="avatar-iniciais"
                style="display:none;"
            >
                ${iniciaisUsuario(nome)}
            </span>
        `;

    }


    return `
        <span class="avatar-iniciais">
            ${iniciaisUsuario(nome)}
        </span>
    `;

}


/* =========================================
   CRIAR CONVERSA
========================================= */

function criarConversa(
    conversa,
    lista
) {

    const elemento =
        document.createElement("div");


    elemento.className =
        "conversa";


    elemento.innerHTML =
        `
        <div class="avatar-pequeno">

            ${htmlAvatar(
                conversa.foto,
                conversa.nome
            )}

        </div>


        <div class="conversa-info">

            <div class="conversa-linha">

                <h3>
                    ${esc(conversa.nome)}
                </h3>


                <span class="conversa-data">

                    ${dataHora(
                        conversa.data_ultima
                    )}

                </span>

            </div>


            <div class="ultima-mensagem">

                ${esc(
                    conversa.ultima_mensagem ||
                    "Nenhuma mensagem"
                )}

            </div>


            ${
                Number(
                    conversa.nao_lidas
                ) > 0

                    ?

                    `
                    <span class="badge">
                        ${conversa.nao_lidas}
                    </span>
                    `

                    :

                    ""
            }

        </div>
        `;


    elemento.onclick =
        function () {

            document
                .querySelectorAll(
                    ".conversa"
                )
                .forEach(
                    function (item) {

                        item.classList.remove(
                            "ativa"
                        );

                    }
                );


            elemento.classList.add(
                "ativa"
            );


            abrirConversa(
                conversa.id_cref,
                conversa.nome,
                conversa.foto
            );

        };


    lista.appendChild(
        elemento
    );

}


/* =========================================
   ABRIR CONVERSA
========================================= */

function abrirConversa(
    cref,
    nome,
    foto
) {

    crefSelecionado =
        Number(cref);


    document
        .getElementById(
            "chatVazio"
        )
        .classList.add(
            "escondido"
        );


    document
        .getElementById(
            "chatAtivo"
        )
        .classList.remove(
            "escondido"
        );


    document
        .getElementById(
            "nomePersonal"
        )
        .textContent =
        nome;


    document
        .getElementById(
            "crefPersonal"
        )
        .textContent =
        cref;


    const avatarCabecalho =
        document.querySelector(
            ".chat-header .avatar"
        );


    if (avatarCabecalho) {

        avatarCabecalho.innerHTML =
            htmlAvatar(
                foto,
                nome
            );

    }


    carregarMensagens();


    /*
     * Verifica se o aluno
     * pode avaliar esse Personal
     */

    verificarFeedback();

}


/* =========================================
   CARREGAR MENSAGENS
========================================= */

function carregarMensagens() {

    if (!crefSelecionado) {

        return;

    }


    const lista =
        document.getElementById(
            "listaMensagens"
        );


    lista.innerHTML =
        `
        <div class="carregando">
            Carregando mensagens...
        </div>
        `;


    fetch(

        URL_PHP +
        "?acao=listar_mensagens&id_cref=" +
        encodeURIComponent(
            crefSelecionado
        ),

        {
            cache: "no-store"
        }

    )

        .then(
            function (resposta) {

                return resposta.json();

            }
        )

        .then(
            function (dados) {

                if (dados.erro) {

                    throw new Error(
                        dados.erro
                    );

                }


                lista.innerHTML = "";


                if (
                    !Array.isArray(dados) ||
                    dados.length === 0
                ) {

                    lista.innerHTML =
                        `
                        <div class="sem-mensagens">
                            Nenhuma mensagem nesta conversa.
                        </div>
                        `;

                    return;

                }


                dados.forEach(
                    function (mensagem) {

                        const elemento =
                            document.createElement(
                                "div"
                            );


                        elemento.className =
                            "mensagem " +
                            mensagem.remetente;


                        elemento.innerHTML =
                            `
                            ${esc(
                                mensagem.mensagem
                            )}

                            <span class="mensagem-hora">

                                ${dataHora(
                                    mensagem.data_envio
                                )}

                            </span>
                            `;


                        lista.appendChild(
                            elemento
                        );

                    }
                );


                lista.scrollTop =
                    lista.scrollHeight;

            }
        )

        .catch(
            function (erro) {

                console.error(
                    erro
                );


                lista.innerHTML =
                    `
                    <div class="erro">
                        Não foi possível carregar as mensagens.
                    </div>
                    `;

            }
        );

}


/* =========================================
   ENVIAR MENSAGEM PADRÃO
========================================= */

function enviarMensagem(
    mensagem
) {

    if (!crefSelecionado) {

        alert(
            "Selecione uma conversa primeiro."
        );

        return;

    }


    const dados =
        new FormData();


    dados.append(
        "acao",
        "enviar"
    );


    dados.append(
        "id_cref",
        crefSelecionado
    );


    dados.append(
        "mensagem",
        mensagem
    );


    bloquearBotoes(
        true
    );


    fetch(
        URL_PHP,
        {
            method: "POST",
            body: dados
        }
    )

        .then(
            function (resposta) {

                return resposta.json();

            }
        )

        .then(
            function (resultado) {

                if (
                    !resultado.sucesso
                ) {

                    throw new Error(
                        resultado.erro ||
                        "Não foi possível enviar a mensagem."
                    );

                }


                carregarMensagens();

                carregarConversas();

            }
        )

        .catch(
            function (erro) {

                console.error(
                    erro
                );

                alert(
                    erro.message
                );

            }
        )

        .finally(
            function () {

                bloquearBotoes(
                    false
                );

            }
        );

}


/* =========================================
   REMARCAÇÃO
========================================= */

function abrirRemarcacao() {

    if (!crefSelecionado) {

        alert(
            "Selecione uma conversa primeiro."
        );

        return;

    }


    horarioSelecionado =
        null;


    document
        .getElementById(
            "horarioEscolhido"
        )
        .classList.add(
            "escondido"
        );


    document
        .getElementById(
            "horariosRemarcacao"
        )
        .innerHTML =
        `
        <div class="mensagem-horarios">
            Escolha uma data e uma academia.
        </div>
        `;


    const data =
        document.getElementById(
            "remarcacaoData"
        );


    definirDataMinima(
        data
    );


    carregarAcademiasRemarcacao();


    document
        .getElementById(
            "modalRemarcacao"
        )
        .classList.add(
            "ativo"
        );

}


/* =========================================
   DATA MÍNIMA
========================================= */

function definirDataMinima(
    campo
) {

    const hoje =
        new Date();


    const ano =
        hoje.getFullYear();


    const mes =
        String(
            hoje.getMonth() + 1
        ).padStart(
            2,
            "0"
        );


    const dia =
        String(
            hoje.getDate()
        ).padStart(
            2,
            "0"
        );


    const dataHoje =
        `${ano}-${mes}-${dia}`;


    campo.min =
        dataHoje;


    if (!campo.value) {

        campo.value =
            dataHoje;

    }

}


/* =========================================
   ACADEMIAS DA REMARCAÇÃO
========================================= */

function carregarAcademiasRemarcacao() {

    const select =
        document.getElementById(
            "remarcacaoAcademia"
        );


    select.innerHTML =
        `
        <option value="">
            Carregando academias...
        </option>
        `;


    fetch(

        URL_PHP +
        "?acao=academias&id_cref=" +
        encodeURIComponent(
            crefSelecionado
        ),

        {
            cache: "no-store"
        }

    )

        .then(
            function (resposta) {

                return resposta.json();

            }
        )

        .then(
            function (dados) {

                select.innerHTML =
                    `
                    <option value="">
                        Selecione a academia
                    </option>
                    `;


                if (dados.erro) {

                    throw new Error(
                        dados.erro
                    );

                }


                if (
                    !Array.isArray(dados) ||
                    dados.length === 0
                ) {

                    select.innerHTML =
                        `
                        <option value="">
                            Nenhuma academia encontrada
                        </option>
                        `;

                    return;

                }


                dados.forEach(
                    function (academia) {

                        const option =
                            document.createElement(
                                "option"
                            );


                        option.value =
                            academia.id_academia;


                        option.textContent =
                            academia.nomeacademia;


                        select.appendChild(
                            option
                        );

                    }
                );

            }
        )

        .catch(
            function (erro) {

                console.error(
                    erro
                );


                select.innerHTML =
                    `
                    <option value="">
                        Erro ao carregar academias
                    </option>
                    `;

            }
        );

}
/* =========================================
   CONFIGURAR MODAL
========================================= */

function configurarModal() {

    const campoData =
        document.getElementById(
            "remarcacaoData"
        );


    const campoAcademia =
        document.getElementById(
            "remarcacaoAcademia"
        );


    if (campoData) {

        campoData.addEventListener(
            "change",
            function () {

                horarioSelecionado =
                    null;


                document
                    .getElementById(
                        "horarioEscolhido"
                    )
                    ?.classList.add(
                        "escondido"
                    );


                carregarHorariosRemarcacao();

            }
        );

    }


    if (campoAcademia) {

        campoAcademia.addEventListener(
            "change",
            function () {

                horarioSelecionado =
                    null;


                document
                    .getElementById(
                        "horarioEscolhido"
                    )
                    ?.classList.add(
                        "escondido"
                    );


                carregarHorariosRemarcacao();

            }
        );

    }

}


/* =========================================
   CARREGAR HORÁRIOS PARA REMARCAÇÃO
========================================= */

function carregarHorariosRemarcacao() {

    if (!crefSelecionado) {

        return;

    }


    const campoData =
        document.getElementById(
            "remarcacaoData"
        );


    const campoAcademia =
        document.getElementById(
            "remarcacaoAcademia"
        );


    const container =
        document.getElementById(
            "horariosRemarcacao"
        );


    if (
        !campoData ||
        !campoAcademia ||
        !container
    ) {

        return;

    }


    const data =
        campoData.value;


    const academia =
        campoAcademia.value;


    if (!data || !academia) {

        container.innerHTML =
            `
            <div class="mensagem-horarios">
                Escolha uma data e uma academia.
            </div>
            `;

        return;

    }


    container.innerHTML =
        `
        <div class="mensagem-horarios">
            Carregando horários disponíveis...
        </div>
        `;


    const url =
        URL_PHP +
        "?acao=horarios_remarcacao" +
        "&id_cref=" +
        encodeURIComponent(
            crefSelecionado
        ) +
        "&dia=" +
        encodeURIComponent(
            data
        ) +
        "&id_academia=" +
        encodeURIComponent(
            academia
        );


    fetch(
        url,
        {
            cache: "no-store"
        }
    )

        .then(
            function (resposta) {

                return resposta.json();

            }
        )

        .then(
            function (dados) {

                container.innerHTML =
                    "";


                if (dados.erro) {

                    throw new Error(
                        dados.erro
                    );

                }


                /*
                 * O PHP pode retornar diretamente
                 * um array ou um objeto contendo
                 * a propriedade horarios.
                 */

                const horarios =
                    Array.isArray(dados)
                        ? dados
                        : (
                            Array.isArray(
                                dados.horarios
                            )
                                ? dados.horarios
                                : []
                        );


                if (
                    horarios.length === 0
                ) {

                    container.innerHTML =
                        `
                        <div class="mensagem-horarios">
                            Não existem horários disponíveis
                            para essa data e academia.
                        </div>
                        `;

                    return;

                }


                horarios.forEach(
                    function (horario) {

                        criarBotaoHorario(
                            horario,
                            container
                        );

                    }
                );

            }
        )

        .catch(
            function (erro) {

                console.error(
                    "Erro ao carregar horários:",
                    erro
                );


                container.innerHTML =
                    `
                    <div class="mensagem-horarios erro">
                        ${esc(
                            erro.message ||
                            "Não foi possível carregar os horários."
                        )}
                    </div>
                    `;

            }
        );

}


/* =========================================
   CRIAR BOTÃO DE HORÁRIO
========================================= */

function criarBotaoHorario(
    horario,
    container
) {

    const botao =
        document.createElement(
            "button"
        );


    botao.type =
        "button";


    botao.className =
        "horario-remarcacao";


    /*
     * Aceita tanto o formato:
     *
     * {
     *   id_agenda: 1,
     *   horario: "18:00:00"
     * }
     *
     * quanto nomes semelhantes retornados
     * pelo backend.
     */

    const idAgenda =
        horario.id_agenda ??
        horario.id ??
        null;


    const hora =
        horario.horario ??
        horario.hora ??
        "";


    botao.textContent =
        formatarHorario(
            hora
        );


    botao.dataset.idAgenda =
        idAgenda || "";


    botao.dataset.horario =
        hora;


    botao.onclick =
        function () {

            selecionarHorarioRemarcacao(
                botao,
                horario
            );

        };


    container.appendChild(
        botao
    );

}


/* =========================================
   SELECIONAR HORÁRIO
========================================= */

function selecionarHorarioRemarcacao(
    botao,
    horario
) {

    document
        .querySelectorAll(
            ".horario-remarcacao"
        )
        .forEach(
            function (item) {

                item.classList.remove(
                    "selecionado"
                );

            }
        );


    botao.classList.add(
        "selecionado"
    );


    horarioSelecionado = {

        id_agenda:
            horario.id_agenda ??
            horario.id ??
            null,

        horario:
            horario.horario ??
            horario.hora ??
            ""

    };


    const caixa =
        document.getElementById(
            "horarioEscolhido"
        );


    if (caixa) {

        caixa.classList.remove(
            "escondido"
        );


        caixa.innerHTML =
            `
            Horário selecionado:
            <strong>
                ${formatarHorario(
                    horarioSelecionado.horario
                )}
            </strong>
            `;

    }

}


/* =========================================
   CONFIRMAR REMARCAÇÃO
========================================= */

function confirmarRemarcacao() {

    if (!crefSelecionado) {

        alert(
            "Selecione uma conversa primeiro."
        );

        return;

    }


    if (
        !horarioSelecionado ||
        !horarioSelecionado.id_agenda
    ) {

        alert(
            "Selecione um novo horário."
        );

        return;

    }


    const botao =
        document.getElementById(
            "btnConfirmarRemarcacao"
        );


    if (botao) {

        botao.disabled =
            true;


        botao.dataset.textoOriginal =
            botao.textContent;


        botao.textContent =
            "Remarcando...";

    }


    const dados =
        new FormData();


    dados.append(
        "acao",
        "remarcar"
    );


    dados.append(
        "id_cref",
        crefSelecionado
    );


    dados.append(
        "id_agenda",
        horarioSelecionado.id_agenda
    );


    if (idAulaAtual) {

        dados.append(
            "id_aula",
            idAulaAtual
        );

    }


    fetch(
        URL_PHP,
        {
            method: "POST",
            body: dados
        }
    )

        .then(
            function (resposta) {

                return resposta.text();

            }
        )

        .then(
            function (texto) {

                let resultado;


                try {

                    resultado =
                        JSON.parse(
                            texto
                        );

                } catch (erro) {

                    console.error(
                        "Resposta do PHP:",
                        texto
                    );


                    throw new Error(
                        "O servidor retornou uma resposta inválida."
                    );

                }


                if (
                    resultado.erro ||
                    resultado.sucesso === false
                ) {

                    throw new Error(
                        resultado.erro ||
                        "Não foi possível remarcar a aula."
                    );

                }


                fecharRemarcacao();


                alert(
                    resultado.mensagem ||
                    "Aula remarcada com sucesso!"
                );


                carregarMensagens();

                carregarConversas();

                verificarFeedback();

            }
        )

        .catch(
            function (erro) {

                console.error(
                    "Erro ao remarcar:",
                    erro
                );


                alert(
                    erro.message ||
                    "Não foi possível remarcar a aula."
                );

            }
        )

        .finally(
            function () {

                if (botao) {

                    botao.disabled =
                        false;


                    botao.textContent =
                        botao.dataset.textoOriginal ||
                        "Confirmar remarcação";

                }

            }
        );

}


/* =========================================
   FECHAR REMARCAÇÃO
========================================= */

function fecharRemarcacao() {

    const modal =
        document.getElementById(
            "modalRemarcacao"
        );


    if (modal) {

        modal.classList.remove(
            "ativo"
        );

    }


    horarioSelecionado =
        null;


    const horarioEscolhido =
        document.getElementById(
            "horarioEscolhido"
        );


    if (horarioEscolhido) {

        horarioEscolhido.classList.add(
            "escondido"
        );

    }

}


/* =========================================
   CANCELAMENTO
========================================= */

function abrirCancelamento() {

    if (!crefSelecionado) {

        alert(
            "Selecione uma conversa primeiro."
        );

        return;

    }


    const modal =
        document.getElementById(
            "modalCancelamento"
        );


    if (modal) {

        modal.classList.add(
            "ativo"
        );

        return;

    }


    /*
     * Caso seu HTML ainda não tenha um modal
     * específico de cancelamento, utiliza
     * confirmação padrão do navegador.
     */

    const confirmar =
        window.confirm(
            "Tem certeza que deseja cancelar sua aula?"
        );


    if (confirmar) {

        confirmarCancelamento();

    }

}


/* =========================================
   FECHAR CANCELAMENTO
========================================= */

function fecharCancelamento() {

    const modal =
        document.getElementById(
            "modalCancelamento"
        );


    if (modal) {

        modal.classList.remove(
            "ativo"
        );

    }

}


/* =========================================
   CONFIRMAR CANCELAMENTO
========================================= */

function confirmarCancelamento() {

    if (!crefSelecionado) {

        return;

    }


    const dados =
        new FormData();


    dados.append(
        "acao",
        "cancelar"
    );


    dados.append(
        "id_cref",
        crefSelecionado
    );


    if (idAulaAtual) {

        dados.append(
            "id_aula",
            idAulaAtual
        );

    }


    fetch(
        URL_PHP,
        {
            method: "POST",
            body: dados
        }
    )

        .then(
            function (resposta) {

                return resposta.text();

            }
        )

        .then(
            function (texto) {

                let resultado;


                try {

                    resultado =
                        JSON.parse(
                            texto
                        );

                } catch (erro) {

                    console.error(
                        texto
                    );


                    throw new Error(
                        "O servidor retornou uma resposta inválida."
                    );

                }


                if (
                    resultado.erro ||
                    resultado.sucesso === false
                ) {

                    throw new Error(
                        resultado.erro ||
                        "Não foi possível cancelar a aula."
                    );

                }


                fecharCancelamento();


                alert(
                    resultado.mensagem ||
                    "Aula cancelada com sucesso."
                );


                carregarMensagens();

                carregarConversas();

                verificarFeedback();

            }
        )

        .catch(
            function (erro) {

                console.error(
                    "Erro ao cancelar aula:",
                    erro
                );


                alert(
                    erro.message
                );

            }
        );

}


/* =========================================
   PRECISO DE AJUDA
========================================= */

async function pedirAjuda() {

    if (!crefSelecionado) {

        alert(
            "Selecione uma conversa primeiro."
        );

        return;

    }


    try {

        const dados =
            new FormData();


        dados.append(
            "acao",
            "telefone"
        );


        dados.append(
            "id_cref",
            crefSelecionado
        );


        const resposta =
            await fetch(
                URL_PHP,
                {
                    method: "POST",
                    body: dados
                }
            );


        const resultado =
            await resposta.json();


        if (resultado.erro) {

            alert(
                resultado.erro
            );

            return;

        }


        if (!resultado.telefone) {

            alert(
                "Este Personal não possui telefone cadastrado."
            );

            return;

        }


        /*
         * Remove espaços, parênteses,
         * hífens e outros caracteres.
         */
        let telefone =
            String(
                resultado.telefone
            ).replace(
                /\D/g,
                ""
            );


        /*
         * Adiciona código do Brasil
         * caso não esteja cadastrado.
         */
        if (
            !telefone.startsWith("55")
        ) {

            telefone =
                "55" + telefone;

        }


        const mensagem =
            encodeURIComponent(
                `Olá, ${resultado.nome}! Sou aluno da FitLink e preciso de ajuda com meu agendamento.`
            );


        const whatsapp =
            `https://wa.me/${telefone}?text=${mensagem}`;


        window.open(
            whatsapp,
            "_blank"
        );


    } catch (erro) {

        console.error(
            "Erro ao abrir WhatsApp:",
            erro
        );


        alert(
            "Não foi possível abrir o WhatsApp do Personal."
        );

    }

}


/* =========================================
   ENVIAR PEDIDO DE REMARCAÇÃO
========================================= */

function solicitarRemarcacao() {

    abrirRemarcacao();

}


/* =========================================
   ENVIAR PEDIDO DE CANCELAMENTO
========================================= */

function solicitarCancelamento() {

    abrirCancelamento();

}


/* =========================================
   BOTÕES DE MENSAGENS RÁPIDAS
========================================= */

function mensagemRapida(
    texto
) {

    if (!texto) {

        return;

    }


    enviarMensagem(
        texto
    );

}


/* =========================================
   BLOQUEAR BOTÕES
========================================= */

function bloquearBotoes(
    bloquear
) {

    const botoes =
        document.querySelectorAll(
            ".acoes-chat button"
        );


    botoes.forEach(
        function (botao) {

            /*
             * Não interfere no botão
             * de feedback.
             */

            if (
                botao.id ===
                "btnAvaliarPersonal"
            ) {

                return;

            }


            botao.disabled =
                bloquear;

        }
    );

}


/* =========================================
   FORMATAR HORÁRIO
========================================= */

function formatarHorario(
    horario
) {

    if (!horario) {

        return "--:--";

    }


    const texto =
        String(
            horario
        );


    /*
     * 18:00:00 -> 18:00
     */

    if (
        /^\d{2}:\d{2}/.test(
            texto
        )
    ) {

        return texto.substring(
            0,
            5
        );

    }


    return texto;

}


/* =========================================
   FORMATAR DATA/HORA
========================================= */

function dataHora(
    valor
) {

    if (!valor) {

        return "";

    }


    /*
     * MariaDB normalmente retorna:
     * 2026-09-29 10:30:00
     *
     * Trocamos espaço por T para facilitar
     * interpretação pelo navegador.
     */

    const normalizado =
        String(valor)
            .replace(
                " ",
                "T"
            );


    const data =
        new Date(
            normalizado
        );


    if (
        Number.isNaN(
            data.getTime()
        )
    ) {

        return String(
            valor
        );

    }


    const agora =
        new Date();


    const mesmoDia =
        data.getDate() ===
            agora.getDate()

        &&

        data.getMonth() ===
            agora.getMonth()

        &&

        data.getFullYear() ===
            agora.getFullYear();


    if (mesmoDia) {

        return data.toLocaleTimeString(
            "pt-BR",
            {
                hour: "2-digit",
                minute: "2-digit"
            }
        );

    }


    return data.toLocaleDateString(
        "pt-BR",
        {
            day: "2-digit",
            month: "2-digit"
        }
    );

}


/* =========================================
   ESCAPAR HTML
========================================= */

function esc(
    valor
) {

    const elemento =
        document.createElement(
            "div"
        );


    elemento.textContent =
        valor ?? "";


    return elemento.innerHTML;

}


/* =========================================
   SAIR
========================================= */

function sair() {

    fetch(
        "../../php/logout.php",
        {
            cache: "no-store"
        }
    )

        .finally(
            function () {

                window.location.href =
                    "../login.html";

            }
        );

}

/* =========================================================
   FEEDBACK DO PERSONAL
========================================================= */

let notaFeedback = 0;


/* =========================================================
   VERIFICAR SE O ALUNO PODE AVALIAR
========================================================= */

async function verificarFeedback() {

    const botao =
        document.getElementById(
            "btnAvaliarPersonal"
        );


    /*
     * Se o botão não existir no HTML,
     * não executa o restante.
     */
    if (!botao) {

        console.warn(
            "Botão btnAvaliarPersonal não encontrado."
        );

        return;
    }


    /*
     * Sempre esconde antes de verificar.
     * O botão só será mostrado caso
     * feedback.php autorize a avaliação.
     */
    botao.style.display = "none";


    if (!crefSelecionado) {

        return;

    }


    try {

        const url =
            "../../php/feedback.php" +
            "?acao=situacao" +
            "&id_cref=" +
            encodeURIComponent(
                crefSelecionado
            );


        const resposta =
            await fetch(
                url,
                {
                    method: "GET",
                    cache: "no-store"
                }
            );


        /*
         * Primeiro usamos .text()
         * para conseguir enxergar erros PHP
         * caso o servidor não devolva JSON.
         */
        const texto =
            await resposta.text();


        let dados;


        try {

            dados =
                JSON.parse(
                    texto
                );

        } catch (erro) {

            console.error(
                "feedback.php não retornou JSON válido."
            );


            console.error(
                "Resposta recebida:",
                texto
            );


            return;

        }


        console.log(
            "Situação do feedback:",
            dados
        );


        if (dados.erro) {

            console.error(
                "Erro retornado pelo feedback.php:",
                dados.erro
            );

            return;

        }


        /* =================================================
           ALUNO ESTÁ LIBERADO PARA AVALIAR
        ================================================= */

        if (
            dados.pode_avaliar === true
            ||
            dados.pode_avaliar === 1
            ||
            dados.pode_avaliar === "1"
        ) {

            /*
             * Mostra o botão.
             */
            botao.style.display =
                "";


            /* =============================================
               JÁ EXISTE FEEDBACK
            ============================================= */

            if (dados.feedback) {

                botao.textContent =
                    "⭐ Editar avaliação";


                /*
                 * Guardamos os dados da avaliação
                 * dentro do próprio botão.
                 *
                 * Quando o modal abrir, esses valores
                 * serão carregados automaticamente.
                 */
                botao.dataset.avaliacao =
                    dados.feedback.avaliacao
                    ?? "";


                botao.dataset.relato =
                    dados.feedback.relato
                    ?? "";

            }


            /* =============================================
               AINDA NÃO EXISTE FEEDBACK
            ============================================= */

            else {

                botao.textContent =
                    "⭐ Avaliar Personal";


                botao.dataset.avaliacao =
                    "";


                botao.dataset.relato =
                    "";

            }

        }


        /* =================================================
           AINDA NÃO PODE AVALIAR
        ================================================= */

        else {

            botao.style.display =
                "none";


            botao.dataset.avaliacao =
                "";


            botao.dataset.relato =
                "";

        }


    } catch (erro) {

        console.error(
            "Erro ao verificar feedback:",
            erro
        );

    }

}



/* =========================================================
   ABRIR MODAL DE FEEDBACK
========================================================= */

function abrirFeedback() {

    const modal =
        document.getElementById(
            "modalFeedback"
        );


    const botao =
        document.getElementById(
            "btnAvaliarPersonal"
        );


    const campoRelato =
        document.getElementById(
            "feedbackRelato"
        );


    const aviso =
        document.getElementById(
            "feedbackAviso"
        );


    /*
     * Segurança caso o modal ainda não
     * tenha sido colocado no HTML.
     */
    if (!modal) {

        console.error(
            "O elemento #modalFeedback não existe no mensagens.html."
        );


        alert(
            "O formulário de avaliação não foi encontrado."
        );


        return;

    }


    /*
     * Se já existe avaliação,
     * recuperamos a nota.
     *
     * Caso contrário começa em zero.
     */
    notaFeedback =
        Number(
            botao?.dataset.avaliacao
            || 0
        );


    /*
     * Recupera o comentário anterior,
     * caso o aluno esteja editando.
     */
    if (campoRelato) {

        campoRelato.value =
            botao?.dataset.relato
            || "";

    }


    /*
     * Limpa mensagens de erro anteriores.
     */
    if (aviso) {

        aviso.textContent =
            "";

    }


    atualizarEstrelasFeedback();


    /*
     * Abre o modal.
     */
    modal.classList.add(
        "ativo"
    );

}



/* =========================================================
   FECHAR MODAL DE FEEDBACK
========================================================= */

function fecharFeedback() {

    const modal =
        document.getElementById(
            "modalFeedback"
        );


    if (!modal) {

        return;

    }


    modal.classList.remove(
        "ativo"
    );

}



/* =========================================================
   ATUALIZAR VISUAL DAS ESTRELAS
========================================================= */

function atualizarEstrelasFeedback() {

    const estrelas =
        document.querySelectorAll(
            "#feedbackEstrelas button"
        );


    estrelas.forEach(
        function (estrela) {

            const nota =
                Number(
                    estrela.dataset.nota
                );


            /*
             * Exemplo:
             *
             * notaFeedback = 4
             *
             * ★ ★ ★ ★ ☆
             */

            if (
                nota <=
                notaFeedback
            ) {

                estrela.classList.add(
                    "selecionada"
                );

            } else {

                estrela.classList.remove(
                    "selecionada"
                );

            }

        }
    );

}



/* =========================================================
   CLIQUE EM UMA ESTRELA
========================================================= */

document.addEventListener(
    "click",
    function (evento) {

        const estrela =
            evento.target.closest(
                "#feedbackEstrelas button"
            );


        /*
         * O clique não aconteceu
         * em uma estrela.
         */
        if (!estrela) {

            return;

        }


        notaFeedback =
            Number(
                estrela.dataset.nota
            );


        console.log(
            "Nota selecionada:",
            notaFeedback
        );


        atualizarEstrelasFeedback();

    }
);



/* =========================================================
   EFEITO VISUAL AO PASSAR O MOUSE
========================================================= */

document.addEventListener(
    "mouseover",
    function (evento) {

        const estrela =
            evento.target.closest(
                "#feedbackEstrelas button"
            );


        if (!estrela) {

            return;

        }


        const notaHover =
            Number(
                estrela.dataset.nota
            );


        const estrelas =
            document.querySelectorAll(
                "#feedbackEstrelas button"
            );


        estrelas.forEach(
            function (item) {

                const notaItem =
                    Number(
                        item.dataset.nota
                    );


                if (
                    notaItem <=
                    notaHover
                ) {

                    item.classList.add(
                        "hover"
                    );

                } else {

                    item.classList.remove(
                        "hover"
                    );

                }

            }
        );

    }
);



/* =========================================================
   RETIRAR EFEITO HOVER
========================================================= */

document.addEventListener(
    "mouseout",
    function (evento) {

        const areaEstrelas =
            evento.target.closest(
                "#feedbackEstrelas"
            );


        if (!areaEstrelas) {

            return;

        }


        /*
         * Verifica se o mouse apenas mudou
         * de uma estrela para outra.
         */
        const destino =
            evento.relatedTarget;


        if (
            destino &&
            areaEstrelas.contains(
                destino
            )
        ) {

            return;

        }


        document
            .querySelectorAll(
                "#feedbackEstrelas button"
            )
            .forEach(
                function (estrela) {

                    estrela.classList.remove(
                        "hover"
                    );

                }
            );

    }
);



/* =========================================================
   SALVAR FEEDBACK
========================================================= */

async function salvarFeedback() {

    const campoRelato =
        document.getElementById(
            "feedbackRelato"
        );


    const aviso =
        document.getElementById(
            "feedbackAviso"
        );


    const botaoEnviar =
        document.querySelector(
            "#modalFeedback .btn-confirmar"
        );


    /*
     * Limpa erro anterior.
     */
    if (aviso) {

        aviso.textContent =
            "";

    }


    /* =====================================================
       VERIFICAR PERSONAL
    ===================================================== */

    if (!crefSelecionado) {

        if (aviso) {

            aviso.textContent =
                "Nenhum Personal foi selecionado.";

        }


        return;

    }


    /* =====================================================
       VERIFICAR CAMPO DE COMENTÁRIO
    ===================================================== */

    if (!campoRelato) {

        console.error(
            "#feedbackRelato não foi encontrado."
        );


        if (aviso) {

            aviso.textContent =
                "Não foi possível localizar o campo de comentário.";

        }


        return;

    }


    const relato =
        campoRelato.value.trim();


    /* =====================================================
       VALIDAR NOTA
    ===================================================== */

    if (
        !notaFeedback ||
        notaFeedback < 1 ||
        notaFeedback > 5
    ) {

        if (aviso) {

            aviso.textContent =
                "Escolha uma nota de 1 a 5 estrelas.";

        }


        return;

    }


    /* =====================================================
       VALIDAR COMENTÁRIO
    ===================================================== */

    if (
        relato.length < 3
    ) {

        if (aviso) {

            aviso.textContent =
                "Escreva um comentário sobre sua experiência.";

        }


        return;

    }


    if (
        relato.length > 1000
    ) {

        if (aviso) {

            aviso.textContent =
                "O comentário pode ter no máximo 1000 caracteres.";

        }


        return;

    }


    /* =====================================================
       PREPARAR ENVIO
    ===================================================== */

    const formData =
        new FormData();


    formData.append(
        "acao",
        "salvar"
    );


    formData.append(
        "id_cref",
        crefSelecionado
    );


    formData.append(
        "avaliacao",
        notaFeedback
    );


    formData.append(
        "relato",
        relato
    );


    /* =====================================================
       DESABILITAR BOTÃO
    ===================================================== */

    let textoBotao =
        "Enviar avaliação";


    if (botaoEnviar) {

        textoBotao =
            botaoEnviar.textContent;


        botaoEnviar.disabled =
            true;


        botaoEnviar.textContent =
            "Enviando...";

    }


    try {

        /* =================================================
           ENVIAR PARA PHP
        ================================================= */

        const resposta =
            await fetch(
                "../../php/feedback.php",
                {
                    method: "POST",
                    body: formData
                }
            );


        /*
         * Novamente usamos text primeiro
         * para facilitar diagnóstico de
         * Warning/Fatal Error do PHP.
         */
        const texto =
            await resposta.text();


        let resultado;


        try {

            resultado =
                JSON.parse(
                    texto
                );

        } catch (erro) {

            console.error(
                "feedback.php retornou algo que não é JSON:"
            );


            console.error(
                texto
            );


            if (aviso) {

                aviso.textContent =
                    "Erro no servidor. Abra o Console para ver os detalhes.";

            }


            return;

        }


        console.log(
            "Resultado do feedback:",
            resultado
        );


        /* =================================================
           PHP RETORNOU ERRO
        ================================================= */

        if (resultado.erro) {

            if (aviso) {

                aviso.textContent =
                    resultado.erro;

            }


            return;

        }


        /* =================================================
           FEEDBACK SALVO
        ================================================= */

        if (
            resultado.sucesso === true
            ||
            resultado.sucesso === 1
            ||
            resultado.sucesso === "1"
        ) {

            /*
             * Fecha o modal.
             */
            fecharFeedback();


            /*
             * Consulta novamente o PHP.
             *
             * Assim o botão muda de:
             *
             * Avaliar Personal
             *
             * para:
             *
             * Editar avaliação
             */
            await verificarFeedback();


            alert(
                resultado.mensagem ||
                "Feedback salvo com sucesso!"
            );


            return;

        }


        /*
         * Caso o PHP retorne JSON,
         * mas sem sucesso e sem erro.
         */
        if (aviso) {

            aviso.textContent =
                "Não foi possível confirmar o envio da avaliação.";

        }


    } catch (erro) {

        console.error(
            "Erro ao enviar feedback:",
            erro
        );


        if (aviso) {

            aviso.textContent =
                "Não foi possível enviar o feedback.";

        }


    } finally {

        /* =================================================
           REATIVAR BOTÃO
        ================================================= */

        if (botaoEnviar) {

            botaoEnviar.disabled =
                false;


            botaoEnviar.textContent =
                textoBotao;

        }

    }

}



/* =========================================================
   FECHAR FEEDBACK CLICANDO FORA DO MODAL
========================================================= */

document.addEventListener(
    "click",
    function (evento) {

        const modal =
            document.getElementById(
                "modalFeedback"
            );


        if (!modal) {

            return;

        }


        if (
            evento.target === modal
        ) {

            fecharFeedback();

        }

    }
);



/* =========================================================
   FECHAR FEEDBACK COM ESC
========================================================= */

document.addEventListener(
    "keydown",
    function (evento) {

        if (
            evento.key !== "Escape"
        ) {

            return;

        }


        const modal =
            document.getElementById(
                "modalFeedback"
            );


        if (
            modal &&
            modal.classList.contains(
                "ativo"
            )
        ) {

            fecharFeedback();

        }

    }
);

/* =========================================================
   EVENTOS E COMPATIBILIDADE DO CHAT
========================================================= */


/* =========================================================
   FECHAR MODAIS CLICANDO FORA
========================================================= */

document.addEventListener(
    "click",
    function (evento) {

        const modalRemarcacao =
            document.getElementById(
                "modalRemarcacao"
            );


        const modalCancelamento =
            document.getElementById(
                "modalCancelamento"
            );


        /*
         * REMARCAÇÃO
         */

        if (
            modalRemarcacao &&
            evento.target === modalRemarcacao
        ) {

            fecharRemarcacao();

        }


        /*
         * CANCELAMENTO
         */

        if (
            modalCancelamento &&
            evento.target === modalCancelamento
        ) {

            fecharCancelamento();

        }

    }
);



/* =========================================================
   ESC FECHA OS MODAIS
========================================================= */

document.addEventListener(
    "keydown",
    function (evento) {

        if (
            evento.key !== "Escape"
        ) {

            return;

        }


        /*
         * Modal de remarcação
         */

        const modalRemarcacao =
            document.getElementById(
                "modalRemarcacao"
            );


        if (
            modalRemarcacao &&
            modalRemarcacao.classList.contains(
                "ativo"
            )
        ) {

            fecharRemarcacao();

        }


        /*
         * Modal de cancelamento
         */

        const modalCancelamento =
            document.getElementById(
                "modalCancelamento"
            );


        if (
            modalCancelamento &&
            modalCancelamento.classList.contains(
                "ativo"
            )
        ) {

            fecharCancelamento();

        }

    }
);



/* =========================================================
   ATUALIZAR CONVERSA PERIODICAMENTE
========================================================= */

/*
 * Atualiza somente as mensagens da conversa
 * que estiver aberta.
 *
 * Isso permite que mensagens automáticas
 * apareçam sem precisar atualizar a página.
 */

setInterval(
    function () {

        if (
            crefSelecionado &&
            !document.hidden
        ) {

            atualizarMensagensSilenciosamente();

        }

    },
    3000
);



/* =========================================================
   ATUALIZAR MENSAGENS SEM MOSTRAR "CARREGANDO"
========================================================= */

async function atualizarMensagensSilenciosamente() {

    if (!crefSelecionado) {

        return;

    }


    const lista =
        document.getElementById(
            "listaMensagens"
        );


    if (!lista) {

        return;

    }


    try {

        const resposta =
            await fetch(

                URL_PHP +
                "?acao=listar_mensagens&id_cref=" +
                encodeURIComponent(
                    crefSelecionado
                ),

                {
                    cache: "no-store"
                }

            );


        const dados =
            await resposta.json();


        if (
            dados.erro ||
            !Array.isArray(dados)
        ) {

            return;

        }


        /*
         * Guarda se o usuário já estava
         * próximo do final da conversa.
         */

        const distanciaFinal =
            lista.scrollHeight -
            lista.scrollTop -
            lista.clientHeight;


        const estavaNoFinal =
            distanciaFinal < 100;


        lista.innerHTML =
            "";


        if (
            dados.length === 0
        ) {

            lista.innerHTML =
                `
                <div class="sem-mensagens">
                    Nenhuma mensagem nesta conversa.
                </div>
                `;


            return;

        }


        dados.forEach(
            function (mensagem) {

                const elemento =
                    document.createElement(
                        "div"
                    );


                elemento.className =
                    "mensagem " +
                    mensagem.remetente;


                elemento.innerHTML =
                    `
                    ${esc(
                        mensagem.mensagem
                    )}

                    <span class="mensagem-hora">

                        ${dataHora(
                            mensagem.data_envio
                        )}

                    </span>
                    `;


                lista.appendChild(
                    elemento
                );

            }
        );


        /*
         * Só força o scroll para baixo
         * caso o aluno já estivesse
         * acompanhando o final da conversa.
         */

        if (estavaNoFinal) {

            lista.scrollTop =
                lista.scrollHeight;

        }


    } catch (erro) {

        /*
         * Não mostramos alert porque essa
         * atualização acontece automaticamente.
         */

        console.error(
            "Erro na atualização automática:",
            erro
        );

    }

}



/* =========================================================
   ATUALIZAR CONVERSAS PERIODICAMENTE
========================================================= */

setInterval(
    function () {

        if (!document.hidden) {

            atualizarListaConversasSilenciosamente();

        }

    },
    20000
);



/* =========================================================
   ATUALIZAR LISTA DE CONVERSAS
========================================================= */

async function atualizarListaConversasSilenciosamente() {

    try {

        const resposta = await fetch(
            URL_PHP + "?acao=listar_conversas",
            {
                cache: "no-store"
            }
        );


        const dados = await resposta.json();


        if (
            dados.erro ||
            !Array.isArray(dados)
        ) {

            return;

        }


        const conversas =
            document.querySelectorAll(
                ".conversa"
            );


        /*
         * Se surgiu ou desapareceu alguma conversa,
         * recria a lista.
         */
        if (
            conversas.length !==
            dados.length
        ) {

            carregarConversas();

        }


        /*
         * Se existe uma conversa aberta,
         * verifica se chegou alguma atualização.
         */
        if (crefSelecionado) {

            const conversaAtual =
                dados.find(
                    function (conversa) {

                        return Number(
                            conversa.id_cref
                        ) === Number(
                            crefSelecionado
                        );

                    }
                );


            if (conversaAtual) {

                /*
                 * Atualiza imediatamente as mensagens
                 * da conversa que o aluno está vendo.
                 *
                 * Isso faz mensagens de:
                 *
                 * - confirmação
                 * - cancelamento
                 * - remarcação
                 *
                 * aparecerem sem precisar clicar
                 * novamente na conversa.
                 */

                await atualizarMensagensSilenciosamente();

            }

        }


    } catch (erro) {

        console.error(
            "Erro ao atualizar conversas:",
            erro
        );

    }

}



/* =========================================================
   QUANDO A ABA VOLTAR A FICAR VISÍVEL
========================================================= */

document.addEventListener(
    "visibilitychange",
    function () {

        if (
            document.hidden
        ) {

            return;

        }


        if (
            crefSelecionado
        ) {

            atualizarMensagensSilenciosamente();

            verificarFeedback();

        }

    }
);



/* =========================================================
   PREVENIR DATA DE REMARCAÇÃO NO PASSADO
========================================================= */

document.addEventListener(
    "change",
    function (evento) {

        if (
            evento.target.id !==
            "remarcacaoData"
        ) {

            return;

        }


        const campo =
            evento.target;


        if (!campo.value) {

            return;

        }


        const hoje =
            new Date();


        hoje.setHours(
            0,
            0,
            0,
            0
        );


        /*
         * T12:00 evita alguns problemas
         * de interpretação de timezone
         * somente para a comparação da data.
         */

        const escolhida =
            new Date(
                campo.value +
                "T12:00:00"
            );


        escolhida.setHours(
            0,
            0,
            0,
            0
        );


        if (
            escolhida < hoje
        ) {

            alert(
                "Não é possível selecionar uma data que já passou."
            );


            definirDataMinima(
                campo
            );


            carregarHorariosRemarcacao();

        }

    }
);



/* =========================================================
   EVITAR DUPLO ENVIO DE FEEDBACK
========================================================= */

let enviandoFeedback =
    false;


/*
 * Esta função serve como camada adicional
 * caso futuramente o botão seja acionado
 * rapidamente mais de uma vez.
 */

async function enviarFeedbackSeguro() {

    if (
        enviandoFeedback
    ) {

        return;

    }


    enviandoFeedback =
        true;


    try {

        await salvarFeedback();

    } finally {

        enviandoFeedback =
            false;

    }

}



/* =========================================================
   CONTADOR DO COMENTÁRIO
========================================================= */

document.addEventListener(
    "input",
    function (evento) {

        if (
            evento.target.id !==
            "feedbackRelato"
        ) {

            return;

        }


        const campo =
            evento.target;


        const contador =
            document.getElementById(
                "feedbackContador"
            );


        if (!contador) {

            return;

        }


        contador.textContent =
            campo.value.length +
            "/1000";

    }
);



/* =========================================================
   GARANTIR LIMITE DE 1000 CARACTERES
========================================================= */

document.addEventListener(
    "input",
    function (evento) {

        if (
            evento.target.id !==
            "feedbackRelato"
        ) {

            return;

        }


        if (
            evento.target.value.length >
            1000
        ) {

            evento.target.value =
                evento.target.value.substring(
                    0,
                    1000
                );

        }

    }
);



/* =========================================================
   LIMPAR FEEDBACK AO TROCAR DE PERSONAL
========================================================= */

function limparEstadoFeedback() {

    notaFeedback =
        0;


    const botao =
        document.getElementById(
            "btnAvaliarPersonal"
        );


    if (botao) {

        botao.style.display =
            "none";


        botao.dataset.avaliacao =
            "";


        botao.dataset.relato =
            "";


        botao.textContent =
            "⭐ Avaliar Personal";

    }


    const campo =
        document.getElementById(
            "feedbackRelato"
        );


    if (campo) {

        campo.value =
            "";

    }


    const aviso =
        document.getElementById(
            "feedbackAviso"
        );


    if (aviso) {

        aviso.textContent =
            "";

    }


    atualizarEstrelasFeedback();

}



/* =========================================================
   FUNÇÃO PARA FORMATAR DATA COMPLETA
========================================================= */

function formatarDataCompleta(
    data
) {

    if (!data) {

        return "";

    }


    const partes =
        String(data)
            .split("-");


    if (
        partes.length !== 3
    ) {

        return data;

    }


    return (
        partes[2] +
        "/" +
        partes[1] +
        "/" +
        partes[0]
    );

}



/* =========================================================
   FUNÇÃO PARA FORMATAR TELEFONE
========================================================= */

function formatarTelefone(
    telefone
) {

    if (!telefone) {

        return "";

    }


    const numeros =
        String(telefone)
            .replace(
                /\D/g,
                ""
            );


    /*
     * Celular:
     * 11999999999
     */

    if (
        numeros.length === 11
    ) {

        return (
            "(" +
            numeros.substring(
                0,
                2
            ) +
            ") " +
            numeros.substring(
                2,
                7
            ) +
            "-" +
            numeros.substring(
                7
            )
        );

    }


    /*
     * Telefone fixo:
     * 1133334444
     */

    if (
        numeros.length === 10
    ) {

        return (
            "(" +
            numeros.substring(
                0,
                2
            ) +
            ") " +
            numeros.substring(
                2,
                6
            ) +
            "-" +
            numeros.substring(
                6
            )
        );

    }


    return telefone;

}



/* =========================================================
   TRATAR ERRO GLOBAL DE PROMISE
========================================================= */

window.addEventListener(
    "unhandledrejection",
    function (evento) {

        console.error(
            "Promise rejeitada:",
            evento.reason
        );

    }
);



/* =========================================================
   LOG DE INICIALIZAÇÃO
========================================================= */

console.log(
    "FitLink - mensagens.js carregado."
);


console.log(
    "Sistema de feedback carregado."
);


/* =========================================================
   FIM DO ARQUIVO
========================================================= */
