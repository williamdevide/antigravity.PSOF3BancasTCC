// ==========================================
// CARREGAR PERFIL
// ==========================================

function carregarPerfil() {

    fetch("../../php/perfil.php?acao=perfil")

        .then(response => response.json())

        .then(dados => {

            if (dados.erro) {

                alert(dados.erro);
                return;

            }

            // ==============================
            // DADOS PESSOAIS
            // ==============================

            document.getElementById("nome").value =
                dados.nome || "";

            document.getElementById("email").value =
                dados.email || "";

            document.getElementById("telefone").value =
                dados.telefone || "";

            document.getElementById("data_nascimento").value =
                dados.data_nascimento || "";

            document.getElementById("genero").value =
                dados.genero || "";

            document.getElementById("cref").value =
                dados.id_cref || "";


            // ==============================
            // FOTO DE PERFIL
            // ==============================

            carregarFotoPerfil(dados);

        })

        .catch(error => {

            console.error(error);

            alert(
                "Erro ao carregar o perfil."
            );

        });

}


// ==========================================
// CARREGAR FOTO DE PERFIL
// ==========================================

function carregarFotoPerfil(dados) {

    const foto =
        document.getElementById("fotoPerfil");

    const iniciais =
        document.getElementById("iniciaisPerfil");

    const nomeFoto =
        document.getElementById("nomeFoto");


    if (!foto || !iniciais) {

        return;

    }


    const nome =
        dados.nome || "Personal";


    // ==============================
    // NOME
    // ==============================

    if (nomeFoto) {

        nomeFoto.textContent =
            nome;

    }


    // ==============================
    // GERAR INICIAIS
    // ==============================

    const partes =
        nome.trim().split(/\s+/);

    let letras = "";


    if (partes.length >= 2) {

        letras =
            partes[0].charAt(0) +
            partes[partes.length - 1].charAt(0);

    }

    else {

        letras =
            partes[0].substring(0, 2);

    }


    iniciais.textContent =
        letras.toUpperCase();


    // ==============================
    // SEM FOTO
    // ==============================

    if (!dados.foto) {

        foto.style.display = "none";
        iniciais.style.display = "flex";

        return;

    }


    // ==============================
    // COM FOTO
    // ==============================

    foto.src =
        "../../" + dados.foto;


    foto.style.display =
        "block";

    iniciais.style.display =
        "none";


    // ==============================
    // CASO A FOTO NÃO CARREGUE
    // ==============================

    foto.onerror = function() {

        foto.style.display =
            "none";

        iniciais.style.display =
            "flex";

    };

}


// ==========================================
// ENVIAR FOTO DE PERFIL
// ==========================================

const inputFoto =
    document.getElementById("inputFoto");


if (inputFoto) {

    inputFoto.addEventListener(
        "change",
        function() {

            if (
                !this.files ||
                this.files.length === 0
            ) {

                return;

            }


            const arquivo =
                this.files[0];


            // ==============================
            // LIMITE DE 5 MB
            // ==============================

            if (
                arquivo.size >
                5 * 1024 * 1024
            ) {

                alert(
                    "A foto deve ter no máximo 5 MB."
                );

                this.value = "";

                return;

            }


            // ==============================
            // TIPOS PERMITIDOS
            // ==============================

            const tiposPermitidos = [

                "image/jpeg",
                "image/png",
                "image/webp"

            ];


            if (
                !tiposPermitidos.includes(
                    arquivo.type
                )
            ) {

                alert(
                    "Formato inválido. Escolha uma imagem JPG, PNG ou WEBP."
                );

                this.value = "";

                return;

            }


            // ==============================
            // FORM DATA
            // ==============================

            const dados =
                new FormData();


            dados.append(
                "acao",
                "upload_foto"
            );


            dados.append(
                "foto",
                arquivo
            );


            // ==============================
            // DESABILITAR INPUT
            // ==============================

            this.disabled =
                true;


            fetch(
                "../../php/perfil.php",
                {
                    method: "POST",
                    body: dados
                }
            )

            .then(response =>
                response.json()
            )

            .then(resultado => {

                if (resultado.erro) {

                    alert(
                        resultado.erro
                    );

                    return;

                }


                // ==============================
                // ATUALIZAR FOTO NA HORA
                // ==============================

                const foto =
                    document.getElementById(
                        "fotoPerfil"
                    );

                const iniciais =
                    document.getElementById(
                        "iniciaisPerfil"
                    );


                if (foto && resultado.foto) {

                    foto.src =
                        "../../" +
                        resultado.foto +
                        "?t=" +
                        new Date().getTime();

                    foto.style.display =
                        "block";

                }


                if (iniciais) {

                    iniciais.style.display =
                        "none";

                }


                alert(
                    "Foto de perfil atualizada com sucesso!"
                );


                // Limpa o input
                inputFoto.value = "";

            })

            .catch(error => {

                console.error(error);

                alert(
                    "Erro ao enviar a foto."
                );

            })

            .finally(() => {

                inputFoto.disabled =
                    false;

            });

        }
    );

}


// ==========================================
// SALVAR PERFIL
// ==========================================

document
    .getElementById("perfilForm")
    .addEventListener(
        "submit",
        function(e) {

            e.preventDefault();


            const dados =
                new FormData();


            dados.append(
                "acao",
                "editar"
            );


            dados.append(
                "nome",
                document.getElementById("nome").value
            );


            dados.append(
                "email",
                document.getElementById("email").value
            );


            dados.append(
                "telefone",
                document.getElementById("telefone").value
            );


            dados.append(
                "data_nascimento",
                document.getElementById(
                    "data_nascimento"
                ).value
            );


            dados.append(
                "genero",
                document.getElementById("genero").value
            );


            fetch(
                "../../php/perfil.php",
                {
                    method: "POST",
                    body: dados
                }
            )

            .then(response =>
                response.text()
            )

            .then(resultado => {

                alert(resultado);

                carregarPerfil();

            })

            .catch(error => {

                console.error(error);

                alert(
                    "Erro ao salvar alterações."
                );

            });

        }
    );


// ==========================================
// BUSCAR ACADEMIAS
// ==========================================

function buscarAcademias() {

    const botao =
        document.getElementById(
            "btnLocalizacao"
        );


    const status =
        document.getElementById(
            "statusLocalizacao"
        );


    const lista =
        document.getElementById(
            "listaAcademias"
        );


    botao.disabled =
        true;


    status.textContent =
        "Procurando academias em Ourinhos...";


    lista.innerHTML =
        "";


    // ==========================================
    // LOCALIZAÇÃO FIXA - OURINHOS/SP
    // ==========================================

    const latitude =
        -22.979;

    const longitude =
        -49.871;


    status.textContent =
        "Localização definida como Ourinhos. Procurando academias próximas...";


    // ==========================================
    // ENVIAR LOCALIZAÇÃO PARA O PHP
    // ==========================================

    const dados =
        new FormData();


    dados.append(
        "acao",
        "buscar_academias"
    );


    dados.append(
        "latitude",
        latitude
    );


    dados.append(
        "longitude",
        longitude
    );


    fetch(
        "../../php/perfil.php",
        {
            method: "POST",
            body: dados
        }
    )

    .then(response =>
        response.json()
    )

    .then(resultado => {

        botao.disabled =
            false;


        if (resultado.erro) {

            status.textContent =
                resultado.erro;

            return;

        }


        status.textContent =
            resultado.academias.length +
            " academias encontradas em um raio de 50 km de Ourinhos.";


        mostrarAcademias(
            resultado.academias
        );

    })

    .catch(error => {

        console.error(error);

        botao.disabled =
            false;

        status.textContent =
            "Erro ao buscar academias.";

    });

}


// ==========================================
// MOSTRAR ACADEMIAS
// ==========================================

function mostrarAcademias(academias) {

    const lista =
        document.getElementById(
            "listaAcademias"
        );


    const botaoSalvar =
        document.getElementById(
            "btnSalvarAcademias"
        );


    lista.innerHTML =
        "";


    if (
        !academias ||
        academias.length === 0
    ) {

        lista.innerHTML = `

            <div class="mensagem">

                <span>
                    🏋️
                </span>

                <p>
                    Nenhuma academia encontrada
                    nessa região.
                </p>

            </div>

        `;


        botaoSalvar.style.display =
            "none";


        return;

    }


    academias.forEach(
        function(academia) {

            const item =
                document.createElement(
                    "label"
                );


            item.className =
                "academia-item";


            item.innerHTML = `

                <div class="academia-topo">

                    <input
                        type="checkbox"
                        class="academia-checkbox"
                        value="${escaparHTML(
                            academia.osm_id
                        )}"
                    >

                    <div class="academia-info">

                        <span
                            class="academia-nome"
                        >

                            ${escaparHTML(
                                academia.nome
                            )}

                        </span>


                        <span
                            class="academia-endereco"
                        >

                            ${escaparHTML(
                                academia.endereco
                            )}

                        </span>


                        ${
                            academia.distancia
                            ?
                            `
                            <span
                                class="distancia"
                            >

                                ${escaparHTML(
                                    academia.distancia
                                )}

                            </span>
                            `
                            :
                            ""
                        }

                    </div>

                </div>

            `;


            const checkbox =
                item.querySelector(
                    ".academia-checkbox"
                );


            checkbox.addEventListener(
                "change",
                function() {

                    if (
                        checkbox.checked
                    ) {

                        item.classList.add(
                            "selecionada"
                        );

                    }

                    else {

                        item.classList.remove(
                            "selecionada"
                        );

                    }

                }
            );


            lista.appendChild(
                item
            );

        }
    );


    botaoSalvar.style.display =
        "inline-block";

}


// ==========================================
// SALVAR ACADEMIAS
// ==========================================

function salvarAcademias() {

    const selecionadas =
        document.querySelectorAll(
            ".academia-checkbox:checked"
        );


    if (
        selecionadas.length === 0
    ) {

        alert(
            "Selecione pelo menos uma academia."
        );

        return;

    }


    const academias =
        [];


    selecionadas.forEach(
        function(checkbox) {

            academias.push(
                checkbox.value
            );

        }
    );


    const dados =
        new FormData();


    dados.append(
        "acao",
        "salvar_academias"
    );


    academias.forEach(
        function(osmId) {

            dados.append(
                "osm_ids[]",
                osmId
            );

        }
    );


    fetch(
        "../../php/perfil.php",
        {
            method: "POST",
            body: dados
        }
    )

    .then(response =>
        response.text()
    )

    .then(resultado => {

        alert(resultado);

    })

    .catch(error => {

        console.error(error);

        alert(
            "Erro ao salvar academias."
        );

    });

}


// ==========================================
// ESCAPAR HTML
// ==========================================

function escaparHTML(texto) {

    if (!texto) {

        return "";

    }


    return String(texto)

        .replace(
            /&/g,
            "&amp;"
        )

        .replace(
            /</g,
            "&lt;"
        )

        .replace(
            />/g,
            "&gt;"
        )

        .replace(
            /"/g,
            "&quot;"
        )

        .replace(
            /'/g,
            "&#039;"
        );

}


// ==========================================
// SAIR
// ==========================================

function sair() {

    window.location.href =
        "../login.html";

}


// ==========================================
// INICIAR
// ==========================================

carregarPerfil();