/* =========================================================
   FITLINK - FINANCEIRO
========================================================= */

const URL_FINANCEIRO =
    "../../php/financeiro.php";


let dataSelecionada =
    new Date();


/* =========================================================
   INICIAR
========================================================= */

document.addEventListener(
    "DOMContentLoaded",
    function () {

        atualizarMesTela();

        carregarFinanceiro();

    }
);


/* =========================================================
   FORMATAR DINHEIRO
========================================================= */

function dinheiro(valor) {

    const numero =
        Number(valor) || 0;


    return numero.toLocaleString(
        "pt-BR",
        {
            style: "currency",
            currency: "BRL"
        }
    );

}


/* =========================================================
   ESCAPAR HTML
========================================================= */

function escapar(texto) {

    const div =
        document.createElement("div");


    div.textContent =
        texto ?? "";


    return div.innerHTML;

}


/* =========================================================
   MÊS NA TELA
========================================================= */

function atualizarMesTela() {

    const elemento =
        document.getElementById(
            "mesSelecionado"
        );


    if (!elemento) {

        return;

    }


    let texto =
        dataSelecionada.toLocaleDateString(
            "pt-BR",
            {
                month: "long",
                year: "numeric"
            }
        );


    texto =
        texto.charAt(0).toUpperCase() +
        texto.slice(1);


    elemento.textContent =
        texto;

}


/* =========================================================
   MÊS ANTERIOR
========================================================= */

function mesAnterior() {

    dataSelecionada.setMonth(
        dataSelecionada.getMonth() - 1
    );


    atualizarMesTela();

    carregarFinanceiro();

}


/* =========================================================
   PRÓXIMO MÊS
========================================================= */

function proximoMes() {

    dataSelecionada.setMonth(
        dataSelecionada.getMonth() + 1
    );


    atualizarMesTela();

    carregarFinanceiro();

}


/* =========================================================
   CARREGAR DADOS
========================================================= */

async function carregarFinanceiro() {

    const ano =
        dataSelecionada.getFullYear();


    const mes =
        dataSelecionada.getMonth() + 1;


    const tabela =
        document.getElementById(
            "tabelaFinanceiro"
        );


    if (tabela) {

        tabela.innerHTML =
            `
            <tr>
                <td
                    colspan="6"
                    class="carregando"
                >
                    Carregando informações...
                </td>
            </tr>
            `;

    }


    try {

        const resposta =
            await fetch(
                URL_FINANCEIRO +
                "?ano=" +
                encodeURIComponent(ano) +
                "&mes=" +
                encodeURIComponent(mes),
                {
                    cache: "no-store"
                }
            );


        const texto =
            await resposta.text();


        let dados;


        try {

            dados =
                JSON.parse(texto);

        } catch (erro) {

            console.error(
                "Resposta do financeiro.php:",
                texto
            );


            throw new Error(
                "O PHP não retornou JSON válido."
            );

        }


        if (dados.erro) {

            throw new Error(
                dados.erro
            );

        }


        atualizarResumo(
            dados.resumo
        );


        montarTabela(
            dados.contratos
        );


    } catch (erro) {

        console.error(
            "Erro financeiro:",
            erro
        );


        if (tabela) {

            tabela.innerHTML =
                `
                <tr>
                    <td
                        colspan="6"
                        class="sem-registros"
                    >
                        Não foi possível carregar
                        as informações financeiras.
                    </td>
                </tr>
                `;

        }

    }

}


/* =========================================================
   RESUMO
========================================================= */

function atualizarResumo(resumo) {

    resumo =
        resumo || {};


    document.getElementById(
        "valorBruto"
    ).textContent =
        dinheiro(
            resumo.bruto
        );


    document.getElementById(
        "valorTaxa"
    ).textContent =
        dinheiro(
            resumo.taxa
        );


    document.getElementById(
        "valorLiquido"
    ).textContent =
        dinheiro(
            resumo.liquido
        );


    document.getElementById(
        "quantidadePlanos"
    ).textContent =
        Number(
            resumo.quantidade || 0
        );

}


/* =========================================================
   TABELA
========================================================= */

function montarTabela(contratos) {

    const tabela =
        document.getElementById(
            "tabelaFinanceiro"
        );


    if (!tabela) {

        return;

    }


    tabela.innerHTML =
        "";


    if (
        !Array.isArray(contratos) ||
        contratos.length === 0
    ) {

        tabela.innerHTML =
            `
            <tr>

                <td
                    colspan="6"
                    class="sem-registros"
                >
                    Nenhum plano foi fechado
                    neste mês.
                </td>

            </tr>
            `;


        return;

    }


    contratos.forEach(
        function (contrato) {

            const linha =
                document.createElement(
                    "tr"
                );


            linha.innerHTML =
                `
                <td>
                    ${escapar(
                        contrato.aluno
                    )}
                </td>

                <td>
                    ${escapar(
                        contrato.plano
                    )}
                </td>

                <td>
                    ${escapar(
                        contrato.data
                    )}
                </td>

                <td class="valor-bruto">
                    ${dinheiro(
                        contrato.valor_bruto
                    )}
                </td>

                <td class="valor-taxa">
                    ${dinheiro(
                        contrato.taxa
                    )}
                </td>

                <td class="valor-liquido">
                    ${dinheiro(
                        contrato.liquido
                    )}
                </td>
                `;


            tabela.appendChild(
                linha
            );

        }
    );

}


/* =========================================================
   SAIR
========================================================= */

function sair() {

    window.location.href =
        "../login.html";

}