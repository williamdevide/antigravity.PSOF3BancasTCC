const URL_FEEDBACK =
    "../../php/feedback.php";


document.addEventListener(
    "DOMContentLoaded",
    carregarFeedbacks
);



async function carregarFeedbacks() {

    const lista =
        document.getElementById(
            "listaFeedbacks"
        );


    try {

        const resposta =
            await fetch(
                URL_FEEDBACK + "?acao=listar",
                {
                    cache: "no-store"
                }
            );


        const dados =
            await resposta.json();


        console.log(
            "Feedbacks:",
            dados
        );


        if (dados.erro) {
            throw new Error(
                dados.erro
            );
        }


        /* Média */

        document.getElementById(
            "media"
        ).textContent =
            Number(
                dados.resumo.media
            ).toFixed(1);



        /* Total */

        document.getElementById(
            "total"
        ).textContent =
            dados.resumo.total;



        /* Estrelas da média */

        document.getElementById(
            "estrelasMedia"
        ).textContent =
            estrelas(
                Math.round(
                    dados.resumo.media
                )
            );



        /* Distribuição */

        document.getElementById(
            "distribuicao"
        ).innerHTML =
            [5, 4, 3, 2, 1]
                .map(nota => {

                    const quantidade =
                        dados.resumo.estrelas[
                            nota
                        ];


                    let porcentagem = 0;


                    if (
                        dados.resumo.total > 0
                    ) {

                        porcentagem =
                            quantidade
                            / dados.resumo.total
                            * 100;
                    }


                    return `

                        <div class="linha-dist">

                            <span>
                                ${nota} ★
                            </span>

                            <div class="barra">

                                <i
                                    style="
                                        width:
                                        ${porcentagem}%
                                    "
                                ></i>

                            </div>

                            <b>
                                ${quantidade}
                            </b>

                        </div>

                    `;

                })
                .join("");



        /* Nenhum feedback */

        if (!dados.feedbacks.length) {

            lista.innerHTML = `

                <p class="estado">
                    Você ainda não recebeu avaliações.
                </p>

            `;

            return;
        }



        /* Cards */

        lista.innerHTML =
            dados.feedbacks
                .map(feedback => {

                    return `

                        <article class="feedback">


                            <div class="avatar">

                                ${avatar(
                                    feedback.foto,
                                    feedback.nome
                                )}

                            </div>



                            <div class="feedback-corpo">


                                <div class="feedback-topo">


                                    <div>

                                        <h3>
                                            ${esc(
                                                feedback.nome
                                            )}
                                        </h3>


                                        <div class="estrelas">

                                            ${estrelas(
                                                Number(
                                                    feedback.avaliacao
                                                )
                                            )}

                                        </div>

                                    </div>


                                    <strong>

                                        ${feedback.avaliacao}/5

                                    </strong>


                                </div>



                                <p>

                                    ${esc(
                                        feedback.relato
                                    )}

                                </p>


                            </div>


                        </article>

                    `;

                })
                .join("");

    }

    catch (erro) {

        console.error(erro);


        lista.innerHTML = `

            <p class="estado erro">

                ${esc(
                    erro.message
                )}

            </p>

        `;
    }
}



function estrelas(nota) {

    return (
        "★".repeat(
            Math.max(0, nota)
        )

        +

        "☆".repeat(
            Math.max(
                0,
                5 - nota
            )
        )
    );
}



function iniciais(nome) {

    const partes =
        String(nome || "?")
            .trim()
            .split(/\s+/);


    return (

        (
            partes[0]?.[0]
            || "?"
        )

        +

        (
            partes.length > 1
                ? partes[
                    partes.length - 1
                ][0]
                : ""
        )

    ).toUpperCase();
}



function avatar(foto, nome) {

    if (foto) {

        return `

            <img
                src="../../${esc(foto)}"
                alt="Foto de ${esc(nome)}"

                onerror="
                    this.parentElement.textContent =
                    '${iniciais(nome)}'
                "
            >

        `;
    }


    return iniciais(nome);
}



function esc(valor) {

    const div =
        document.createElement(
            "div"
        );


    div.textContent =
        valor ?? "";


    return div.innerHTML;
}



function sair() {

    fetch(
        "../../php/logout.php"
    )

    .finally(() => {

        location.href =
            "../login.html";

    });
}