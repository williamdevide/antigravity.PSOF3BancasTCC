
/* ==================================================
   FITLINK - NOTIFICAÇÕES DE MENSAGENS DO ALUNO
   Exibe um ponto dourado se houver mensagens não lidas.
================================================== */

const URL_NOTIFICACOES_ALUNO = "../../php/mensagens.php";

async function verificarNotificacoesAluno() {
    const bolinha = document.getElementById("bolinhaMensagens");

    if (!bolinha) return;

    try {
        const resposta = await fetch(
            URL_NOTIFICACOES_ALUNO + "?acao=listar_conversas",
            {
                method: "GET",
                credentials: "same-origin",
                cache: "no-store"
            }
        );

        if (!resposta.ok) {
            throw new Error("Falha ao consultar as conversas.");
        }

        const conversas = await resposta.json();

        if (!Array.isArray(conversas)) {
            throw new Error(
                conversas.erro || "Resposta inválida do servidor."
            );
        }

        const total = conversas.reduce((soma, conversa) => {
            return soma + Math.max(
                0,
                Number(conversa.nao_lidas) || 0
            );
        }, 0);

        bolinha.hidden = (total === 0);

        bolinha.parentElement.title = total > 0
            ? `${total} mensagem(ns) não lida(s)`
            : "Mensagens";

    } catch (erro) {
        console.error(
            "Erro ao verificar notificações do aluno:",
            erro
        );

        bolinha.hidden = true;
    }
}

document.addEventListener("DOMContentLoaded", () => {
    verificarNotificacoesAluno();

    window.setInterval(() => {
        if (!document.hidden) {
            verificarNotificacoesAluno();
        }
    }, 10000);
});

document.addEventListener("visibilitychange", () => {
    if (!document.hidden) {
        verificarNotificacoesAluno();
    }
});

window.addEventListener(
    "pageshow",
    verificarNotificacoesAluno
);
