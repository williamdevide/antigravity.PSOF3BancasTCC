// ==================================================
// FITLINK - ÁREA DO ALUNO
// ==================================================


// ==================================================
// CONFIGURAÇÃO
// ==================================================

const URL_PHP = "../../php/aluno.php";


// ==================================================
// VARIÁVEIS
// ==================================================

let profissionais = [];


// ==================================================
// INICIAR PÁGINA
// ==================================================

document.addEventListener(
    "DOMContentLoaded",
    function () {

        const listaProfissionais =
            document.getElementById(
                "listaProfissionais"
            );


        const campoPesquisa =
            document.getElementById(
                "pesquisa"
            );


        // ------------------------------------------
        // VERIFICAR ELEMENTOS
        // ------------------------------------------

        if (!listaProfissionais) {

            console.error(
                "Elemento listaProfissionais não encontrado."
            );

            return;

        }


        if (!campoPesquisa) {

            console.error(
                "Elemento pesquisa não encontrado."
            );

            return;

        }


        // ------------------------------------------
        // CARREGAR
        // ------------------------------------------

        carregarProfissionais(
            listaProfissionais
        );


        // ------------------------------------------
        // PESQUISA
        // ------------------------------------------

        campoPesquisa.addEventListener(
            "input",
            function () {

                const termo =
                    this.value
                        .trim()
                        .toLowerCase();


                if (termo === "") {

                    mostrarProfissionais(
                        profissionais,
                        listaProfissionais
                    );

                    return;

                }


                const resultados =
                    profissionais.filter(
                        function (profissional) {


                            const nome =
                                String(
                                    profissional.nome || ""
                                ).toLowerCase();


                            const academias =
                                String(
                                    profissional.academias || ""
                                ).toLowerCase();


                            const cidades =
                                String(
                                    profissional.cidades || ""
                                ).toLowerCase();


                            return (

                                nome.includes(termo)

                                ||

                                academias.includes(termo)

                                ||

                                cidades.includes(termo)

                            );

                        }
                    );


                mostrarProfissionais(
                    resultados,
                    listaProfissionais
                );

            }
        );

    }
);


// ==================================================
// CARREGAR PROFISSIONAIS
// ==================================================

function carregarProfissionais(
    listaProfissionais
) {

    mostrarCarregando(
        listaProfissionais
    );


    fetch(
        URL_PHP +
        "?acao=listar_personais",
        {
            method: "GET",
            cache: "no-store"
        }
    )

    .then(
        function (response) {

            if (!response.ok) {

                throw new Error(
                    "Erro HTTP " +
                    response.status
                );

            }


            return response.text();

        }
    )

    .then(
        function (texto) {

            console.log(
                "Resposta recebida do PHP:",
                texto
            );


            let dados;


            try {

                dados =
                    JSON.parse(texto);

            }

            catch (erro) {

                console.error(
                    "Resposta não é JSON válido:",
                    texto
                );


                throw new Error(
                    "O PHP não retornou um JSON válido."
                );

            }


            // --------------------------------------
            // ERRO DO PHP
            // --------------------------------------

            if (
                dados &&
                dados.erro
            ) {

                throw new Error(
                    dados.erro
                );

            }


            // --------------------------------------
            // VERIFICAR ARRAY
            // --------------------------------------

            if (
                !Array.isArray(dados)
            ) {

                throw new Error(
                    "O servidor não retornou uma lista de profissionais."
                );

            }


            // --------------------------------------
            // SALVAR
            // --------------------------------------

            profissionais =
                dados;


            // --------------------------------------
            // MOSTRAR
            // --------------------------------------

            mostrarProfissionais(
                profissionais,
                listaProfissionais
            );

        }
    )

    .catch(
        function (erro) {

            console.error(
                "Erro ao carregar profissionais:",
                erro
            );


            mostrarErro(
                listaProfissionais,
                erro.message
            );

        }
    );

}


// ==================================================
// MOSTRAR PROFISSIONAIS
// ==================================================

function mostrarProfissionais(
    lista,
    elemento
) {

    elemento.innerHTML = "";


    // ------------------------------------------
    // NENHUM
    // ------------------------------------------

    if (
        lista.length === 0
    ) {

        elemento.innerHTML = `

            <div class="nenhum-resultado">

                <h3>
                    Nenhum profissional encontrado
                </h3>

                <p>
                    Tente pesquisar por outro nome,
                    cidade ou academia.
                </p>

            </div>

        `;

        return;

    }


    // ------------------------------------------
    // CARDS
    // ------------------------------------------

    lista.forEach(
        function (profissional) {

            const card =
                criarCard(
                    profissional
                );


            elemento.appendChild(
                card
            );

        }
    );

}


// ==================================================
// FOTO / INICIAIS DO PERSONAL
// ==================================================

function gerarIniciais(nome) {

    const partes =
        String(nome || "Profissional")
            .trim()
            .split(/\s+/)
            .filter(Boolean);

    if (partes.length === 0) return "P";

    if (partes.length === 1) {
        return partes[0][0].toUpperCase();
    }

    return (
        partes[0][0] +
        partes[partes.length - 1][0]
    ).toUpperCase();

}


function criarFotoPersonal(profissional) {

    const nome =
        escaparHTML(
            profissional.nome ||
            "Profissional"
        );


    const iniciais =
        escaparHTML(
            gerarIniciais(
                profissional.nome
            )
        );


    const foto =
        profissional.foto
            ? String(profissional.foto)
            : "";


    // ------------------------------------------
    // PERSONAL POSSUI FOTO
    // ------------------------------------------

    if (foto !== "") {

        return `

            <div class="foto-personal">

                <img
                    src="../../${escaparHTML(foto)}"
                    alt="Foto de ${nome}"
                    class="foto-personal-imagem"
                    onerror="this.style.display='none'; this.nextElementSibling.style.display='flex';"
                >

                <div
                    class="foto-personal-iniciais"
                    style="display:none;"
                >
                    ${iniciais}
                </div>

            </div>

        `;

    }


    // ------------------------------------------
    // SEM FOTO
    // ------------------------------------------

    return `

        <div class="foto-personal">

            <div class="foto-personal-iniciais">

                ${iniciais}

            </div>

        </div>

    `;

}


// ==================================================
// CRIAR CARD
// ==================================================

function criarCard(
    profissional
) {

    const card =
        document.createElement(
            "article"
        );


    card.className =
        "card-personal";


    // ------------------------------------------
    // NOME
    // ------------------------------------------

    const nome =
        escaparHTML(
            profissional.nome ||
            "Profissional"
        );


    // ------------------------------------------
    // CREF
    // ------------------------------------------

    const cref =
        escaparHTML(
            profissional.id_cref ||
            "Não informado"
        );


    // ------------------------------------------
    // TELEFONE
    // ------------------------------------------

    const telefone =
        escaparHTML(
            profissional.telefone ||
            "Não informado"
        );


    // ------------------------------------------
    // CIDADE
    // ------------------------------------------

    const cidade =
        escaparHTML(
            profissional.cidades ||
            "Não informado"
        );


    // ------------------------------------------
    // AVALIAÇÃO
    // ------------------------------------------

    let avaliacao =
        "Sem avaliações";


    if (
        profissional.avaliacao !== null &&
        profissional.avaliacao !== undefined &&
        profissional.avaliacao !== ""
    ) {

        avaliacao =
            Number(
                profissional.avaliacao
            ).toFixed(1);

    }


    // ------------------------------------------
    // VALOR
    // ------------------------------------------

    let valor =
        "Não informado";


    if (
        profissional.valor_minimo !== null &&
        profissional.valor_minimo !== undefined &&
        profissional.valor_minimo !== ""
    ) {

        valor =
            formatarMoeda(
                profissional.valor_minimo
            );

    }


    // ------------------------------------------
    // ID DO PERSONAL
    // ------------------------------------------

    const idCref =
        escaparHTML(
            profissional.id_cref
        );


    // ------------------------------------------
    // HTML DO CARD
    // ------------------------------------------

    card.innerHTML = `

        ${criarFotoPersonal(profissional)}

        <div class="card-cabecalho">

            <div>

                <h3 class="nome-personal">

                    ${nome}

                </h3>


                <div class="cref">

                    CREF:
                    ${cref}

                </div>

            </div>


            <div class="avaliacao">

                ⭐ ${avaliacao}

            </div>

        </div>


        <div class="informacoes">


            <div class="info">

                <span class="info-icone">
                    📍
                </span>


                <span>

                    <strong>
                        Cidade:
                    </strong>

                    ${cidade}

                </span>

            </div>


            <div class="info">

                <span class="info-icone">
                    📞
                </span>


                <span>

                    <strong>
                        Telefone:
                    </strong>

                    ${telefone}

                </span>

            </div>

        </div>


        <div class="card-rodape">


            <div class="preco-container">

                <span class="preco-label">

                    A partir de

                </span>


                <span class="preco">

                    ${valor}

                </span>

            </div>


            <button
                class="btn-agendar"
                onclick="agendarPersonal('${profissional.id_cref}')"
            >

                Agendar

            </button>

        </div>

    `;


    return card;

}


// ==================================================
// AGENDAR PERSONAL
// ==================================================

function agendarPersonal(cref) {

    if (!cref) {

        alert(
            "Não foi possível identificar o CREF do profissional."
        );

        return;

    }


    window.location.href =
        `agendar.html?id_cref=${encodeURIComponent(cref)}`;

}


// ==================================================
// FORMATAR MOEDA
// ==================================================

function formatarMoeda(
    valor
) {

    const numero =
        Number(valor);


    if (
        isNaN(numero)
    ) {

        return "Não informado";

    }


    return numero.toLocaleString(
        "pt-BR",
        {
            style: "currency",
            currency: "BRL"
        }
    );

}


// ==================================================
// ESCAPAR HTML
// ==================================================

function escaparHTML(
    texto
) {

    if (
        texto === null ||
        texto === undefined
    ) {

        return "";

    }


    return String(texto)

        .replace(
            /&/g,
            "&amp;"
        )

        .replace(
            /</g,
            "&lt;"
        )

        .replace(
            />/g,
            "&gt;"
        )

        .replace(
            /"/g,
            "&quot;"
        )

        .replace(
            /'/g,
            "&#039;"
        );

}


// ==================================================
// CARREGANDO
// ==================================================

function mostrarCarregando(
    elemento
) {

    elemento.innerHTML = `

        <div class="carregando">

            <div class="loader"></div>

            <p>
                Carregando profissionais...
            </p>

        </div>

    `;

}


// ==================================================
// ERRO
// ==================================================

function mostrarErro(
    elemento,
    mensagem
) {

    elemento.innerHTML = `

        <div class="erro">

            <h3>
                Erro ao carregar profissionais
            </h3>


            <p>

                ${escaparHTML(
                    mensagem ||
                    "Não foi possível carregar os dados."
                )}

            </p>

        </div>

    `;

}


// ==================================================
// SAIR
// ==================================================

function sair() {

    window.location.href =
        "../../php/logout.php";

}