const URL_FEEDBACK = "../../php/feedback.php";

let crefAtual = 0;
let notaAtual = 0;


document.addEventListener("DOMContentLoaded", () => {

    carregarPersonais();


    document
        .querySelectorAll("#estrelas button")
        .forEach(botao => {

            botao.addEventListener("click", () => {

                notaAtual =
                    Number(botao.dataset.nota);

                atualizarEstrelas();

            });

        });


    document
        .getElementById("relato")
        .addEventListener(
            "input",
            atualizarContador
        );


    document
        .getElementById("modalFeedback")
        .addEventListener("click", evento => {

            if (
                evento.target.id ===
                "modalFeedback"
            ) {

                fecharModal();

            }

        });

});


/* =========================================================
   CARREGAR PERSONAIS DISPONÍVEIS PARA AVALIAÇÃO
========================================================= */

async function carregarPersonais() {

    const lista =
        document.getElementById(
            "listaPersonais"
        );


    try {

        const resposta =
            await fetch(
                URL_FEEDBACK +
                "?acao=listar_personais",
                {
                    cache: "no-store"
                }
            );


        const texto =
            await resposta.text();


        let dados;


        try {

            dados =
                JSON.parse(texto);

        } catch {

            throw new Error(
                "O servidor não retornou uma resposta válida."
            );

        }


        if (dados.erro) {

            throw new Error(
                dados.erro
            );

        }


        /* =================================================
           NENHUM PERSONAL DISPONÍVEL
        ================================================= */

        if (
            !dados.personais ||
            !dados.personais.length
        ) {

            lista.innerHTML = `

                <div class="estado">

                    Você ainda não possui nenhuma aula
                    confirmada e realizada disponível
                    para avaliação.

                </div>

            `;

            return;

        }


        /* =================================================
           CRIAR CARDS
        ================================================= */

        lista.innerHTML =
            dados.personais
                .map(personal => {

                    const feedback =
                        personal.feedback;


                    const textoBotao =
                        feedback
                            ? "Editar avaliação"
                            : "Avaliar Personal";


                    const classeBotao =
                        feedback
                            ? "btn-avaliar editar"
                            : "btn-avaliar";


                    const avaliacaoAtual =
                        feedback

                            ? `

                                <p class="avaliacao-atual">

                                    ${estrelasTexto(
                                        feedback.avaliacao
                                    )}

                                    ${feedback.avaliacao}/5

                                </p>

                            `

                            : "";


                    return `

                        <article class="personal-card">


                            <div class="avatar">

                                ${avatar(
                                    personal.foto,
                                    personal.nome
                                )}

                            </div>


                            <div class="dados">

                                <h2>

                                    ${esc(
                                        personal.nome
                                    )}

                                </h2>


                                <p>

                                    CREF:

                                    <strong>
                                        ${personal.id_cref}
                                    </strong>

                                </p>


                                <p>

                                    Última aula:

                                    ${formatarData(
                                        personal.ultima_aula
                                    )}

                                </p>


                                ${avaliacaoAtual}


                            </div>


                            <button
                                class="${classeBotao}"
                                onclick='abrirModal(
                                    ${JSON.stringify(personal)}
                                )'
                            >

                                ⭐ ${textoBotao}

                            </button>


                        </article>

                    `;

                })
                .join("");

    }

    catch (erro) {

        console.error(
            "Erro ao carregar Personais:",
            erro
        );


        lista.innerHTML = `

            <div class="estado">

                ${esc(
                    erro.message
                )}

            </div>

        `;

    }

}



/* =========================================================
   ABRIR MODAL
========================================================= */

function abrirModal(personal) {

    crefAtual =
        Number(
            personal.id_cref
        );


    notaAtual =
        Number(
            personal.feedback?.avaliacao
            || 0
        );


    document.getElementById(
        "modalTitulo"
    ).textContent =

        personal.feedback
            ? "Editar avaliação"
            : "Avaliar Personal";


    document.getElementById(
        "modalPersonal"
    ).textContent =
        personal.nome;


    document.getElementById(
        "relato"
    ).value =
        personal.feedback?.relato
        || "";


    document.getElementById(
        "aviso"
    ).textContent = "";


    atualizarEstrelas();

    atualizarContador();


    document.getElementById(
        "modalFeedback"
    ).classList.add(
        "ativo"
    );

}



/* =========================================================
   FECHAR MODAL
========================================================= */

function fecharModal() {

    document.getElementById(
        "modalFeedback"
    ).classList.remove(
        "ativo"
    );

}



/* =========================================================
   ATUALIZAR ESTRELAS
========================================================= */

function atualizarEstrelas() {

    document
        .querySelectorAll(
            "#estrelas button"
        )
        .forEach(botao => {

            botao.classList.toggle(
                "ativa",

                Number(
                    botao.dataset.nota
                ) <= notaAtual
            );

        });


    const nomes = [

        "Selecione de 1 a 5 estrelas",

        "Muito ruim",

        "Ruim",

        "Regular",

        "Bom",

        "Excelente"

    ];


    document.getElementById(
        "textoNota"
    ).textContent =
        nomes[notaAtual]
        || nomes[0];

}



/* =========================================================
   CONTADOR DO COMENTÁRIO
========================================================= */

function atualizarContador() {

    const campo =
        document.getElementById(
            "relato"
        );


    document.getElementById(
        "contador"
    ).textContent =
        `${campo.value.length}/500`;

}



/* =========================================================
   SALVAR FEEDBACK
========================================================= */

async function salvarFeedback() {

    const relato =
        document.getElementById(
            "relato"
        ).value.trim();


    const aviso =
        document.getElementById(
            "aviso"
        );


    const botao =
        document.getElementById(
            "btnSalvar"
        );


    aviso.textContent = "";


    /* =====================================================
       VALIDAR NOTA
    ===================================================== */

    if (!notaAtual) {

        aviso.textContent =
            "Escolha uma nota.";

        return;

    }


    /* =====================================================
       VALIDAR COMENTÁRIO
    ===================================================== */

    if (
        relato.length < 3
    ) {

        aviso.textContent =
            "Escreva um comentário com pelo menos 3 caracteres.";

        return;

    }


    /* =====================================================
       PREPARAR DADOS
    ===================================================== */

    const dados =
        new FormData();


    dados.append(
        "acao",
        "salvar"
    );


    dados.append(
        "id_cref",
        crefAtual
    );


    dados.append(
        "avaliacao",
        notaAtual
    );


    dados.append(
        "relato",
        relato
    );


    /* =====================================================
       DESABILITAR BOTÃO
    ===================================================== */

    botao.disabled =
        true;


    botao.textContent =
        "Salvando...";


    try {

        const resposta =
            await fetch(
                URL_FEEDBACK,
                {
                    method: "POST",
                    body: dados
                }
            );


        const texto =
            await resposta.text();


        let resultado;


        try {

            resultado =
                JSON.parse(texto);

        }

        catch {

            console.error(
                "Resposta do PHP:",
                texto
            );


            throw new Error(
                "Erro no servidor ao salvar a avaliação."
            );

        }


        if (
            resultado.erro
        ) {

            throw new Error(
                resultado.erro
            );

        }


        /* =================================================
           SALVO
        ================================================= */

        fecharModal();


        await carregarPersonais();

    }

    catch (erro) {

        console.error(
            "Erro ao salvar feedback:",
            erro
        );


        aviso.textContent =
            erro.message;

    }

    finally {

        botao.disabled =
            false;


        botao.textContent =
            "Enviar avaliação";

    }

}



/* =========================================================
   FORMATAR DATA
========================================================= */

function formatarData(valor) {

    if (!valor) {

        return "-";

    }


    const [data] =
        String(valor)
            .split(" ");


    const [
        ano,
        mes,
        dia
    ] =
        data.split("-");


    return (
        `${dia}/${mes}/${ano}`
    );

}



/* =========================================================
   ESTRELAS EM TEXTO
========================================================= */

function estrelasTexto(nota) {

    nota =
        Number(nota)
        || 0;


    return (

        "★".repeat(nota)

        +

        "☆".repeat(
            5 - nota
        )

    );

}



/* =========================================================
   INICIAIS
========================================================= */

function iniciais(nome) {

    const partes =
        String(
            nome || "?"
        )
        .trim()
        .split(/\s+/);


    return (

        (
            partes[0]?.[0]
            || "?"
        )

        +

        (
            partes.length > 1

                ? partes[
                    partes.length - 1
                ][0]

                : ""
        )

    ).toUpperCase();

}



/* =========================================================
   FOTO / AVATAR
========================================================= */

function avatar(
    foto,
    nome
) {

    if (foto) {

        return `

            <img
                src="../../${esc(foto)}"
                alt="${esc(nome)}"

                onerror="
                    this.parentElement.textContent =
                    '${iniciais(nome)}'
                "
            >

        `;

    }


    return iniciais(nome);

}



/* =========================================================
   ESCAPAR HTML
========================================================= */

function esc(valor) {

    const div =
        document.createElement(
            "div"
        );


    div.textContent =
        valor ?? "";


    return div.innerHTML;

}



/* =========================================================
   SAIR
========================================================= */

function sair() {

    fetch(
        "../../php/logout.php"
    )

    .finally(() => {

        location.href =
            "../login.html";

    });

}