// ==================================================
// FITLINK - AGENDAMENTO
// ==================================================


// Evita que textos enviados pelo banco sejam tratados como HTML.
function escaparHTMLAgendar(valor) {
    return String(valor ?? "").replace(/[&<>"']/g, caractere => ({
        "&": "&amp;", "<": "&lt;", ">": "&gt;",
        "\"": "&quot;", "'": "&#39;"
    })[caractere]);
}

// ==================================================
// PEGAR CREF DA URL
// ==================================================

const parametros =
    new URLSearchParams(window.location.search);

const cref =
    parametros.get("id_cref");

console.log("URL:", window.location.href);
console.log("CREF recebido:", cref);


// ==================================================
// VARIÁVEIS
// ==================================================

let academiaSelecionada = "";
let dataSelecionada = "";
let horarioSelecionado = null;


// ==================================================
// ELEMENTOS
// ==================================================

const nomePersonal =
    document.getElementById("nomePersonal");

const crefPersonal =
    document.getElementById("crefPersonal");

const fotoPersonal =
    document.querySelector(".card-personal .foto-personal");

const academia =
    document.getElementById("academia");

const data =
    document.getElementById("data");

const listaHorarios =
    document.getElementById("listaHorarios");

const quantidadeHorarios =
    document.getElementById("quantidadeHorarios");

const quantidadeDisponiveis =
    document.getElementById("quantidadeDisponiveis");

const aviso =
    document.getElementById("aviso");

const modal =
    document.getElementById("modal");


// ==================================================
// INICIALIZAÇÃO
// ==================================================

document.addEventListener(
    "DOMContentLoaded",
    function () {

        definirDataAtual();

        if (!cref) {

            mostrarAviso(
                "Não foi possível identificar o profissional.",
                "erro"
            );

            listaHorarios.innerHTML = `
                <div class="carregando">
                    <p>
                        Personal não informado.
                    </p>
                </div>
            `;

            return;
        }

        carregarPersonal();
        carregarAcademias();
    }
);


// ==================================================
// DEFINIR DATA ATUAL
// ==================================================

function definirDataAtual() {

    const hoje = new Date();

    const ano =
        hoje.getFullYear();

    const mes =
        String(
            hoje.getMonth() + 1
        ).padStart(
            2,
            "0"
        );

    const dia =
        String(
            hoje.getDate()
        ).padStart(
            2,
            "0"
        );

    const dataHoje =
        `${ano}-${mes}-${dia}`;

    data.value =
        dataHoje;

    data.min =
        dataHoje;

    dataSelecionada =
        dataHoje;
}


// ==================================================
// EVENTO ACADEMIA
// ==================================================

academia.addEventListener(
    "change",
    function () {

        academiaSelecionada =
            this.value;

        carregarHorarios();
    }
);


// ==================================================
// EVENTO DATA
// ==================================================

data.addEventListener(
    "change",
    function () {

        dataSelecionada =
            this.value;

        carregarHorarios();
    }
);


// ==================================================
// CARREGAR PERSONAL
// ==================================================

function carregarPersonal() {

    fetch(
        `../../php/agendar.php?acao=dados_personal&id_cref=${encodeURIComponent(cref)}`
    )

    .then(
        resposta => {

            if (!resposta.ok) {

                throw new Error(
                    "Erro HTTP " +
                    resposta.status
                );
            }

            return resposta.json();
        }
    )

    .then(
        dados => {

            console.log(
                "Dados do personal:",
                dados
            );

            if (dados.erro) {

                mostrarAviso(
                    dados.erro,
                    "erro"
                );

                return;
            }

            nomePersonal.textContent =
                dados.nome || "Personal";

            crefPersonal.textContent =
                dados.id_cref || cref;

            atualizarFotoPersonal(
                dados.foto,
                dados.nome || "Personal"
            );
        }
    )

    .catch(
        erro => {

            console.error(
                "Erro ao carregar personal:",
                erro
            );

            mostrarAviso(
                "Erro ao carregar o profissional.",
                "erro"
            );
        }
    );
}




// ==================================================
// FOTO DO PERSONAL
// ==================================================

function gerarIniciaisPersonal(nome) {
    const partes = String(nome || "Personal").trim().split(/\s+/).filter(Boolean);
    if (!partes.length) return "P";
    if (partes.length === 1) return partes[0].charAt(0).toUpperCase();
    return (partes[0].charAt(0) + partes[partes.length - 1].charAt(0)).toUpperCase();
}

function atualizarFotoPersonal(foto, nome) {
    if (!fotoPersonal) return;

    if (foto) {
        const imagem = document.createElement("img");
        imagem.className = "foto-perfil-agendamento";
        imagem.alt = `Foto de ${String(nome || "Personal")}`;
        // Recebe o caminho do banco; impedir URLs externas e segmentos suspeitos.
        const caminho = String(foto).replace(/^\/+/, "");
        if (!/^img\/[\w\-/]+\.(?:jpg|jpeg|png|webp)$/i.test(caminho) || caminho.includes("..")) {
            fotoPersonal.textContent = gerarIniciaisPersonal(nome);
            return;
        }
        imagem.src = `../../${caminho}`;
        imagem.onerror = function () {
            fotoPersonal.textContent = gerarIniciaisPersonal(nome);
        };
        fotoPersonal.replaceChildren(imagem);
    } else {
        fotoPersonal.textContent = gerarIniciaisPersonal(nome);
    }
}

// ==================================================
// CARREGAR ACADEMIAS
// ==================================================

function carregarAcademias() {

    academia.innerHTML = `
        <option value="">
            Carregando academias...
        </option>
    `;

    fetch(
        `../../php/agendar.php?acao=academias&id_cref=${encodeURIComponent(cref)}`
    )

    .then(
        resposta => {

            if (!resposta.ok) {

                throw new Error(
                    "Erro HTTP " +
                    resposta.status
                );
            }

            return resposta.json();
        }
    )

    .then(
        dados => {

            console.log(
                "Academias:",
                dados
            );

            academia.innerHTML = `
                <option value="">
                    Selecione uma academia
                </option>
            `;

            if (dados.erro) {

                mostrarAviso(
                    dados.erro,
                    "erro"
                );

                return;
            }

            if (
                !Array.isArray(dados) ||
                dados.length === 0
            ) {

                academia.innerHTML = `
                    <option value="">
                        Nenhuma academia cadastrada
                    </option>
                `;

                return;
            }

            dados.forEach(
                item => {

                    const option =
                        document.createElement(
                            "option"
                        );

                    option.value =
                        item.id_academia;

                    option.textContent =
                        item.nomeacademia;

                    academia.appendChild(
                        option
                    );
                }
            );
        }
    )

    .catch(
        erro => {

            console.error(
                "Erro ao carregar academias:",
                erro
            );

            academia.innerHTML = `
                <option value="">
                    Erro ao carregar academias
                </option>
            `;

            mostrarAviso(
                "Erro ao carregar as academias.",
                "erro"
            );
        }
    );
}


// ==================================================
// CARREGAR HORÁRIOS
// ==================================================

function carregarHorarios() {

    academiaSelecionada =
        academia.value;

    dataSelecionada =
        data.value;


    // ----------------------------------------------
    // VERIFICAR SE FOI SELECIONADO TUDO
    // ----------------------------------------------

    if (
        !academiaSelecionada ||
        !dataSelecionada
    ) {

        listaHorarios.innerHTML = `
            <div class="carregando">
                <p>
                    Selecione uma academia e uma data.
                </p>
            </div>
        `;

        quantidadeHorarios.textContent =
            "0";

        quantidadeDisponiveis.textContent =
            "0";

        return;
    }


    // ----------------------------------------------
    // LOADING
    // ----------------------------------------------

    listaHorarios.innerHTML = `
        <div class="carregando">
            <div class="loader"></div>

            <p>
                Verificando horários...
            </p>
        </div>
    `;


    quantidadeHorarios.textContent =
        "0";

    quantidadeDisponiveis.textContent =
        "0";


    // ----------------------------------------------
    // BUSCAR NO PHP
    // ----------------------------------------------

    const url =
        `../../php/agendar.php` +
        `?acao=horarios` +
        `&id_cref=${encodeURIComponent(cref)}` +
        `&academia=${encodeURIComponent(academiaSelecionada)}` +
        `&data=${encodeURIComponent(dataSelecionada)}`;


    console.log(
        "Buscando horários:",
        url
    );


    fetch(url)

    .then(
        resposta => {

            if (!resposta.ok) {

                throw new Error(
                    "Erro HTTP " +
                    resposta.status
                );
            }

            return resposta.json();
        }
    )

    .then(
        dados => {

            console.log(
                "Horários recebidos:",
                dados
            );

            if (dados.erro) {

                listaHorarios.innerHTML = `
                    <div class="carregando">
                        <p>
                            ${dados.erro}
                        </p>
                    </div>
                `;

                quantidadeHorarios.textContent =
                    "0";

                quantidadeDisponiveis.textContent =
                    "0";

                return;
            }

            renderizarHorarios(
                dados
            );
        }
    )

    .catch(
        erro => {

            console.error(
                "Erro ao carregar horários:",
                erro
            );

            listaHorarios.innerHTML = `
                <div class="carregando">

                    <div style="font-size:45px;">
                        ⚠️
                    </div>

                    <h3>
                        Erro ao carregar horários
                    </h3>

                    <p>
                        Verifique se o servidor está funcionando.
                    </p>

                </div>
            `;

            quantidadeHorarios.textContent =
                "0";

            quantidadeDisponiveis.textContent =
                "0";

            mostrarAviso(
                "Erro ao carregar os horários.",
                "erro"
            );
        }
    );
}


// ==================================================
// RENDERIZAR HORÁRIOS
// ==================================================

function renderizarHorarios(
    dados
) {

    const horarios =
        Array.isArray(dados.horarios)
            ? dados.horarios
            : [];


    quantidadeHorarios.textContent =
        dados.total ?? horarios.length;


    quantidadeDisponiveis.textContent =
        dados.disponiveis ?? 0;


    listaHorarios.innerHTML =
        "";


    // ----------------------------------------------
    // NENHUM HORÁRIO
    // ----------------------------------------------

    if (
        horarios.length === 0
    ) {

        listaHorarios.innerHTML = `
            <div class="carregando">

                <div style="font-size:45px;">
                    🗓️
                </div>

                <h3>
                    Nenhum horário disponível
                </h3>

                <p>
                    O profissional não possui
                    horários cadastrados para esta data.
                </p>

            </div>
        `;

        return;
    }


    // ----------------------------------------------
    // CRIAR CARDS
    // ----------------------------------------------

    horarios.forEach(
        horario => {

            const card =
                document.createElement(
                    "div"
                );


            card.classList.add(
                "horario"
            );


            const status =
                horario.status ||
                "disponivel";


            card.classList.add(
                status
            );


            // --------------------------------------
            // TEXTO DO STATUS
            // --------------------------------------

            let textoStatus =
                "Disponível";


            if (
                status === "ocupado"
            ) {

                textoStatus =
                    "Ocupado";
            }


            if (
                status === "deslocamento"
            ) {

                textoStatus =
                    "Margem de deslocamento";
            }


            // --------------------------------------
            // NOME DA ACADEMIA
            // --------------------------------------

            const nomeAcademia =
                horario.nomeacademia ||
                "Academia";


            // --------------------------------------
            // HTML DO CARD
            // --------------------------------------

            card.innerHTML = `

                <div class="hora">
                    ${escaparHTMLAgendar(horario.hora_inicio)}
                    -
                    ${escaparHTMLAgendar(horario.hora_fim)}
                </div>

                <div class="academia">
                    🏋️
                    ${escaparHTMLAgendar(nomeAcademia)}
                </div>

                <span class="status ${status}">
                    ${textoStatus}
                </span>

            `;


            // --------------------------------------
            // SOMENTE DISPONÍVEL É CLICÁVEL
            // --------------------------------------

            if (
                status === "disponivel"
            ) {

                card.addEventListener(
                    "click",
                    function () {

                        abrirConfirmacao(
                            horario
                        );
                    }
                );
            }


            listaHorarios.appendChild(
                card
            );
        }
    );
}


// ==================================================
// ABRIR MODAL
// ==================================================

function abrirConfirmacao(
    horario
) {

    horarioSelecionado =
        horario;


    document.getElementById(
        "confirmPersonal"
    ).textContent =
        nomePersonal.textContent;


    document.getElementById(
        "confirmAcademia"
    ).textContent =
        horario.nomeacademia ||
        "Academia";


    document.getElementById(
        "confirmData"
    ).textContent =
        formatarData(
            dataSelecionada
        );


    document.getElementById(
        "confirmHorario"
    ).textContent =
        `${horario.hora_inicio} - ${horario.hora_fim}`;


    modal.classList.add(
        "ativo"
    );
}


// ==================================================
// FECHAR MODAL
// ==================================================

function fecharModal() {

    modal.classList.remove(
        "ativo"
    );

    horarioSelecionado =
        null;
}


// ==================================================
// CONFIRMAR AGENDAMENTO
// ==================================================

function confirmarAgendamento() {

    if (
        !horarioSelecionado
    ) {

        mostrarAviso(
            "Selecione um horário.",
            "erro"
        );

        return;
    }


    // ----------------------------------------------
    // DESABILITAR BOTÃO
    // ----------------------------------------------

    const botao =
        document.querySelector(
            ".btn-confirmar"
        );


    if (botao) {

        botao.disabled =
            true;

        botao.textContent =
            "Agendando...";
    }


    // ----------------------------------------------
    // FORM DATA
    // ----------------------------------------------

    const dados =
        new FormData();


    dados.append(
        "acao",
        "agendar"
    );


    dados.append(
        "id_cref",
        cref
    );


    dados.append(
        "id_agenda",
        horarioSelecionado.id_agenda
    );


    console.log(
        "Enviando agendamento:",
        {
            id_cref: cref,
            id_agenda:
                horarioSelecionado.id_agenda
        }
    );


    // ----------------------------------------------
    // ENVIAR AO PHP
    // ----------------------------------------------

    fetch(
        "../../php/agendar.php",
        {
            method: "POST",
            body: dados
        }
    )

    .then(
        resposta => {

            if (!resposta.ok) {

                throw new Error(
                    "Erro HTTP " +
                    resposta.status
                );
            }

            return resposta.json();
        }
    )

    .then(
        resultado => {

            console.log(
                "Resultado agendamento:",
                resultado
            );


            fecharModal();


            if (
                resultado.sucesso
            ) {

                mostrarAviso(
                    "Aula agendada com sucesso!",
                    "sucesso"
                );


                // Atualiza os horários
                carregarHorarios();

            } else {

                mostrarAviso(
                    resultado.erro ||
                    "Não foi possível agendar a aula.",
                    "erro"
                );


                carregarHorarios();
            }
        }
    )

    .catch(
        erro => {

            console.error(
                "Erro no agendamento:",
                erro
            );


            fecharModal();


            mostrarAviso(
                "Erro ao realizar o agendamento.",
                "erro"
            );
        }
    )

    .finally(
        () => {

            if (botao) {

                botao.disabled =
                    false;

                botao.textContent =
                    "Confirmar aula";
            }
        }
    );
}


// ==================================================
// FORMATAR DATA
// ==================================================

function formatarData(
    dataTexto
) {

    if (!dataTexto) {

        return "-";
    }


    const partes =
        dataTexto.split("-");


    if (
        partes.length !== 3
    ) {

        return dataTexto;
    }


    return (
        partes[2] +
        "/" +
        partes[1] +
        "/" +
        partes[0]
    );
}


// ==================================================
// MOSTRAR AVISO
// ==================================================

function mostrarAviso(
    mensagem,
    tipo
) {

    aviso.textContent =
        mensagem;

    aviso.className =
        "aviso " +
        tipo;
}


// ==================================================
// FECHAR MODAL CLICANDO FORA
// ==================================================

modal.addEventListener(
    "click",
    function (evento) {

        if (
            evento.target === modal
        ) {

            fecharModal();
        }
    }
);