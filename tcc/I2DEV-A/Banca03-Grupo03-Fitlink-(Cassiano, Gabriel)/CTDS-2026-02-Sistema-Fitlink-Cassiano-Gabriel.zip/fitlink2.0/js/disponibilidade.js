/* ==================================================
   FITLINK
   CONFIGURAÇÃO DE DISPONIBILIDADE
================================================== */

const URL_API = "../../php/disponibilidade.php";


// ==================================================
// DADOS
// ==================================================

let academias = [];

let disponibilidade = {};

let academiaAtual = "";


// Horários permitidos para início de aula
const horariosPermitidos = [

    "00:00",
    "01:00",
    "02:00",
    "03:00",
    "04:00",
    "05:00",
    "06:00",
    "07:00",
    "08:00",
    "09:00",
    "10:00",
    "11:00",
    "12:00",
    "13:00",
    "14:00",
    "15:00",
    "16:00",
    "17:00",
    "18:00",
    "19:00",
    "20:00",
    "21:00",
    "22:00",
    "23:00"

];


// Dias da semana
const dias = [

    {
        numero: 1,
        nome: "Segunda"
    },

    {
        numero: 2,
        nome: "Terça"
    },

    {
        numero: 3,
        nome: "Quarta"
    },

    {
        numero: 4,
        nome: "Quinta"
    },

    {
        numero: 5,
        nome: "Sexta"
    },

    {
        numero: 6,
        nome: "Sábado"
    },

    {
        numero: 7,
        nome: "Domingo"
    }

];


// ==================================================
// INICIALIZAÇÃO
// ==================================================

document.addEventListener(
    "DOMContentLoaded",
    iniciar
);


async function iniciar() {

    criarTabela();

    await carregarAcademias();

    await carregarDisponibilidade();

    atualizarTela();

}


// ==================================================
// CRIAR TABELA
// ==================================================

function criarTabela() {

    const corpo =
        document.getElementById(
            "corpoTabela"
        );

    corpo.innerHTML = "";


    for (
        let hora = 0;
        hora < 24;
        hora++
    ) {

        const horaTexto =
            String(hora).padStart(2, "0") + ":00";

        const linha =
            document.createElement("tr");


        // Coluna da hora
        const tdHora =
            document.createElement("td");

        tdHora.className =
            "celula-hora";

        tdHora.textContent =
            horaTexto;


        linha.appendChild(tdHora);


        // Dias
        dias.forEach(dia => {

            const td =
                document.createElement("td");


            const celula =
                document.createElement("div");

            celula.className =
                "celula-horario";


            const checkbox =
                document.createElement("input");

            checkbox.type = "checkbox";

            checkbox.className =
                "checkbox-horario";


            const texto =
                document.createElement("span");

            texto.className =
                "texto-horario";


            // Horário permitido
            if (
                horariosPermitidos.includes(
                    horaTexto
                )
            ) {

                texto.textContent = "Disponível";


                celula.dataset.dia =
                    dia.numero;

                celula.dataset.horario =
                    horaTexto;


                celula.addEventListener(
                    "click",
                    () => clicarHorario(
                        dia.numero,
                        horaTexto
                    )
                );

            }

            // Horário bloqueado
            else {

                celula.classList.add(
                    "bloqueado"
                );

                texto.textContent =
                    "Indisponível";

            }


            celula.appendChild(
                checkbox
            );

            celula.appendChild(
                texto
            );


            td.appendChild(
                celula
            );

            linha.appendChild(td);

        });


        corpo.appendChild(linha);

    }

}


// ==================================================
// CARREGAR ACADEMIAS
// ==================================================

async function carregarAcademias() {

    const select =
        document.getElementById(
            "academiaSelect"
        );


    try {

        const resposta =
            await fetch(
                `${URL_API}?acao=academias`,
                {
                    credentials: "same-origin"
                }
            );


        const dados =
            await resposta.json();


        if (!dados.sucesso) {

            throw new Error(
                dados.mensagem ||
                "Erro ao carregar academias."
            );

        }


        academias =
            dados.academias || [];


        select.innerHTML = "";


        if (
            academias.length === 0
        ) {

            select.innerHTML =
                `<option value="">
                    Nenhuma academia vinculada
                </option>`;

            select.disabled = true;

            return;

        }


        const primeira =
            document.createElement(
                "option"
            );

        primeira.value = "";

        primeira.textContent =
            "Selecione uma academia...";

        select.appendChild(
            primeira
        );


        academias.forEach(
            academia => {

                const option =
                    document.createElement(
                        "option"
                    );

                option.value =
                    academia.id_academia;

                option.textContent =
                    academia.nomeacademia;

                select.appendChild(
                    option
                );

            }
        );


    } catch (erro) {

        console.error(erro);

        select.innerHTML =
            `<option value="">
                Erro ao carregar academias
            </option>`;

        mostrarMensagem(
            erro.message,
            "erro"
        );

    }

}


// ==================================================
// TROCA DE ACADEMIA
// ==================================================

document
    .getElementById("academiaSelect")
    .addEventListener(
        "change",
        function () {

            academiaAtual =
                this.value;

            atualizarTela();

        }
    );


// ==================================================
// CARREGAR DISPONIBILIDADE
// ==================================================

async function carregarDisponibilidade() {

    try {

        const resposta =
            await fetch(
                `${URL_API}?acao=disponibilidade`,
                {
                    credentials: "same-origin"
                }
            );


        const dados =
            await resposta.json();


        if (!dados.sucesso) {

            throw new Error(
                dados.mensagem ||
                "Erro ao carregar disponibilidade."
            );

        }


        disponibilidade = {};


        (dados.disponibilidade || [])
            .forEach(item => {

                const chave =
                    gerarChave(
                        item.dia_semana,
                        item.horario
                    );


                disponibilidade[chave] = {

                    dia_semana:
                        Number(
                            item.dia_semana
                        ),

                    horario:
                        item.horario
                            .substring(0, 5),

                    id_academia:
                        String(
                            item.id_academia
                        ),

                    nomeacademia:
                        item.nomeacademia

                };

            });


    } catch (erro) {

        console.error(erro);

        mostrarMensagem(
            erro.message,
            "erro"
        );

    }

}


// ==================================================
// ATUALIZAR VISUAL
// ==================================================

function atualizarTela() {

    const celulas =
        document.querySelectorAll(
            ".celula-horario"
        );


    celulas.forEach(
        celula => {

            if (
                !celula.dataset.dia
            ) {
                return;
            }


            const dia =
                Number(
                    celula.dataset.dia
                );

            const horario =
                celula.dataset.horario;


            const chave =
                gerarChave(
                    dia,
                    horario
                );


            const registro =
                disponibilidade[chave];


            const texto =
                celula.querySelector(
                    ".texto-horario"
                );


            celula.classList.remove(
                "selecionado",
                "outra-academia"
            );


            // Nenhuma academia selecionada
            if (!academiaAtual) {

                if (registro) {

                    celula.classList.add(
                        "outra-academia"
                    );

                    texto.textContent =
                        abreviarAcademia(
                            registro.nomeacademia
                        );

                } else {

                    texto.textContent =
                        "Disponível";

                }

                return;

            }


            // Horário da academia atual
            if (
                registro &&
                String(
                    registro.id_academia
                ) === String(
                    academiaAtual
                )
            ) {

                celula.classList.add(
                    "selecionado"
                );

                texto.textContent =
                    "Selecionado";

                return;

            }


            // Horário pertence a outra academia
            if (registro) {

                celula.classList.add(
                    "outra-academia"
                );

                texto.textContent =
                    abreviarAcademia(
                        registro.nomeacademia
                    );

                return;

            }


            texto.textContent =
                "Disponível";

        }
    );


    atualizarNomeAcademia();

}


// ==================================================
// NOME DA ACADEMIA
// ==================================================

function atualizarNomeAcademia() {

    const elemento =
        document.getElementById(
            "academiaSelecionada"
        );


    if (!academiaAtual) {

        elemento.textContent =
            "Nenhuma academia selecionada.";

        elemento.classList.remove(
            "ativa"
        );

        return;

    }


    const academia =
        academias.find(
            item =>
                String(
                    item.id_academia
                ) === String(
                    academiaAtual
                )
        );


    if (!academia) {

        elemento.textContent =
            "Academia selecionada.";

        return;

    }


    elemento.textContent =
        `Academia atual: ${academia.nomeacademia}`;

    elemento.classList.add(
        "ativa"
    );

}


// ==================================================
// CLICAR NO HORÁRIO
// ==================================================

function clicarHorario(
    dia,
    horario
) {

    if (!academiaAtual) {

        mostrarMensagem(
            "Primeiro selecione uma academia.",
            "erro"
        );

        return;

    }


    const chave =
        gerarChave(
            dia,
            horario
        );


    const registro =
        disponibilidade[chave];


    // Se já está configurado nesta academia,
    // remove
    if (
        registro &&
        String(
            registro.id_academia
        ) === String(
            academiaAtual
        )
    ) {

        delete disponibilidade[chave];

        atualizarTela();

        return;

    }


    // Se já pertence a outra academia,
    // substitui pela atual
    disponibilidade[chave] = {

        dia_semana: dia,

        horario: horario,

        id_academia:
            String(
                academiaAtual
            ),

        nomeacademia:
            obterNomeAcademia(
                academiaAtual
            )

    };


    atualizarTela();

}


// ==================================================
// VALIDAR HORÁRIOS
// ==================================================

function validarDisponibilidade() {

    const registros =
        Object.values(
            disponibilidade
        );


    // Agrupar por dia
    const porDia = {};


    registros.forEach(
        registro => {

            const dia =
                Number(
                    registro.dia_semana
                );


            if (!porDia[dia]) {

                porDia[dia] = [];

            }


            porDia[dia].push(
                registro
            );

        }
    );


    // Verificar cada dia
    for (
        const dia in porDia
    ) {

        const registrosDia =
            porDia[dia];


        registrosDia.sort(
            (
                a,
                b
            ) =>
                converterMinutos(
                    a.horario
                ) -
                converterMinutos(
                    b.horario
                )
        );


        for (
            let i = 1;
            i < registrosDia.length;
            i++
        ) {

            const anterior =
                registrosDia[i - 1];

            const atual =
                registrosDia[i];


            const minutosAnterior =
                converterMinutos(
                    anterior.horario
                );

            const minutosAtual =
                converterMinutos(
                    atual.horario
                );


            const diferenca =
                minutosAtual -
                minutosAnterior;


            const academiasDiferentes =
                String(
                    anterior.id_academia
                ) !== String(
                    atual.id_academia
                );


            /*
             * Cada aula dura 60 minutos.
             *
             * Se forem academias diferentes,
             * precisamos de mais 30 minutos.
             *
             * Portanto:
             *
             * mesma academia = mínimo 60 min
             * academias diferentes = mínimo 90 min
             */

            if (
                academiasDiferentes &&
                diferenca < 90
            ) {

                const diaNome =
                    dias.find(
                        d =>
                            Number(
                                d.numero
                            ) === Number(
                                dia
                            )
                    )?.nome || "Dia";


                return {

                    valido: false,

                    mensagem:
                        `Conflito na ${diaNome}: ` +
                        `${anterior.horario} (${anterior.nomeacademia}) ` +
                        `e ${atual.horario} (${atual.nomeacademia}). ` +
                        `É necessário ter 30 minutos para deslocamento entre academias.`

                };

            }


            if (
                !academiasDiferentes &&
                diferenca < 60
            ) {

                return {

                    valido: false,

                    mensagem:
                        "Existem horários conflitantes no mesmo dia."

                };

            }

        }

    }


    return {

        valido: true,

        mensagem: ""

    };

}


// ==================================================
// SALVAR
// ==================================================

document
    .getElementById("btnSalvar")
    .addEventListener(
        "click",
        salvar
    );


async function salvar() {

    const validacao =
        validarDisponibilidade();


    if (
        !validacao.valido
    ) {

        mostrarMensagem(
            validacao.mensagem,
            "erro"
        );

        return;

    }


    const registros =
        Object.values(
            disponibilidade
        );


    const botao =
        document.getElementById(
            "btnSalvar"
        );


    botao.disabled = true;

    botao.textContent =
        "Salvando...";


    try {

        const resposta =
            await fetch(
                URL_API,
                {

                    method: "POST",

                    credentials:
                        "same-origin",

                    headers: {

                        "Content-Type":
                            "application/json"

                    },

                    body:
                        JSON.stringify({

                            disponibilidade:
                                registros

                        })

                }
            );


        const dados =
            await resposta.json();


        if (!dados.sucesso) {

            throw new Error(
                dados.mensagem ||
                "Não foi possível salvar."
            );

        }


        mostrarMensagem(
            "✓ Horários salvos com sucesso!",
            "sucesso"
        );


    } catch (erro) {

        console.error(erro);

        mostrarMensagem(
            erro.message,
            "erro"
        );

    } finally {

        botao.disabled = false;

        botao.textContent =
            "✓ Salvar horários";

    }

}


// ==================================================
// FUNÇÕES AUXILIARES
// ==================================================

function gerarChave(
    dia,
    horario
) {

    return `${dia}_${horario}`;

}


function converterMinutos(
    horario
) {

    const partes =
        horario.split(":");

    return (
        Number(partes[0]) * 60 +
        Number(partes[1])
    );

}


function obterNomeAcademia(
    id
) {

    const academia =
        academias.find(
            item =>
                String(
                    item.id_academia
                ) === String(id)
        );


    return academia
        ? academia.nomeacademia
        : "Academia";

}


function abreviarAcademia(
    nome
) {

    if (!nome) {

        return "Outra academia";

    }


    if (
        nome.length <= 18
    ) {

        return nome;

    }


    return nome.substring(
        0,
        16
    ) + "...";

}


function mostrarMensagem(
    texto,
    tipo
) {

    const elemento =
        document.getElementById(
            "mensagem"
        );


    elemento.textContent =
        texto;


    elemento.className =
        `mensagem ${tipo}`;


    setTimeout(
        () => {

            elemento.textContent =
                "";

            elemento.className =
                "mensagem";

        },
        6000
    );

}


// ==================================================
// SAIR
// ==================================================

function sair() {

    window.location.href =
        "../../php/logout.php";

}