const API_PERFIL = "../../php/perfil_aluno.php";


document.addEventListener("DOMContentLoaded", () => {

    carregarPerfil();

    document
        .getElementById("perfilForm")
        ?.addEventListener(
            "submit",
            salvarPerfil
        );

    document
        .getElementById("senhaForm")
        ?.addEventListener(
            "submit",
            alterarSenha
        );

    document
        .getElementById("inputFoto")
        ?.addEventListener(
            "change",
            enviarFoto
        );

});


async function carregarPerfil() {

    try {

        const resposta = await fetch(
            `${API_PERFIL}?acao=perfil`
        );

        const dados =
            await resposta.json();


        if (dados.erro) {

            alert(dados.erro);
            return;

        }


        document.getElementById("nome").value =
            dados.nome || "";

        document.getElementById("email").value =
            dados.email || "";

        document.getElementById("telefone").value =
            dados.telefone || "";

        document.getElementById("data_nascimento").value =
            dados.data_nascimento || "";

        document.getElementById("genero").value =
            dados.genero || "";


        carregarFoto(dados);

    } catch (erro) {

        console.error(erro);

        alert(
            "Erro ao carregar o perfil."
        );

    }

}


function carregarFoto(dados) {

    const imagem =
        document.getElementById("fotoPerfil");

    const iniciais =
        document.getElementById("iniciaisPerfil");

    const nome =
        dados.nome || "Aluno";


    document.getElementById("nomeFoto").textContent =
        nome;


    iniciais.textContent =
        gerarIniciais(nome);


    if (dados.foto) {

        imagem.src =
            `../../${dados.foto}?t=${Date.now()}`;

        imagem.style.display =
            "block";

        iniciais.style.display =
            "none";

        imagem.onerror = () => {

            imagem.style.display =
                "none";

            iniciais.style.display =
                "flex";

        };

    } else {

        imagem.style.display =
            "none";

        iniciais.style.display =
            "flex";

    }

}


function gerarIniciais(nome) {

    const partes =
        nome
            .trim()
            .split(/\s+/)
            .filter(Boolean);


    if (partes.length === 0) {
        return "A";
    }


    if (partes.length === 1) {
        return partes[0][0].toUpperCase();
    }


    return (
        partes[0][0]
        + partes[partes.length - 1][0]
    ).toUpperCase();

}


async function salvarPerfil(event) {

    event.preventDefault();


    const formData =
        new FormData();


    formData.append(
        "acao",
        "editar"
    );

    formData.append(
        "nome",
        document.getElementById("nome").value
    );

    formData.append(
        "email",
        document.getElementById("email").value
    );

    formData.append(
        "telefone",
        document.getElementById("telefone").value
    );

    formData.append(
        "data_nascimento",
        document.getElementById("data_nascimento").value
    );

    formData.append(
        "genero",
        document.getElementById("genero").value
    );


    try {

        const resposta = await fetch(
            API_PERFIL,
            {
                method: "POST",
                body: formData
            }
        );


        const dados =
            await resposta.json();


        if (dados.erro) {

            alert(dados.erro);
            return;

        }


        alert(
            dados.mensagem ||
            "Perfil atualizado com sucesso."
        );


        carregarPerfil();

    } catch (erro) {

        console.error(erro);

        alert(
            "Erro ao salvar o perfil."
        );

    }

}


async function enviarFoto(event) {

    const arquivo =
        event.target.files[0];


    if (!arquivo) {
        return;
    }


    if (arquivo.size > 5 * 1024 * 1024) {

        alert(
            "A foto pode ter no máximo 5 MB."
        );

        event.target.value = "";
        return;

    }


    const tiposPermitidos = [
        "image/jpeg",
        "image/png",
        "image/webp"
    ];


    if (
        !tiposPermitidos.includes(
            arquivo.type
        )
    ) {

        alert(
            "Use uma imagem JPG, PNG ou WEBP."
        );

        event.target.value = "";
        return;

    }


    const formData =
        new FormData();


    formData.append(
        "acao",
        "upload_foto"
    );

    formData.append(
        "foto",
        arquivo
    );


    try {

        const resposta = await fetch(
            API_PERFIL,
            {
                method: "POST",
                body: formData
            }
        );


        const dados =
            await resposta.json();


        if (dados.erro) {

            alert(dados.erro);
            return;

        }


        const imagem =
            document.getElementById(
                "fotoPerfil"
            );

        const iniciais =
            document.getElementById(
                "iniciaisPerfil"
            );


        imagem.src =
            `../../${dados.foto}?t=${Date.now()}`;

        imagem.style.display =
            "block";

        iniciais.style.display =
            "none";


        alert(
            "Foto atualizada com sucesso."
        );


    } catch (erro) {

        console.error(erro);

        alert(
            "Erro ao enviar a foto."
        );

    }


    event.target.value = "";

}


async function alterarSenha(event) {

    event.preventDefault();


    const senhaAtual =
        document.getElementById(
            "senha_atual"
        ).value;

    const novaSenha =
        document.getElementById(
            "nova_senha"
        ).value;

    const confirmarSenha =
        document.getElementById(
            "confirmar_senha"
        ).value;


    if (novaSenha !== confirmarSenha) {

        alert(
            "A confirmação da senha não confere."
        );

        return;

    }


    const formData =
        new FormData();


    formData.append(
        "acao",
        "alterar_senha"
    );

    formData.append(
        "senha_atual",
        senhaAtual
    );

    formData.append(
        "nova_senha",
        novaSenha
    );


    try {

        const resposta = await fetch(
            API_PERFIL,
            {
                method: "POST",
                body: formData
            }
        );


        const dados =
            await resposta.json();


        if (dados.erro) {

            alert(dados.erro);
            return;

        }


        alert(
            dados.mensagem ||
            "Senha alterada com sucesso."
        );


        document
            .getElementById("senhaForm")
            .reset();


    } catch (erro) {

        console.error(erro);

        alert(
            "Erro ao alterar a senha."
        );

    }

}


function sair() {

    window.location.href =
        "../../php/logout.php";

}