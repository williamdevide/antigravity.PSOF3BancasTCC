function sair() {

    fetch(
        "../../php/logout.php"
    )

    .finally(() => {

        location.href =
            "../login.html";

    });
}